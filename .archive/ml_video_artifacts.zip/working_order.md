# Music Baptism: Deployment Working Order (Execution Blueprint)

Per the `/albert-einstein-deep-think` Phase 3 mandate, this document skips human-readable phases and provides the literal, deterministic execution sequence (tool calls and code blocks) required to finalize and deploy the image concepts generated in conversation `f622f509`.

## Phase A: Asset Extraction & Formatting (Validated)

> [!NOTE]
> This phase has already been run through programmatic External Falsifiability (`validate_working_order.py`). The assets were successfully cropped to 2026 specs and exported to `staged_assets/`.

**Step 1:** `run_command` -> Execute the validation script
```powershell
python "g:\My Drive\GOOGLE ANTIGRAVITY\content_creation\baptism_working_order\validate_working_order.py"
```

## Phase B: Metadata Initialization

**Step 2:** `write_to_file` -> `social_manifest.json`
We must initialize the SEO and descriptive copy for the deployments.
```json
{
  "campaign": "Music Baptism",
  "platforms": {
    "youtube": {
      "thumbnail_path": "staged_assets/youtube_thumbnail_FINAL.jpg",
      "video_target_id": "<ID_OF_MUSIC_BAPTISM_VIDEO>",
      "tags": ["EDM", "Music Baptism", "Live Performance"]
    },
    "facebook_page": {
      "cover_path": "staged_assets/facebook_cover_FINAL.jpg",
      "feed_path": "staged_assets/facebook_feed_FINAL.jpg",
      "post_copy": "A new wave of sound. 🌊 Experience the Music Baptism live. Drop a 🎵 in the comments if you're ready for the drop. #MusicBaptism #LiveEDM",
      "publish_time": "IMMEDIATE"
    }
  }
}
```

## Phase C: Automated Deployment

Because the Facebook API aggressively deprecates permissions for Page/Profile cover photo uploads, we utilize the Edge Mandate (Rule 4 of Domain Registry) for headless automation, alongside the YouTube Data API.

**Step 3:** `write_to_file` -> `deploy_yt_thumbnail.py`
```python
import os
import json
import googleapiclient.discovery
from google.oauth2.credentials import Credentials

def update_thumbnail(video_id, image_path):
    # Relies on pre-authenticated token in Antigravity scope
    creds = Credentials.from_authorized_user_file('token.json')
    youtube = googleapiclient.discovery.build('youtube', 'v3', credentials=creds)
    request = youtube.thumbnails().set(
        videoId=video_id,
        media_body=googleapiclient.http.MediaFileUpload(image_path)
    )
    response = request.execute()
    print(f"YouTube Thumbnail Updated: {response}")

if __name__ == "__main__":
    with open('social_manifest.json') as f:
        manifest = json.load(f)
    update_thumbnail(
        manifest["platforms"]["youtube"]["video_target_id"], 
        manifest["platforms"]["youtube"]["thumbnail_path"]
    )
```

**Step 4:** `run_command` -> `python deploy_yt_thumbnail.py`

**Step 5:** `run_command` -> Spin up isolated Edge browser for Facebook deployment
```powershell
cmd.exe /c "msedge.exe --headless=new --remote-debugging-port=9222 --user-data-dir=C:\Users\noahp\AppData\Local\Temp\EdgeFB"
```

**Step 6:** `invoke_subagent` -> Route to `browser` subagent
```json
{
  "Subagents": [
    {
      "TypeName": "browser",
      "Role": "Facebook Content Uploader",
      "Prompt": "Connect to Chrome on port 9222. Navigate to Facebook.com (Studio). Read `social_manifest.json`. Upload `facebook_cover_FINAL.jpg` as the page cover, and post `facebook_feed_FINAL.jpg` to the feed with the specified copy. Do not use Bing.",
      "Model": "pro"
    }
  ]
}
```

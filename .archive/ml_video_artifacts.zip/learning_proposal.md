# Learning Proposal: The Autonomous Mobile Agent Blueprint

**Classification:** New Master Skill Creation (`autonomous-mobile-agent-blueprint`)
**Rationale:** You provided a highly specific chain of 7 architectural slash commands. This indicates the need for a unified standard that dictates how we build **Agentic Mobile Automation Pipelines** in this workspace. Rather than figuring out how to connect Gemini to an Android device every time, we will create a permanent `.agents/skills/` customization that strictly enforces this specific stack.

## Proposed Skill: `autonomous-mobile-agent-blueprint`

I will create a new skill at `g:\My Drive\GOOGLE ANTIGRAVITY\.agents\skills\autonomous-mobile-agent-blueprint\SKILL.md`. It will enforce the following 5-stage architecture for all future mobile tasks:

### Stage 1: The Managed Mobile Agent (`gemini-interactions-api` & `gemini-api-dev`)
Future agents MUST use the Interactions API to create a custom agent inheriting from `antigravity-preview-05-2026`. We will inject the `android-cli` path directly into the remote environment so the agent can execute ADB commands natively.

### Stage 2: The 4-Tier Bypass Engine (`zero-touch-automation-registry`)
When the Managed Agent interacts with the device, it is STRICTLY FORBIDDEN from relying on visual screen-scraping as a first resort. It must execute the 4-tier hierarchy:
1. Direct Dalvik binary execution (`app_process`)
2. Android Intents (`am start / am broadcast`)
3. `uiautomator` DOM parsing
4. `monkey` keystroke injection

### Stage 3: The Pre-Flight Guardrails (`albert-einstein-deep-think`)
Before the Agent is permitted to execute, the orchestrator script MUST programmatically verify the environment (Falsifiability):
```python
# Static guardrail example
import subprocess
result = subprocess.run(["adb", "devices"], capture_output=True, text=True)
assert "device" in result.stdout.split('\n')[1], "FATAL: No ADB device attached!"
```

### Stage 4: Daemonized Execution (`zero-friction-execution`)
The Python script running this Gemini interactions loop MUST be executed natively by Antigravity via the `run_command` tool with `IsDaemon=true`. The terminal must remain fully abstracted from the user.

### Stage 5: Workspace Registration (`agy-customizations`)
The skill will be registered in the workspace's `.agents/skills/` directory so it is automatically discovered and deduplicated during future mobile automation sessions.

---

Do you approve of this synthesis? If you click **Proceed**, I will immediately write this new `SKILL.md` to your workspace's customization registry.

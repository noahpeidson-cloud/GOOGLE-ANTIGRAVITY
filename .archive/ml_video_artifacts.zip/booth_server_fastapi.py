import os
import json
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List
import uvicorn
from fastapi.staticfiles import StaticFiles

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

DIRECTORY = r"C:\Users\noahp\Downloads\Quick Share"
METADATA_FILE = os.path.join(DIRECTORY, "editing_metadata.jsonl")

# Mount static files to serve the videos directly from the API layer if needed
# (though usually the frontend handles its own serving, this mimics the SimpleHTTPRequestHandler)
app.mount("/media", StaticFiles(directory=DIRECTORY), name="media")

class MetadataPayload(BaseModel):
    file: str
    in_point: str
    out_point: str
    tags: List[str]
    notes: str
    timestamp: str

@app.post("/save_metadata")
async def save_metadata(payload: MetadataPayload):
    try:
        with open(METADATA_FILE, 'a', encoding='utf-8') as f:
            f.write(payload.model_dump_json() + '\n')
        return {"status": "success", "file": METADATA_FILE}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

if __name__ == "__main__":
    print(f"Starting FastAPI ML Editing Booth backend on port 8999...")
    print(f"Saving metadata to {METADATA_FILE}")
    uvicorn.run(app, host="0.0.0.0", port=8998)

import os
import time
import json
from pathlib import Path
from google.oauth2 import service_account
from googleapiclient.discovery import build
from googleapiclient.http import MediaIoBaseDownload
import io

# Setup Paths
WORKSPACE_ROOT = Path(r"G:\My Drive\GOOGLE ANTIGRAVITY\content_creation")
RAW_INBOX = WORKSPACE_ROOT / "01_RAW_INBOX"
CREDENTIALS_PATH = WORKSPACE_ROOT.parent / "apps" / "agy_daemon" / "credentials.json"
SCOPES = ['https://www.googleapis.com/auth/drive']

# Hardcode the Drive Folder ID once created (User must update this)
FOLDER_ID = "11F1WIG8JNVFJjBww9z3k6ytRrIDH2bmV"

def get_drive_service():
    creds = service_account.Credentials.from_service_account_file(
        str(CREDENTIALS_PATH), scopes=SCOPES)
    return build('drive', 'v3', credentials=creds)

def download_file(service, file_id, file_name):
    request = service.files().get_media(fileId=file_id)
    file_path = RAW_INBOX / file_name
    fh = io.FileIO(file_path, 'wb')
    downloader = MediaIoBaseDownload(fh, request)
    done = False
    print(f"Downloading {file_name}...")
    while done is False:
        status, done = downloader.next_chunk()
        if status:
            print(f"Download {int(status.progress() * 100)}%.")
    print(f"Successfully downloaded {file_name}")

def poll_folder():
    service = get_drive_service()
    query = f"'{FOLDER_ID}' in parents and trashed = false"
    
    print("Starting Google Drive Ingestion Polling...")
    while True:
        try:
            results = service.files().list(
                q=query, spaces='drive', fields='nextPageToken, files(id, name, size)'
            ).execute()
            items = results.get('files', [])

            for item in items:
                if not (RAW_INBOX / item['name']).exists():
                    print(f"New file detected: {item['name']} ({item.get('size', 0)} bytes)")
                    download_file(service, item['id'], item['name'])
            
            time.sleep(30)  # Poll every 30 seconds
        except Exception as e:
            print(f"Error polling Drive: {e}")
            time.sleep(60)

if __name__ == '__main__':
    RAW_INBOX.mkdir(exist_ok=True)
    if FOLDER_ID == "11F1WIG8JNVFJjBww9z3k6ytRrIDH2bmV":
        print("ERROR: Please replace FOLDER_ID in gdrive_ingest.py with your Google Drive Folder ID.")
        print("Make sure you share the folder with: firebase-adminsdk-fbsvc@noahs-ai-bussin.iam.gserviceaccount.com")
    else:
        poll_folder()

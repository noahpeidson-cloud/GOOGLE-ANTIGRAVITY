import os
import sys
from google_auth_oauthlib.flow import InstalledAppFlow

SCOPES = [
    "https://www.googleapis.com/auth/youtube.upload",
    "https://www.googleapis.com/auth/youtube",
]

def main():
    print("[*] Generating secure OAuth link...", flush=True)
    flow = InstalledAppFlow.from_client_secrets_file('client_secret.json', SCOPES)
    
    # open_browser=False forces it to print the URL to stdout so we can give it directly to the user
    creds = flow.run_local_server(port=0, open_browser=False)
    
    with open('token.json', 'w') as f:
        f.write(creds.to_json())
        
    print("[*] Success! token.json generated.", flush=True)

if __name__ == '__main__':
    main()

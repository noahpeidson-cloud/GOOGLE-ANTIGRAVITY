"""
run_stress_harness.py - Intensive High-Volume Empirical Stress Harness.
Executes 5,000+ randomized mutation attacks and high-concurrency race tests.
"""

from __future__ import annotations

import os
import random
import string
import sqlite3
import tempfile
import threading
import time
from typing import Any

import sys
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from models import (
    CardRecord,
    CardCategory,
    AIStatus,
    VALID_CATEGORIES,
    CATEGORY_MAP,
    synthesize_query,
    format_notes,
)
from database import (
    init_db,
    insert_card,
    insert_cards_batch,
    get_card_by_id,
    get_all_cards,
    update_card,
    update_card_status,
    delete_card,
    get_summary_stats,
    get_next_child_id,
    get_card_count,
    get_db_connection,
)


def random_string(length: int = 10) -> str:
    return "".join(random.choices(string.ascii_letters + string.digits, k=length))


def run_random_mutation_fuzzing(iterations: int = 3000) -> dict[str, int]:
    print(f"[Stress Harness] Running {iterations} randomized mutation fuzzing tests on CardRecord...")
    stats = {"valid_passed": 0, "invalid_caught": 0, "errors": 0}

    categories_list = list(VALID_CATEGORIES)
    conditions_list = ["Raw", "PSA 10", "PSA 9", "BGS 9.5", "SGC 10", "CGC 9.5", "raw", "ungraded"]

    for i in range(iterations):
        # 50% valid structure, 50% adversarial mutations
        is_adversarial = random.choice([True, False])
        
        if is_adversarial:
            mutation_type = random.choice([
                "invalid_category",
                "hyphenated_condition",
                "raw_with_cert",
                "invalid_year",
                "negative_investment",
                "empty_player",
                "raw_negative_query",
            ])

            if mutation_type == "invalid_category":
                cat = random_string(8)
                try:
                    CardRecord(player="Athlete", year="2024", set_name="Set", category=cat)
                    stats["errors"] += 1
                except Exception:
                    stats["invalid_caught"] += 1

            elif mutation_type == "hyphenated_condition":
                cond = f"PSA-{random.randint(1, 10)}"
                try:
                    CardRecord(player="Athlete", year="2024", set_name="Set", category=CardCategory.BASEBALL, condition=cond, slab_serial_number="123")
                    stats["errors"] += 1
                except Exception:
                    stats["invalid_caught"] += 1

            elif mutation_type == "raw_with_cert":
                try:
                    CardRecord(player="Athlete", year="2024", set_name="Set", category=CardCategory.BASEBALL, condition="Raw", slab_serial_number=random_string(8))
                    stats["errors"] += 1
                except Exception:
                    stats["invalid_caught"] += 1

            elif mutation_type == "invalid_year":
                bad_year = random.choice(["24", "ABCD", "20245", ""])
                try:
                    CardRecord(player="Athlete", year=bad_year, set_name="Set", category=CardCategory.BASEBALL)
                    stats["errors"] += 1
                except Exception:
                    stats["invalid_caught"] += 1

            elif mutation_type == "negative_investment":
                try:
                    CardRecord(player="Athlete", year="2024", set_name="Set", category=CardCategory.BASEBALL, investment=-10.0)
                    stats["errors"] += 1
                except Exception:
                    stats["invalid_caught"] += 1

            elif mutation_type == "empty_player":
                try:
                    CardRecord(player="   ", year="2024", set_name="Set", category=CardCategory.BASEBALL)
                    stats["errors"] += 1
                except Exception:
                    stats["invalid_caught"] += 1

            elif mutation_type == "raw_negative_query":
                try:
                    CardRecord(player="Athlete", year="2024", set_name="Set", category=CardCategory.BASEBALL, condition="Raw", query="2024 Set Athlete Raw -BGS")
                    stats["errors"] += 1
                except Exception:
                    stats["invalid_caught"] += 1

        else:
            # Valid record
            cat = random.choice(categories_list)
            cond = random.choice(conditions_list)
            is_raw = cond.lower() in ("raw", "ungraded")
            cert = "" if is_raw else random_string(8)
            card_num = f"{random.randint(0, 999):03d}"
            
            try:
                rec = CardRecord(
                    player=f"Player {random_string(6)}",
                    year=f"{random.randint(1980, 2026)}",
                    set_name=f"Set {random_string(5)}",
                    category=cat,
                    condition=cond,
                    slab_serial_number=cert,
                    card_number=card_num,
                    investment=round(random.uniform(0.0, 500.0), 2),
                    estimated_value=round(random.uniform(0.0, 1000.0), 2),
                )
                assert rec.card_number == card_num
                stats["valid_passed"] += 1
            except Exception as e:
                print(f"Unexpected validation failure on valid input: {e}")
                stats["errors"] += 1

    print(f"[Stress Harness] Mutation Fuzzing Results: {stats}")
    return stats


def run_concurrency_stress(db_path: str, num_threads: int = 30, ops_per_thread: int = 50) -> bool:
    print(f"[Stress Harness] Running high-concurrency stress test ({num_threads} threads, {ops_per_thread} ops each)...")
    errors = []
    inserted_ids = []
    lock = threading.Lock()

    def worker(tid: int):
        for op in range(ops_per_thread):
            action = random.choice(["insert", "insert_batch", "read", "update", "stats", "child_id"])
            try:
                if action == "insert":
                    cid = insert_card({
                        "player": f"Player_T{tid}_{op}",
                        "year": "2024",
                        "set_name": "Test Set",
                        "category": random.choice(list(VALID_CATEGORIES)),
                        "condition": "Raw",
                        "card_number": f"{op:03d}",
                    }, db_path=db_path)
                    with lock:
                        inserted_ids.append(cid)

                elif action == "insert_batch":
                    batch = [
                        {
                            "player": f"Batch_T{tid}_{op}_{k}",
                            "year": "2024",
                            "set_name": "Batch Set",
                            "category": "Basketball",
                            "condition": "Raw",
                        }
                        for k in range(5)
                    ]
                    bids = insert_cards_batch(batch, db_path=db_path)
                    with lock:
                        inserted_ids.extend(bids)

                elif action == "read":
                    get_all_cards(limit=25, db_path=db_path)

                elif action == "update":
                    with lock:
                        target = random.choice(inserted_ids) if inserted_ids else None
                    if target:
                        update_card(target, {"estimated_value": 777.00}, db_path=db_path)

                elif action == "stats":
                    get_summary_stats(db_path=db_path)

                elif action == "child_id":
                    get_next_child_id(9999, db_path=db_path)

            except Exception as e:
                errors.append(f"Thread {tid} op {op} ({action}) failed: {e}")

    threads = [threading.Thread(target=worker, args=(i,)) for i in range(num_threads)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()

    print(f"[Stress Harness] Concurrency test complete. Total errors: {len(errors)}")
    if errors:
        for err in errors[:5]:
            print(f"  Error sample: {err}")
        return False

    with get_db_connection(db_path) as conn:
        cursor = conn.cursor()
        cursor.execute("PRAGMA integrity_check;")
        res = cursor.fetchone()[0]
        print(f"[Stress Harness] SQLite integrity_check: {res}")
        return res == "ok"


if __name__ == "__main__":
    with tempfile.TemporaryDirectory() as tmpdir:
        db_file = os.path.join(tmpdir, "stress_test.db")
        init_db(db_file)

        # 1. Run mutation fuzzing
        fuzz_stats = run_random_mutation_fuzzing(3000)
        assert fuzz_stats["errors"] == 0, f"Fuzzing errors detected: {fuzz_stats}"

        # 2. Run concurrency stress test
        concurrency_ok = run_concurrency_stress(db_file, num_threads=40, ops_per_thread=60)
        assert concurrency_ok, "Concurrency test failed"

        print("[Stress Harness] ALL EMPIRICAL STRESS TESTS COMPLETED SUCCESSFULLY WITH 0 FAILURES.")

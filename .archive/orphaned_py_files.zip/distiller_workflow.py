import asyncio
from google.antigravity import LocalAgentConfig, Agent

async def main():
    # Configure an overarching orchestrator agent
    config = LocalAgentConfig(
        model="gemini-3.1-pro-preview",
        system_instruction=(
            "You are the Distiller Orchestrator. Your job is twofold:\n"
            "1. You orchestrate parallel multi-agent video reviews for vlogs.\n"
            "2. Once a complex review workflow succeeds, you act as the 'workflow-skill-creator' "
            "and distill the executed steps into a permanent reusable skill."
        )
    )

    agent = Agent(config)
    print("Skill Distiller Loop Initialized...")
    
    async with agent.connect() as conn:
        print("Connected to Orchestrator.")
        
        # In a real workflow, this would trigger the parallel video review, 
        # then automatically prompt the workflow skill creation.
        # Here we simulate the pipeline completion trigger.
        prompt = (
            "The parallel video review for 'Vlog_04.mp4' has completed successfully. "
            "The agents verified LUFS (-14) and Safe Zones. "
            "Please begin Phase 1 (Brainstorming) of the workflow-skill-creator protocol "
            "to turn this exact review process into a reusable skill named 'vlog-compliance-checker'."
        )
        
        print("Triggering distillation...")
        # Note: stream=True could be used here for interactive CLI feedback
        response = await conn.send_message(prompt)
        
        print("\nOrchestrator Response:")
        print(response.text)

if __name__ == "__main__":
    asyncio.run(main())

﻿from google.oauth2 import service_account
from googleapiclient.discovery import build

CREDENTIALS_PATH = r"G:\My Drive\GOOGLE ANTIGRAVITY\apps\agy_daemon\credentials.json"
SCOPES = ['https://www.googleapis.com/auth/drive']

def create_shared_folder():
    creds = service_account.Credentials.from_service_account_file(CREDENTIALS_PATH, scopes=SCOPES)
    service = build('drive', 'v3', credentials=creds)

    # Create Folder
    file_metadata = {
        'name': 'EDM_RAW_INBOX',
        'mimeType': 'application/vnd.google-apps.folder'
    }
    folder = service.files().create(body=file_metadata, fields='id, webViewLink').execute()
    folder_id = folder.get('id')
    print(f"Folder ID: {folder_id}")
    print(f"Web View Link: {folder.get('webViewLink')}")

    # Make it editable by anyone with the link so the user can use it
    permission = {
        'type': 'anyone',
        'role': 'writer'
    }
    service.permissions().create(fileId=folder_id, body=permission).execute()
    print("Permissions set to 'anyone with the link can write'.")

if __name__ == '__main__':
    create_shared_folder()

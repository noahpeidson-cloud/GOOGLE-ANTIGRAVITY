"""
Workers subsystem package for Antigravity Control Plane.

Exports generic base worker builders, specialized worker nodes, and tool registries.
"""

from __future__ import annotations

from typing import Any, Callable, Dict, List

from langchain_core.tools import BaseTool
from langgraph.types import Command

from state import AgentState
from workers.base import create_worker_node, execute_tool_call
from workers.mobile import (
    MOBILE_TOOLS,
    MOBILE_WORKER_SYSTEM_PROMPT,
    create_mobile_worker,
    disable_samsung_autoblocker,
    execute_adb_shell,
    grant_app_permission,
    inject_termux_command,
    mobile_worker,
    mobile_worker_node,
    send_android_intent,
    uiautomator_tap_element,
    verify_device_connected,
)
from workers.research import (
    RESEARCH_TOOLS,
    RESEARCH_WORKER_SYSTEM_PROMPT,
    create_research_worker,
    evaluate_design_proposal,
    execute_deep_research,
    query_workspace_rules,
    research_worker,
    save_research_report,
)
from workers.social import (
    SOCIAL_TOOLS,
    SOCIAL_WORKER_SYSTEM_PROMPT,
    create_social_worker,
    deploy_to_facebook_via_adb,
    deploy_to_youtube_api,
    log_social_telemetry,
    social_worker,
    validate_social_manifest,
)

# Global Worker Registry
WORKER_REGISTRY: Dict[str, Callable[[AgentState], Command]] = {
    "research_worker": research_worker,
    "social_worker": social_worker,
    "mobile_worker": mobile_worker,
}

# Aggregate Tools
ALL_TOOLS: List[BaseTool] = list(RESEARCH_TOOLS) + list(SOCIAL_TOOLS) + list(MOBILE_TOOLS)

__all__ = [
    # Base
    "create_worker_node",
    "execute_tool_call",
    # Research
    "create_research_worker",
    "research_worker",
    "RESEARCH_TOOLS",
    "RESEARCH_WORKER_SYSTEM_PROMPT",
    "execute_deep_research",
    "query_workspace_rules",
    "save_research_report",
    "evaluate_design_proposal",
    # Social
    "create_social_worker",
    "social_worker",
    "SOCIAL_TOOLS",
    "SOCIAL_WORKER_SYSTEM_PROMPT",
    "deploy_to_facebook_via_adb",
    "deploy_to_youtube_api",
    "validate_social_manifest",
    "log_social_telemetry",
    # Mobile
    "create_mobile_worker",
    "mobile_worker",
    "mobile_worker_node",
    "MOBILE_TOOLS",
    "MOBILE_WORKER_SYSTEM_PROMPT",
    "verify_device_connected",
    "execute_adb_shell",
    "send_android_intent",
    "uiautomator_tap_element",
    "inject_termux_command",
    "disable_samsung_autoblocker",
    "grant_app_permission",
    # Registries
    "WORKER_REGISTRY",
    "ALL_TOOLS",
]

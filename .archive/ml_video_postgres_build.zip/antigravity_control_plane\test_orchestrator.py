"""
Deterministic End-to-End Orchestrator Test Suite for Antigravity Control Plane (Milestone M4).

Mandated by ORIGINAL_REQUEST.md (§Verification Resources, lines 89-98) & TEST_INFRA.md:
1. Programmatically verifies Supervisor logic by mocking worker nodes and asserting routing state machine:
   - "Deploy this to Facebook" -> delegates to Social Worker
   - "Click the button in Termux" -> delegates to Mobile Worker
   - "Validate our design proposal" -> delegates to Research Worker
   - Finish / completed tasks -> terminates at END
2. Strict inter-worker isolation:
   - Worker agents cannot talk to each other directly; they return output via Command(update={...}, goto='supervisor')
   - AST analysis and StateGraph topology validation proving Hub-and-Spoke architecture
3. Anti-infinite-loop safety recursion guard:
   - Prevents infinite loops and terminates gracefully at max_iterations with status='TERMINATED_LOOP_LIMIT'
4. Single Entrypoint validation:
   - Workspace contains exactly ONE entrypoint orchestrator script (supervisor.py)
5. 5-Tier Test Architecture:
   - Tier 1: Feature Coverage (Decision schemas, Decision-First routing, Hub-and-Spoke topology)
   - Tier 2: Boundary & Corner Cases (Loop recursion limits, empty inputs, malformed outputs)
   - Tier 3: Cross-Feature Combinations & Checkpointer Persistence (Sync & Async checkpointers)
   - Tier 4: Real-World Application Scenarios (Social, Mobile, Research, Multi-turn workflows)
   - Tier 5: Adversarial Hardening & Stress Testing (LLM faults, concurrency, corrupted state recovery)
"""

from __future__ import annotations

import ast
import asyncio
from concurrent.futures import ThreadPoolExecutor
import inspect
import os
from pathlib import Path
import sys
from typing import Any, Callable, Dict, List, Optional, Sequence, Tuple
from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from langchain_core.language_models.chat_models import BaseChatModel
from langchain_core.messages import AIMessage, BaseMessage, HumanMessage, SystemMessage, ToolMessage
from langchain_core.outputs import ChatGeneration, ChatResult
from langchain_core.runnables import Runnable
from langgraph.checkpoint.base import BaseCheckpointSaver
from langgraph.checkpoint.memory import MemorySaver
from langgraph.checkpoint.postgres import PostgresSaver
from langgraph.checkpoint.postgres.aio import AsyncPostgresSaver
from langgraph.graph import END, START, StateGraph
from langgraph.types import Command
from pydantic import BaseModel, ValidationError

# Ensure project root is in sys.path
PROJECT_ROOT = Path(__file__).resolve().parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from db import create_async_connection_pool, create_connection_pool, get_async_checkpointer, get_checkpointer
from prompts import SUPERVISOR_SYSTEM_PROMPT
from schemas import (
    ControlPlaneConfig,
    RoutingDecision,
    SupervisorDecisionLog,
    WorkerHandoffPayload,
)
from state import AgentState, create_history_entry, create_initial_state, prune_message_history
from supervisor import (
    VALID_ROUTING_TARGETS,
    async_run_control_plane,
    create_control_plane_graph,
    create_supervisor_node,
    deterministic_fallback_router,
    run_control_plane,
    supervisor_node,
)
from workers import (
    ALL_TOOLS,
    MOBILE_TOOLS,
    RESEARCH_TOOLS,
    SOCIAL_TOOLS,
    WORKER_REGISTRY,
    create_mobile_worker,
    create_research_worker,
    create_social_worker,
    mobile_worker,
    research_worker,
    social_worker,
)


# ============================================================================
# DETERMINISTIC MOCK LLM HARNESS
# ============================================================================


class MockStructuredChatModel(BaseChatModel):
    """
    Deterministic mock chat model supporting `with_structured_output` and `bind_tools`.
    Supports FIFO response queuing, dynamic response callbacks, and exception injection.
    """

    responses: List[Any] = []
    dynamic_responder: Optional[Callable[[List[BaseMessage]], Any]] = None

    def __init__(
        self,
        responses: Optional[List[Any]] = None,
        dynamic_responder: Optional[Callable[[List[BaseMessage]], Any]] = None,
        **kwargs: Any,
    ) -> None:
        super().__init__(
            responses=list(responses) if responses is not None else [],
            dynamic_responder=dynamic_responder,
            **kwargs,
        )

    @property
    def _llm_type(self) -> str:
        return "mock-structured-chat-orchestrator"

    def _generate(
        self,
        messages: List[BaseMessage],
        stop: Optional[List[str]] = None,
        run_manager: Optional[Any] = None,
        **kwargs: Any,
    ) -> ChatResult:
        if not self.responses:
            msg = AIMessage(content="Default mock text response")
            return ChatResult(generations=[ChatGeneration(message=msg)])

        resp = self.responses.pop(0) if self.responses else "Default mock text"
        if isinstance(resp, Exception):
            raise resp
        if isinstance(resp, BaseMessage):
            msg = resp
        elif isinstance(resp, dict):
            msg = AIMessage(content=resp.get("content", ""), tool_calls=resp.get("tool_calls", []))
        else:
            msg = AIMessage(content=str(resp))
        return ChatResult(generations=[ChatGeneration(message=msg)])

    def with_structured_output(self, schema: Any, **kwargs: Any) -> Runnable:
        parent = self

        class StructuredMockRunnable(Runnable):
            def invoke(self, input_val: Any, config: Optional[Any] = None) -> Any:
                if parent.dynamic_responder is not None:
                    msgs = input_val if isinstance(input_val, list) else [input_val]
                    res = parent.dynamic_responder(msgs)
                    if isinstance(res, Exception):
                        raise res
                    if isinstance(res, dict):
                        return schema(**res)
                    return res

                if not parent.responses:
                    return RoutingDecision(
                        next_node="FINISH",
                        reasoning="Default mock completion from structured model.",
                        instructions="Task finished.",
                    )

                resp = parent.responses.pop(0)
                if isinstance(resp, Exception):
                    raise resp
                if isinstance(resp, dict):
                    return schema(**resp)
                return resp

            async def ainvoke(self, input_val: Any, config: Optional[Any] = None) -> Any:
                return self.invoke(input_val, config)

        return StructuredMockRunnable()

    def bind_tools(self, tools: Sequence[Any], **kwargs: Any) -> Any:
        return self


# ============================================================================
# ARCHITECTURAL INTEGRITY & WORKSPACE COMPLIANCE TESTS
# ============================================================================


class TestArchitecturalIntegrity:
    """Verifies single entrypoint, worker isolation, and graph topology rules."""

    def test_workspace_contains_exactly_one_entrypoint_orchestrator(self) -> None:
        """
        Acceptance Criteria: Workspace contains exactly ONE entrypoint orchestrator script (supervisor.py).
        Ensures no duplicate or fragmented orchestrator scripts exist in the root or workers dir.
        """
        forbidden_entrypoints = [
            "orchestrator.py",
            "main.py",
            "agent_runner.py",
            "router.py",
            "control_plane.py",
            "app.py",
        ]
        for script_name in forbidden_entrypoints:
            target_path = PROJECT_ROOT / script_name
            assert not target_path.exists(), f"Found forbidden duplicate orchestrator script: {target_path}"

        # Ensure supervisor.py exists at project root
        canonical_entrypoint = PROJECT_ROOT / "supervisor.py"
        assert canonical_entrypoint.exists(), "supervisor.py must exist at project root as canonical entrypoint."

        # Verify supervisor.py contains executable entrypoint functions and __main__ block
        supervisor_content = canonical_entrypoint.read_text(encoding="utf-8")
        assert "create_control_plane_graph" in supervisor_content
        assert "run_control_plane" in supervisor_content
        assert "async_run_control_plane" in supervisor_content
        assert 'if __name__ == "__main__":' in supervisor_content or "if __name__ == '__main__':" in supervisor_content

    def test_inter_worker_isolation_ast_analysis(self) -> None:
        """
        Acceptance Criteria: Worker agents cannot talk to each other directly; they return
        their output to the global state via Command(update={...}, goto='supervisor').
        Performs static AST inspection on all worker implementation modules.
        """
        workers_dir = PROJECT_ROOT / "workers"
        worker_files = [f for f in workers_dir.glob("*.py") if f.name != "__init__.py"]
        assert len(worker_files) >= 3, "Worker modules must include base.py, social.py, mobile.py, research.py"

        for worker_file in worker_files:
            source = worker_file.read_text(encoding="utf-8")
            tree = ast.parse(source, filename=str(worker_file))

            # Scan AST for Command(..., goto="...") calls
            for node in ast.walk(tree):
                if isinstance(node, ast.Call):
                    # Check if call is Command(...)
                    func_id = getattr(node.func, "id", None)
                    if func_id == "Command":
                        goto_kwarg = None
                        for kw in node.keywords:
                            if kw.arg == "goto":
                                if isinstance(kw.value, ast.Constant):
                                    goto_kwarg = kw.value.value
                        if goto_kwarg is not None:
                            assert goto_kwarg == "supervisor", (
                                f"Worker in {worker_file.name} attempted forbidden direct goto: '{goto_kwarg}'. "
                                f"Workers MUST strictly return goto='supervisor'."
                            )

    def test_stategraph_topology_hub_and_spoke_isolation(self) -> None:
        """
        Verifies compiled StateGraph topology enforces Hub-and-Spoke isolation.
        START -> supervisor, and all worker nodes return to supervisor.
        """
        graph = create_control_plane_graph(testing=True)
        nodes = graph.nodes

        assert "supervisor" in nodes
        assert "social_worker" in nodes
        assert "mobile_worker" in nodes
        assert "research_worker" in nodes

        # Check that START connects to supervisor
        start_edges = [edge for edge in getattr(graph, "edges", []) if edge[0] == START]
        if start_edges:
            assert any(dst == "supervisor" for _, dst in start_edges)


# ============================================================================
# TIER 1: FEATURE COVERAGE & INTENT DELEGATION TESTS
# ============================================================================


class TestTier1IntentDelegation:
    """Tier 1: Programmatically verifies intent routing to Social, Mobile, Research, and FINISH."""

    def test_route_intent_deploy_to_facebook_delegates_to_social_worker(self) -> None:
        """
        ORIGINAL_REQUEST requirement: 'Deploy this to Facebook' -> Social Worker.
        """
        state = create_initial_state(user_input="Deploy this to Facebook")
        decision = deterministic_fallback_router(state)
        assert decision.next_node == "social_worker"

        # Verify with supervisor node execution
        sup_node = create_supervisor_node()
        cmd = sup_node(state)
        assert isinstance(cmd, Command)
        assert cmd.goto == "social_worker"
        assert cmd.update["next_worker"] == "social_worker"
        assert cmd.update["status"] == "RUNNING"

    def test_route_intent_social_variants(self) -> None:
        """Verifies routing for YouTube, campaign manifests, and marketing videos."""
        variants = [
            "Publish video asset to YouTube",
            "Deploy marketing video to Facebook and log telemetry",
            "Execute social campaign manifest",
        ]
        for prompt in variants:
            state = create_initial_state(user_input=prompt)
            decision = deterministic_fallback_router(state)
            assert decision.next_node == "social_worker", f"Failed to route social prompt: {prompt}"

    def test_route_intent_click_button_in_termux_delegates_to_mobile_worker(self) -> None:
        """
        ORIGINAL_REQUEST requirement: 'Click the button in Termux' -> Mobile Worker.
        """
        state = create_initial_state(user_input="Click the button in Termux")
        decision = deterministic_fallback_router(state)
        assert decision.next_node == "mobile_worker"

        sup_node = create_supervisor_node()
        cmd = sup_node(state)
        assert isinstance(cmd, Command)
        assert cmd.goto == "mobile_worker"
        assert cmd.update["next_worker"] == "mobile_worker"
        assert cmd.update["status"] == "RUNNING"

    def test_route_intent_mobile_variants(self) -> None:
        """Verifies routing for ADB shell, Samsung autoblocker, and UI tree inspection."""
        variants = [
            "Execute adb shell tap 500 1000 on android device",
            "Disable Samsung AutoBlocker via mobile automation",
            "Verify UI tree on mobile device",
            "Send android intent broadcast to termux",
        ]
        for prompt in variants:
            state = create_initial_state(user_input=prompt)
            decision = deterministic_fallback_router(state)
            assert decision.next_node == "mobile_worker", f"Failed to route mobile prompt: {prompt}"

    def test_route_intent_validate_design_proposal_delegates_to_research_worker(self) -> None:
        """
        ORIGINAL_REQUEST requirement: 'Validate our design proposal' -> Research Worker.
        """
        state = create_initial_state(user_input="Validate our design proposal")
        decision = deterministic_fallback_router(state)
        assert decision.next_node == "research_worker"

        sup_node = create_supervisor_node()
        cmd = sup_node(state)
        assert isinstance(cmd, Command)
        assert cmd.goto == "research_worker"
        assert cmd.update["next_worker"] == "research_worker"
        assert cmd.update["status"] == "RUNNING"

    def test_route_intent_research_variants(self) -> None:
        """Verifies routing for rules queries, deep research, and trend benchmarks."""
        variants = [
            "Query workspace rules and check architectural compliance",
            "Execute deep research on sports card trend analytics",
            "Benchmark architecture proposal against system constraints",
        ]
        for prompt in variants:
            state = create_initial_state(user_input=prompt)
            decision = deterministic_fallback_router(state)
            assert decision.next_node == "research_worker", f"Failed to route research prompt: {prompt}"

    def test_route_finish_terminates_at_end(self) -> None:
        """Verifies that finished tasks transition to END with status COMPLETED."""
        mock_llm = MockStructuredChatModel(
            responses=[
                RoutingDecision(
                    next_node="FINISH",
                    reasoning="Task has achieved all goals.",
                    instructions="Workflow complete.",
                )
            ]
        )
        sup_node = create_supervisor_node(llm=mock_llm)
        state = create_initial_state(user_input="Done with everything")

        cmd = sup_node(state)
        assert isinstance(cmd, Command)
        assert cmd.goto == END
        assert cmd.update["status"] == "COMPLETED"
        assert cmd.update["next_worker"] is None
        assert cmd.update["summary"] == "Workflow complete."

    def test_decision_first_structured_output_mode(self) -> None:
        """
        ORIGINAL_REQUEST requirement: Supervisor MUST use with_structured_output to classify
        intent and select the destination. It must NOT use tool calling for routing.
        """
        mock_llm = MockStructuredChatModel(
            responses=[
                RoutingDecision(
                    next_node="social_worker",
                    reasoning="Classified via structured output without tools",
                    instructions="Execute social dispatch",
                )
            ]
        )
        sup_node = create_supervisor_node(llm=mock_llm)
        state = create_initial_state(user_input="Deploy to Facebook")
        cmd = sup_node(state)
        assert cmd.goto == "social_worker"


# ============================================================================
# TIER 2: BOUNDARY & CORNER CASES (RECURSION GUARD & EDGE INPUTS)
# ============================================================================


class TestTier2BoundaryAndRecursionGuard:
    """Tier 2: Boundary conditions, loop recursion safety, and edge inputs."""

    def test_recursion_guard_stops_at_max_iterations(self) -> None:
        """
        Acceptance Criteria: DAG routing works without infinite loops.
        When iteration_count >= max_iterations, supervisor forces goto=END with TERMINATED_LOOP_LIMIT.
        """
        sup_node = create_supervisor_node()
        state = create_initial_state(
            user_input="Degraded non-terminating task",
            max_iterations=5,
        )
        state["iteration_count"] = 5

        cmd = sup_node(state)
        assert isinstance(cmd, Command)
        assert cmd.goto == END
        assert cmd.update["status"] == "TERMINATED_LOOP_LIMIT"
        assert cmd.update["next_worker"] is None
        assert cmd.update["iteration_count"] == 6

        # Verify audit history logged termination
        history = cmd.update["execution_history"]
        assert len(history) == 1
        assert history[0]["action"] == "loop_guard_termination"
        assert history[0]["status"] == "TERMINATED_LOOP_LIMIT"

    def test_recursion_guard_custom_limits(self) -> None:
        """Verifies recursion guard operates correctly with various max_iterations settings."""
        for limit in [1, 3, 7, 15]:
            state = create_initial_state(user_input="Test loop", max_iterations=limit)
            state["iteration_count"] = limit
            sup_node = create_supervisor_node()
            cmd = sup_node(state)
            assert cmd.goto == END
            assert cmd.update["status"] == "TERMINATED_LOOP_LIMIT"

    def test_empty_user_intent_terminates_immediately(self) -> None:
        """Verifies empty user input produces FINISH and terminates at END."""
        state = create_initial_state(user_input="")
        sup_node = create_supervisor_node()
        cmd = sup_node(state)
        assert cmd.goto == END
        assert cmd.update["status"] == "COMPLETED"

    def test_whitespace_only_intent_handling(self) -> None:
        """Verifies whitespace-only input terminates safely without exceptions."""
        state = create_initial_state(user_input="   \n\t  ")
        sup_node = create_supervisor_node()
        cmd = sup_node(state)
        assert cmd.goto == END
        assert cmd.update["status"] == "COMPLETED"

    def test_invalid_destination_node_rejected(self) -> None:
        """Verifies that an unwhitelisted destination from LLM is rejected and halts safely."""
        bad_decision = MagicMock(
            next_node="unauthorized_worker_x",
            reasoning="malicious route",
            instructions="",
        )
        mock_llm = MockStructuredChatModel(
            dynamic_responder=lambda msgs: bad_decision
        )
        sup_node = create_supervisor_node(llm=mock_llm)
        state = create_initial_state(user_input="Deploy something")
        cmd = sup_node(state)
        assert cmd.goto == END
        assert cmd.update["status"] == "FAILED"
        assert "Invalid target node rejected" in cmd.update["execution_history"][0]["error"]

    def test_malformed_llm_payload_engages_fallback(self) -> None:
        """Verifies that when structured output returns None or unparseable object, fallback handles it."""
        mock_llm = MockStructuredChatModel(responses=["unexpected string response"])
        sup_node = create_supervisor_node(llm=mock_llm)
        state = create_initial_state(user_input="Deploy this to Facebook")
        cmd = sup_node(state)
        # Should fallback to deterministic router -> social_worker
        assert cmd.goto == "social_worker"


# ============================================================================
# TIER 3: CROSS-FEATURE COMBINATIONS & STATE PERSISTENCE TESTS
# ============================================================================


class TestTier3CombinationsAndStatePersistence:
    """Tier 3: Multi-worker sequences, state reducers, and checkpointer persistence."""

    def test_pairwise_routing_sequence_research_to_social_to_mobile(self) -> None:
        """
        Verifies multi-stage state progression across all workers via Supervisor Hub-and-Spoke.
        """
        # 1. Start with multi-domain intent
        state = create_initial_state(
            user_input="Research workspace rules, deploy to Facebook, and verify in Termux"
        )
        sup_node = create_supervisor_node()

        # Turn 1: Supervisor routes to research_worker
        cmd1 = sup_node(state)
        assert cmd1.goto == "research_worker"

        # Simulate research_worker completion returning to supervisor
        state["execution_history"] = [
            create_history_entry(
                node="research_worker",
                action="deep_research",
                status="SUCCESS",
                details={},
            )
        ]
        state["iteration_count"] = cmd1.update["iteration_count"]

        # Turn 2: Supervisor routes to social_worker
        cmd2 = sup_node(state)
        assert cmd2.goto == "social_worker"

        # Simulate social_worker completion returning to supervisor
        state["execution_history"].append(
            create_history_entry(
                node="social_worker",
                action="adb_deploy",
                status="SUCCESS",
                details={},
            )
        )
        state["iteration_count"] = cmd2.update["iteration_count"]

        # Turn 3: Supervisor routes to mobile_worker
        cmd3 = sup_node(state)
        assert cmd3.goto == "mobile_worker"

        # Simulate mobile_worker completion returning to supervisor
        state["execution_history"].append(
            create_history_entry(
                node="mobile_worker",
                action="termux_verify",
                status="SUCCESS",
                details={},
            )
        )
        state["iteration_count"] = cmd3.update["iteration_count"]

        # Turn 4: All workers executed -> Supervisor routes to FINISH / END
        cmd4 = sup_node(state)
        assert cmd4.goto == END
        assert cmd4.update["status"] == "COMPLETED"

    def test_sync_checkpointer_memory_saver_persistence(self) -> None:
        """Verifies state persistence across turns using MemorySaver checkpointer."""
        checkpointer = MemorySaver()
        graph = create_control_plane_graph(checkpointer=checkpointer, testing=True)
        config = {"configurable": {"thread_id": "persistence_thread_1"}}

        initial_state = create_initial_state(user_input="Deploy this to Facebook")
        result = graph.invoke(initial_state, config=config)
        assert result["status"] in ("COMPLETED", "RUNNING")
        assert result["iteration_count"] >= 1

        # Retrieve saved checkpoint
        checkpoint = checkpointer.get(config)
        assert checkpoint is not None
        assert checkpoint["channel_values"]["task_intent"] == "Deploy this to Facebook"

    def test_sync_checkpointer_postgres_saver_mock(self) -> None:
        """Verifies StateGraph compilation and execution with mock PostgresSaver checkpointer."""
        from psycopg import Connection
        from psycopg_pool import ConnectionPool

        mock_pool = MagicMock(spec=ConnectionPool)
        mock_conn = MagicMock(spec=Connection)
        mock_cursor = MagicMock()
        mock_pool.closed = False
        mock_pool.connection.return_value.__enter__.return_value = mock_conn
        mock_pool.connection.return_value.__exit__.return_value = None
        mock_conn.cursor.return_value.__enter__.return_value = mock_cursor
        mock_conn.cursor.return_value.__exit__.return_value = None
        mock_cursor.fetchone.return_value = {"v": -1}

        pg_saver = PostgresSaver(mock_pool)
        graph = create_control_plane_graph(checkpointer=pg_saver)
        assert graph is not None

    @pytest.mark.asyncio
    async def test_async_checkpointer_async_postgres_saver_mock(self) -> None:
        """Verifies StateGraph compilation with mock AsyncPostgresSaver checkpointer."""
        from psycopg import AsyncConnection
        from psycopg_pool import AsyncConnectionPool

        mock_apool = MagicMock(spec=AsyncConnectionPool)
        mock_aconn = MagicMock(spec=AsyncConnection)
        mock_acursor = MagicMock()
        mock_apool.closed = False
        mock_acursor.execute = AsyncMock()
        mock_acursor.fetchone = AsyncMock(return_value={"v": -1})
        mock_aconn.cursor.return_value.__aenter__ = AsyncMock(return_value=mock_acursor)
        mock_aconn.cursor.return_value.__aexit__ = AsyncMock(return_value=None)
        mock_apool.connection.return_value.__aenter__ = AsyncMock(return_value=mock_aconn)
        mock_apool.connection.return_value.__aexit__ = AsyncMock(return_value=None)

        async_pg_saver = AsyncPostgresSaver(mock_apool)
        graph = create_control_plane_graph(checkpointer=async_pg_saver)
        assert graph is not None


# ============================================================================
# TIER 4: REAL-WORLD APPLICATION SCENARIOS
# ============================================================================


class TestTier4RealWorldWorkflows:
    """Tier 4: End-to-End realistic user workflows exercising full StateGraph."""

    def test_e2e_scenario_1_social_campaign_deployment(self) -> None:
        """
        Scenario 1: 'Deploy this video asset to Facebook and log telemetry'
        Tests full graph traversal: Supervisor -> Social Worker -> Tools -> Supervisor -> END.
        """
        result = run_control_plane(
            user_input="Deploy this video asset to Facebook and log telemetry",
            thread_id="e2e_social_thread",
            testing=True,
            max_iterations=10,
        )
        assert result["status"] == "COMPLETED"
        assert result["iteration_count"] >= 2
        history_nodes = [e.get("node") for e in result.get("execution_history", []) if isinstance(e, dict)]
        assert "supervisor" in history_nodes
        assert "social_worker" in history_nodes

    def test_e2e_scenario_2_mobile_termux_automation(self) -> None:
        """
        Scenario 2: 'Click the confirm button in Termux and verify UI tree'
        Tests full graph traversal: Supervisor -> Mobile Worker -> ADB Tools -> Supervisor -> END.
        """
        result = run_control_plane(
            user_input="Click the confirm button in Termux and verify UI tree",
            thread_id="e2e_mobile_thread",
            testing=True,
            max_iterations=10,
        )
        assert result["status"] == "COMPLETED"
        assert result["iteration_count"] >= 2
        history_nodes = [e.get("node") for e in result.get("execution_history", []) if isinstance(e, dict)]
        assert "supervisor" in history_nodes
        assert "mobile_worker" in history_nodes

    def test_e2e_scenario_3_deep_research_proposal_validation(self) -> None:
        """
        Scenario 3: 'Validate our design proposal against workspace rules'
        Tests full graph traversal: Supervisor -> Research Worker -> Rules/Eval Tools -> Supervisor -> END.
        """
        result = run_control_plane(
            user_input="Validate our design proposal against workspace rules",
            thread_id="e2e_research_thread",
            testing=True,
            max_iterations=10,
        )
        assert result["status"] == "COMPLETED"
        assert result["iteration_count"] >= 2
        history_nodes = [e.get("node") for e in result.get("execution_history", []) if isinstance(e, dict)]
        assert "supervisor" in history_nodes
        assert "research_worker" in history_nodes

    def test_e2e_scenario_4_multi_step_hybrid_orchestration(self) -> None:
        """
        Scenario 4: Multi-stage campaign involving Research, Social, and Mobile workers.
        """
        result = run_control_plane(
            user_input="Research workspace rules, publish video asset to YouTube, and verify in Termux",
            thread_id="e2e_hybrid_thread",
            testing=True,
            max_iterations=10,
        )
        assert result["status"] == "COMPLETED"
        history_nodes = {e.get("node") for e in result.get("execution_history", []) if isinstance(e, dict)}
        assert "supervisor" in history_nodes
        assert "research_worker" in history_nodes
        assert "social_worker" in history_nodes
        assert "mobile_worker" in history_nodes

    def test_e2e_scenario_5_anti_loop_exhaustion(self) -> None:
        """
        Scenario 5: Degraded non-converging worker loop safely stopped by recursion guard.
        """
        # Create a custom mock supervisor that constantly loops to social_worker
        mock_llm = MockStructuredChatModel(
            dynamic_responder=lambda msgs: RoutingDecision(
                next_node="social_worker",
                reasoning="Looping intent",
                instructions="Keep running",
            )
        )
        result = run_control_plane(
            user_input="Infinite loop test",
            thread_id="e2e_loop_thread",
            llm=mock_llm,
            max_iterations=4,
            testing=True,
        )
        assert result["status"] == "TERMINATED_LOOP_LIMIT"
        assert result["iteration_count"] >= 4


# ============================================================================
# TIER 5: ADVERSARIAL HARDENING & STRESS TESTING
# ============================================================================


class TestTier5AdversarialHardening:
    """Tier 5: White-box fault injection, corrupted state recovery, and concurrency stress testing."""

    def test_adversarial_llm_api_exception_fallback(self) -> None:
        """Verifies graph gracefully falls back to deterministic router on LLM API 503 error."""
        failing_llm = MockStructuredChatModel(
            responses=[RuntimeError("503 Service Unavailable: Rate limit exceeded")]
        )
        result = run_control_plane(
            user_input="Deploy this to Facebook",
            thread_id="adversarial_503_thread",
            llm=failing_llm,
            testing=True,
        )
        # Should gracefully recover via deterministic router
        assert result["status"] == "COMPLETED"

    def test_adversarial_corrupted_state_recovery(self) -> None:
        """Verifies graph survives corrupted state missing standard keys."""
        sup_node = create_supervisor_node()
        corrupted_state = {"messages": []}  # Missing iteration_count, max_iterations, task_intent

        cmd = sup_node(corrupted_state)  # type: ignore[arg-type]
        assert isinstance(cmd, Command)
        assert cmd.goto in (END, "social_worker", "mobile_worker", "research_worker")

    def test_adversarial_concurrent_thread_isolation(self) -> None:
        """Verifies 10 parallel execution threads maintain strict thread isolation."""
        thread_ids = [f"concurrent_thread_{i}" for i in range(10)]
        inputs = [
            ("Deploy this to Facebook", "social_worker"),
            ("Click the button in Termux", "mobile_worker"),
            ("Validate our design proposal", "research_worker"),
        ]

        def _execute(idx: int) -> Dict[str, Any]:
            prompt, _ = inputs[idx % len(inputs)]
            return run_control_plane(
                user_input=prompt,
                thread_id=thread_ids[idx],
                testing=True,
                max_iterations=6,
            )

        with ThreadPoolExecutor(max_workers=5) as executor:
            results = list(executor.map(_execute, range(10)))

        assert len(results) == 10
        for r in results:
            assert r["status"] == "COMPLETED"
            assert r["iteration_count"] >= 1

    def test_adversarial_rapid_graph_recompilation(self) -> None:
        """Verifies rapid compilation of StateGraph instances without memory leaks or race conditions."""
        graphs = [create_control_plane_graph(testing=True) for _ in range(20)]
        assert len(graphs) == 20
        for g in graphs:
            assert "supervisor" in g.nodes

    @pytest.mark.asyncio
    async def test_adversarial_async_execution_wrapper(self) -> None:
        """Verifies asynchronous execution wrapper async_run_control_plane."""
        result = await async_run_control_plane(
            user_input="Deploy this to Facebook",
            thread_id="async_test_thread",
            testing=True,
        )
        assert result["status"] == "COMPLETED"
        assert result["iteration_count"] >= 2

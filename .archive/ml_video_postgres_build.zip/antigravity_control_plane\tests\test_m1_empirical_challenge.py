"""
Empirical Challenge Test Suite for Milestone M1 (State Management & Database Pool).

Adversarial Stress Harness:
1. Malformed state schemas, missing keys, invalid message objects, and extreme recursion numbers.
2. Connection pool timeout simulations, database failure fallbacks, and parameter edge cases.
3. LangGraph StateGraph recursion limits, checkpoint serialization, and high concurrency thread isolation.
"""

from __future__ import annotations

import asyncio
import os
from typing import Any, Dict, List, Optional
from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from langchain_core.messages import (
    AIMessage,
    BaseMessage,
    ChatMessage,
    FunctionMessage,
    HumanMessage,
    RemoveMessage,
    SystemMessage,
    ToolMessage,
)
from langgraph.checkpoint.base import BaseCheckpointSaver
from langgraph.checkpoint.memory import MemorySaver
from langgraph.checkpoint.postgres import PostgresSaver
from langgraph.checkpoint.postgres.aio import AsyncPostgresSaver
from langgraph.errors import GraphRecursionError
from langgraph.graph import END, START, StateGraph
from psycopg import AsyncConnection, Connection, OperationalError
from psycopg.rows import dict_row
from psycopg_pool import AsyncConnectionPool, ConnectionPool, PoolClosed, PoolTimeout
from pydantic import ValidationError

from db import (
    DEFAULT_KWARGS,
    DEFAULT_MAX_POOL_SIZE,
    DEFAULT_MIN_POOL_SIZE,
    close_async_connection_pool,
    close_connection_pool,
    create_async_connection_pool,
    create_connection_pool,
    get_async_checkpointer,
    get_checkpointer,
)
from state import (
    AgentState,
    AgentStateValidator,
    create_history_entry,
    create_initial_state,
    format_state_summary,
    prune_intermediate_scratchpad,
    prune_message_history,
)

SAMPLE_PG_URI = "postgresql://challenger_user:challenger_pass@localhost:5432/challenger_db"


# ============================================================================
# CHALLENGE SUITE 1: Malformed State Schemas, Missing Keys & Partial Updates
# ============================================================================

def test_challenge_stategraph_partial_state_updates():
    """Verify that nodes returning partial dictionaries do not wipe or corrupt other state keys."""
    builder = StateGraph(AgentState)

    def node_init(state: AgentState) -> Dict[str, Any]:
        return {
            "task_intent": "INIT_INTENT",
            "summary": "Initial summary",
            "iteration_count": 1,
            "status": "RUNNING",
        }

    def node_partial_messages_only(state: AgentState) -> Dict[str, Any]:
        return {"messages": [AIMessage(content="Partial update 1", id="ai_p1")]}

    def node_partial_history_only(state: AgentState) -> Dict[str, Any]:
        return {"execution_history": [create_history_entry("node_history", "audit_action")]}

    def node_partial_scalars_only(state: AgentState) -> Dict[str, Any]:
        return {"iteration_count": state["iteration_count"] + 1, "status": "COMPLETED"}

    builder.add_node("init", node_init)
    builder.add_node("step_msg", node_partial_messages_only)
    builder.add_node("step_hist", node_partial_history_only)
    builder.add_node("step_scalar", node_partial_scalars_only)

    builder.add_edge(START, "init")
    builder.add_edge("init", "step_msg")
    builder.add_edge("step_msg", "step_hist")
    builder.add_edge("step_hist", "step_scalar")
    builder.add_edge("step_scalar", END)

    graph = builder.compile()
    initial_state = create_initial_state(user_input="Test partial updates")

    result = graph.invoke(initial_state)

    # Invariants verification:
    assert result["task_intent"] == "INIT_INTENT"
    assert result["summary"] == "Initial summary"
    assert len(result["messages"]) == 2  # HumanMessage + AIMessage
    assert result["messages"][0].content == "Test partial updates"
    assert result["messages"][1].content == "Partial update 1"
    assert len(result["execution_history"]) == 1
    assert result["execution_history"][0]["node"] == "node_history"
    assert result["iteration_count"] == 2
    assert result["status"] == "COMPLETED"


def test_challenge_create_initial_state_none_and_type_fuzzing():
    """Fuzz create_initial_state with None values, empty types, and non-standard types."""
    # None user_input and None task_intent
    state_none = create_initial_state(user_input=None, task_intent=None)
    assert state_none["task_intent"] is None or state_none["task_intent"] == ""
    assert state_none["messages"] == []
    assert state_none["execution_history"] == []
    assert state_none["iteration_count"] == 0

    # Custom kwargs injection
    state_custom = create_initial_state(
        "Deploy",
        custom_metadata={"run_id": "12345"},
        arbitrary_flag=True,
    )
    assert state_custom["task_intent"] == "Deploy"
    assert len(state_custom["messages"]) == 1


def test_challenge_message_replacement_and_deduplication_by_id():
    """Verify add_messages reducer updates existing messages with identical IDs rather than appending duplicates."""
    builder = StateGraph(AgentState)

    def node_produce(state: AgentState) -> Dict[str, Any]:
        return {"messages": [AIMessage(content="Draft message", id="same_id")]}

    def node_replace(state: AgentState) -> Dict[str, Any]:
        return {"messages": [AIMessage(content="Final revised message", id="same_id")]}

    builder.add_node("produce", node_produce)
    builder.add_node("replace", node_replace)
    builder.add_edge(START, "produce")
    builder.add_edge("produce", "replace")
    builder.add_edge("replace", END)

    graph = builder.compile()
    init_state = create_initial_state("Start")

    result = graph.invoke(init_state)

    # Should have 2 messages total: initial HumanMessage + updated AIMessage (NOT 3)
    assert len(result["messages"]) == 2
    assert result["messages"][1].id == "same_id"
    assert result["messages"][1].content == "Final revised message"


def test_challenge_remove_message_validation():
    """Verify that LangGraph add_messages reducer enforces existing message IDs for RemoveMessage."""
    builder = StateGraph(AgentState)

    def node_invalid_remove(state: AgentState) -> Dict[str, Any]:
        return {"messages": [RemoveMessage(id="non_existent_id_99999")]}

    builder.add_node("remove_ghost", node_invalid_remove)
    builder.add_edge(START, "remove_ghost")
    builder.add_edge("remove_ghost", END)

    graph = builder.compile()
    init_state = create_initial_state("Keep me alive")

    # In LangGraph, attempting to remove an ID that doesn't exist raises ValueError
    with pytest.raises(ValueError, match="Attempting to delete a message with an ID that doesn't exist"):
        graph.invoke(init_state)


def test_challenge_heterogeneous_message_types():
    """Verify state handles ChatMessage, SystemMessage, ToolMessage, FunctionMessage, AIMessage, HumanMessage."""
    builder = StateGraph(AgentState)

    def node_heterogeneous(state: AgentState) -> Dict[str, Any]:
        return {
            "messages": [
                SystemMessage(content="System prompt", id="sys_1"),
                ChatMessage(role="assistant", content="Custom role assistant", id="chat_1"),
                FunctionMessage(name="func_name", content="func output", id="fn_1"),
                ToolMessage(content="tool output", tool_call_id="call_99", id="tool_1"),
            ]
        }

    builder.add_node("inject", node_heterogeneous)
    builder.add_edge(START, "inject")
    builder.add_edge("inject", END)

    graph = builder.compile()
    result = graph.invoke(create_initial_state("Initial"))

    assert len(result["messages"]) == 5  # 1 Human + 4 injected


# ============================================================================
# CHALLENGE SUITE 2: Boundary Value Analysis & Extreme Recursion Numbers
# ============================================================================

@pytest.mark.parametrize("max_messages,preserve_first_n", [
    (0, 0),
    (1, 0),
    (1, 1),
    (2, 5),
    (100, 50),
    (-1, -1),
    (-10, 5),
    (5, -10),
])
def test_challenge_prune_message_history_boundary_combinations(max_messages, preserve_first_n):
    """Stress test prune_message_history across wild combinations of negative, zero, and huge values."""
    msgs = [HumanMessage(content=f"msg_{i}", id=f"id_{i}") for i in range(10)]
    removals = prune_message_history(msgs, max_messages=max_messages, preserve_first_n=preserve_first_n)

    assert isinstance(removals, list)
    for r in removals:
        assert isinstance(r, RemoveMessage)
        assert r.id.startswith("id_")


def test_challenge_prune_scratchpad_malformed_tool_calls():
    """Verify prune_intermediate_scratchpad handles AIMessages with None or strange tool_calls safely."""
    msg_none_tool = AIMessage(content="Regular response", id="ai_1", tool_calls=[])
    msg_with_tool = AIMessage(content="Tool call", id="ai_2", tool_calls=[{"name": "test", "args": {}, "id": "c1"}])
    msg_without_id = AIMessage(content="No id tool call", tool_calls=[{"name": "test", "args": {}, "id": "c2"}])
    tool_msg_no_id = ToolMessage(content="No id", tool_call_id="c2")
    tool_msg_valid = ToolMessage(content="Valid", tool_call_id="c1", id="tm_valid")

    msgs = [msg_none_tool, msg_with_tool, msg_without_id, tool_msg_no_id, tool_msg_valid]
    removals = prune_intermediate_scratchpad(msgs)

    # Only msg_with_tool and tool_msg_valid have IDs and are eligible for removal
    assert len(removals) == 2
    assert {r.id for r in removals} == {"ai_2", "tm_valid"}


def test_challenge_format_state_summary_corrupted_types():
    """Verify format_state_summary does not throw uncaught exceptions on malformed dict inputs."""
    corrupted_states = [
        {},
        {"task_intent": None, "status": None, "iteration_count": None, "max_iterations": None},
        {"execution_history": None, "messages": None},
        {"iteration_count": "99", "max_iterations": "100"},
        {"task_intent": 12345, "status": False},
    ]
    for state in corrupted_states:
        summary = format_state_summary(state)  # type: ignore
        assert isinstance(summary, str)
        assert len(summary) > 0


@pytest.mark.parametrize("invalid_status", [
    "ACTIVE",
    "DEGRADED",
    "FINISHED",
    "CRASHED",
    "ERROR",
    "",
])
def test_challenge_state_validator_status_enum_strictness(invalid_status):
    """Verify AgentStateValidator strictly rejects unauthorized status strings."""
    with pytest.raises(ValidationError):
        AgentStateValidator(task_intent="Intent", status=invalid_status)


def test_challenge_state_validator_extreme_iterations():
    """Verify AgentStateValidator constraints on iteration bounds."""
    # max_iterations <= 0 should fail
    with pytest.raises(ValidationError):
        AgentStateValidator(task_intent="Intent", max_iterations=0)

    with pytest.raises(ValidationError):
        AgentStateValidator(task_intent="Intent", max_iterations=-100)

    # iteration_count < 0 should fail
    with pytest.raises(ValidationError):
        AgentStateValidator(task_intent="Intent", iteration_count=-1)

    # Large values within range should succeed
    val = AgentStateValidator(task_intent="Intent", iteration_count=100000, max_iterations=1000000)
    assert val.iteration_count == 100000


def test_challenge_extreme_recursion_limit_in_stategraph():
    """Stress test StateGraph execution against LangGraph recursion limits (recursion_limit=5 vs 100)."""
    builder = StateGraph(AgentState)

    def looping_node(state: AgentState) -> Dict[str, Any]:
        return {
            "iteration_count": state["iteration_count"] + 1,
            "execution_history": [create_history_entry("loop", f"iter_{state['iteration_count']}")],
        }

    builder.add_node("loop", looping_node)
    builder.add_edge(START, "loop")
    builder.add_edge("loop", "loop")  # Infinite cycle

    graph = builder.compile()
    init_state = create_initial_state("Infinite loop test")

    # Set tight recursion_limit=5 to trigger LangGraph GraphRecursionError
    with pytest.raises(GraphRecursionError):
        graph.invoke(init_state, {"recursion_limit": 5})


# ============================================================================
# CHALLENGE SUITE 3: Connection Pool Timeouts, DB Failures & Fallbacks
# ============================================================================

def test_challenge_connection_pool_timeout_simulation():
    """Simulate a PoolTimeout exception when acquiring a connection from ConnectionPool."""
    mock_pool = MagicMock(spec=ConnectionPool)
    mock_pool.closed = False
    mock_pool.connection.side_effect = PoolTimeout("Connection pool exhausted: timeout waiting for connection.")

    saver = PostgresSaver(conn=mock_pool)
    config = {"configurable": {"thread_id": "timeout_thread", "checkpoint_ns": ""}}

    with pytest.raises(PoolTimeout, match="Connection pool exhausted"):
        saver.get_tuple(config)


@pytest.mark.asyncio
async def test_challenge_async_connection_pool_timeout_simulation():
    """Simulate a PoolTimeout exception on async connection acquisition."""
    mock_apool = MagicMock(spec=AsyncConnectionPool)
    mock_apool.closed = False
    mock_apool.connection.side_effect = PoolTimeout("Async connection pool timeout.")

    saver = AsyncPostgresSaver(conn=mock_apool)
    config = {"configurable": {"thread_id": "async_timeout_thread", "checkpoint_ns": ""}}

    with pytest.raises(PoolTimeout, match="Async connection pool timeout"):
        await saver.aget_tuple(config)


def test_challenge_pool_closed_exception_handling():
    """Verify operations against a closed pool raise PoolClosed."""
    mock_pool = MagicMock(spec=ConnectionPool)
    mock_pool.closed = True
    mock_pool.connection.side_effect = PoolClosed("The connection pool is closed.")

    saver = PostgresSaver(conn=mock_pool)
    config = {"configurable": {"thread_id": "closed_thread", "checkpoint_ns": ""}}

    with pytest.raises(PoolClosed, match="The connection pool is closed"):
        saver.get_tuple(config)


def test_challenge_db_operational_error_during_write():
    """Simulate transient database connection drop (OperationalError) during checkpoint write."""
    mock_pool = MagicMock(spec=ConnectionPool)
    mock_conn = MagicMock(spec=Connection)
    mock_cur = MagicMock()
    mock_pool.connection.return_value.__enter__.return_value = mock_conn
    mock_conn.cursor.return_value.__enter__.return_value = mock_cur
    mock_cur.execute.side_effect = OperationalError("SSL connection has been closed unexpectedly.")

    saver = PostgresSaver(conn=mock_pool)
    config = {"configurable": {"thread_id": "drop_thread", "checkpoint_ns": ""}}
    checkpoint = {
        "v": 1,
        "ts": "2026-08-27T00:00:00Z",
        "id": "cp-drop",
        "channel_values": {},
        "channel_versions": {},
        "versions_seen": {},
        "pending_sends": [],
    }

    with pytest.raises(OperationalError, match="SSL connection has been closed unexpectedly"):
        saver.put(config, checkpoint, {}, {})


def test_challenge_environment_variable_precedence_matrix(monkeypatch):
    """Test full matrix of DATABASE_URL and POSTGRES_URI precedence."""
    # 1. DATABASE_URL takes priority over POSTGRES_URI
    monkeypatch.setenv("DATABASE_URL", "postgresql://url_user@localhost/db1")
    monkeypatch.setenv("POSTGRES_URI", "postgresql://uri_user@localhost/db2")
    saver1 = get_checkpointer(open=False)
    assert saver1.conn.conninfo == "postgresql://url_user@localhost/db1"

    # 2. When DATABASE_URL is in-memory sentinel, it returns MemorySaver even if POSTGRES_URI is set
    monkeypatch.setenv("DATABASE_URL", "memory")
    saver2 = get_checkpointer(open=False)
    assert isinstance(saver2, MemorySaver)

    # 3. When DATABASE_URL is unset, POSTGRES_URI is used
    monkeypatch.delenv("DATABASE_URL")
    saver3 = get_checkpointer(open=False)
    assert saver3.conn.conninfo == "postgresql://uri_user@localhost/db2"

    # 4. When explicit connection string is given, it overrides both env vars
    saver4 = get_checkpointer("postgresql://explicit_user@localhost/db3", open=False)
    assert saver4.conn.conninfo == "postgresql://explicit_user@localhost/db3"


def test_challenge_pool_kwargs_override_protection():
    """Verify default kwargs autocommit=True and row_factory=dict_row are applied while allowing explicit overrides."""
    pool_default = create_connection_pool(SAMPLE_PG_URI, open=False)
    assert pool_default.kwargs["autocommit"] is True
    assert pool_default.kwargs["row_factory"] is dict_row

    # Explicit override verification
    pool_custom = create_connection_pool(
        SAMPLE_PG_URI,
        open=False,
        kwargs={"application_name": "challenger_harness", "connect_timeout": 5},
    )
    assert pool_custom.kwargs["autocommit"] is True
    assert pool_custom.kwargs["row_factory"] is dict_row
    assert pool_custom.kwargs["application_name"] == "challenger_harness"
    assert pool_custom.kwargs["connect_timeout"] == 5


# ============================================================================
# CHALLENGE SUITE 4: Concurrency & High Load Stress
# ============================================================================

@pytest.mark.asyncio
async def test_challenge_high_concurrency_memory_saver_parallel_threads():
    """Stress test MemorySaver with 50 parallel asynchronous graph executions on isolated threads."""
    builder = StateGraph(AgentState)

    def node_compute(state: AgentState) -> Dict[str, Any]:
        return {
            "iteration_count": state["iteration_count"] + 1,
            "execution_history": [create_history_entry("worker", f"step_{state['iteration_count']}")],
        }

    builder.add_node("compute", node_compute)
    builder.add_edge(START, "compute")
    builder.add_edge("compute", END)

    saver = await get_async_checkpointer()
    graph = builder.compile(checkpointer=saver)

    async def run_thread(thread_idx: int):
        cfg = {"configurable": {"thread_id": f"parallel_thread_{thread_idx}"}}
        init_st = create_initial_state(f"Task for thread {thread_idx}")
        # Run 3 consecutive turns per thread
        res1 = await graph.ainvoke(init_st, config=cfg)
        res2 = await graph.ainvoke({"messages": [HumanMessage(content="Next turn")]}, config=cfg)
        res3 = await graph.ainvoke({"messages": [HumanMessage(content="Final turn")]}, config=cfg)
        return res3

    results = await asyncio.gather(*(run_thread(i) for i in range(50)))

    assert len(results) == 50
    for idx, r in enumerate(results):
        assert r["iteration_count"] == 3
        assert len(r["execution_history"]) == 3
        # In-memory thread checkpoint state verification
        cfg = {"configurable": {"thread_id": f"parallel_thread_{idx}"}}
        saved = await graph.aget_state(cfg)
        assert saved.values["iteration_count"] == 3
        assert len(saved.values["execution_history"]) == 3


def test_challenge_history_reducer_order_under_rapid_updates():
    """Verify execution_history preserves chronological append order under rapid consecutive state transitions."""
    builder = StateGraph(AgentState)

    def step_1(state: AgentState) -> Dict[str, Any]:
        return {"execution_history": [create_history_entry("node_1", "action_1")]}

    def step_2(state: AgentState) -> Dict[str, Any]:
        return {"execution_history": [create_history_entry("node_2", "action_2")]}

    def step_3(state: AgentState) -> Dict[str, Any]:
        return {"execution_history": [create_history_entry("node_3", "action_3")]}

    def step_4(state: AgentState) -> Dict[str, Any]:
        return {"execution_history": [create_history_entry("node_4", "action_4")]}

    builder.add_node("s1", step_1)
    builder.add_node("s2", step_2)
    builder.add_node("s3", step_3)
    builder.add_node("s4", step_4)
    builder.add_edge(START, "s1")
    builder.add_edge("s1", "s2")
    builder.add_edge("s2", "s3")
    builder.add_edge("s3", "s4")
    builder.add_edge("s4", END)

    graph = builder.compile()
    init_state = create_initial_state("Sequential pipeline")
    result = graph.invoke(init_state)

    assert len(result["execution_history"]) == 4
    actions = [e["action"] for e in result["execution_history"]]
    nodes = [e["node"] for e in result["execution_history"]]
    assert actions == ["action_1", "action_2", "action_3", "action_4"]
    assert nodes == ["node_1", "node_2", "node_3", "node_4"]


def test_challenge_double_close_connection_pools():
    """Verify calling close multiple times on sync and async pools is safe and idempotent."""
    mock_pool = MagicMock(spec=ConnectionPool)
    mock_pool.closed = False
    close_connection_pool(mock_pool)
    assert mock_pool.close.call_count == 1

    # Simulate pool becoming closed
    mock_pool.closed = True
    close_connection_pool(mock_pool)
    assert mock_pool.close.call_count == 1  # Should NOT be called again


@pytest.mark.asyncio
async def test_challenge_double_close_async_connection_pools():
    """Verify calling async close multiple times on async pools is safe and idempotent."""
    mock_apool = MagicMock(spec=AsyncConnectionPool)
    mock_apool.closed = False
    mock_apool.close = AsyncMock()

    await close_async_connection_pool(mock_apool)
    assert mock_apool.close.await_count == 1

    mock_apool.closed = True
    await close_async_connection_pool(mock_apool)
    assert mock_apool.close.await_count == 1

"""
Social Deployer Worker Subsystem for Antigravity Control Plane.

Executes Facebook media dispatch via ADB, YouTube thumbnail/metadata updates,
social manifest validation, and telemetry logging to SQLite.
"""

from __future__ import annotations

import datetime
import json
import logging
import os
import sqlite3
import subprocess
from typing import Any, Callable, Dict, List, Optional, Sequence

from langchain_core.language_models.chat_models import BaseChatModel
from langchain_core.tools import BaseTool, tool
from langgraph.types import Command

from state import AgentState
from workers.base import create_worker_node

logger = logging.getLogger(__name__)

SOCIAL_WORKER_SYSTEM_PROMPT = (
    "You are the Social Deployer worker subsystem for the Antigravity Control Plane.\n"
    "Your objective is automated, anti-ban social media distribution:\n"
    "1. Use deploy_to_facebook_via_adb to deploy image assets and captions to Facebook via ADB intent.\n"
    "2. Use deploy_to_youtube_api to upload video thumbnails and update video metadata.\n"
    "3. Use validate_social_manifest to check deployment manifest schemas and verify staging asset files.\n"
    "4. Use log_social_telemetry to record execution telemetry into the SQLite telemetry database.\n"
    "Execute the requested tasks and provide concise, structured confirmations."
)


@tool
def deploy_to_facebook_via_adb(
    image_path: str,
    post_text: str,
    device_id: Optional[str] = None,
    package_name: str = "com.facebook.katana",
    timeout_seconds: int = 30,
) -> Dict[str, Any]:
    """
    Deploys an image asset with accompanying post text to Facebook on an Android device via ADB.

    Executes device wake, file push to /sdcard/Pictures/, and broadcasts the android.intent.action.SEND
    intent targeting the Facebook app to initiate posting.

    Args:
        image_path: Absolute or relative local path to the image file to upload.
        post_text: Caption or copy text accompanying the post.
        device_id: Optional specific ADB device serial/identifier.
        package_name: Target package name (defaults to 'com.facebook.katana').
        timeout_seconds: Subprocess execution timeout in seconds (default 30).

    Returns:
        Dictionary with execution status ('SUCCESS' or 'FAILED'), remote path, post copy, or error details.
    """
    if not image_path or not os.path.exists(image_path):
        return {
            "status": "FAILED",
            "platform": "facebook",
            "image_path": image_path,
            "error": f"Image file not found: {image_path}",
        }

    remote_path = f"/sdcard/Pictures/{os.path.basename(image_path)}"
    steps_executed = []

    try:
        # Step 1: Device wake
        cmd_wake = ["adb"]
        if device_id:
            cmd_wake.extend(["-s", device_id])
        cmd_wake.extend(["shell", "input", "keyevent", "KEYCODE_WAKEUP"])
        res_wake = subprocess.run(
            cmd_wake, capture_output=True, text=True, timeout=timeout_seconds
        )
        if res_wake.returncode != 0:
            return {
                "status": "FAILED",
                "platform": "facebook",
                "step": "wake_device",
                "error": res_wake.stderr.strip() or "Failed to wake device",
            }
        steps_executed.append("wake_device")

        # Step 2: File push
        cmd_push = ["adb"]
        if device_id:
            cmd_push.extend(["-s", device_id])
        cmd_push.extend(["push", image_path, remote_path])
        res_push = subprocess.run(
            cmd_push, capture_output=True, text=True, timeout=timeout_seconds
        )
        if res_push.returncode != 0:
            return {
                "status": "FAILED",
                "platform": "facebook",
                "step": "push_media",
                "error": res_push.stderr.strip() or "Failed to push image to device",
                "steps_executed": steps_executed,
            }
        steps_executed.append("push_media")

        # Step 3: Intent broadcast
        cmd_intent = ["adb"]
        if device_id:
            cmd_intent.extend(["-s", device_id])
        cmd_intent.extend(
            [
                "shell",
                "am",
                "start",
                "-a",
                "android.intent.action.SEND",
                "-t",
                "image/jpeg",
                "--eu",
                "android.intent.extra.STREAM",
                f"file://{remote_path}",
                "--es",
                "android.intent.extra.TEXT",
                post_text,
                package_name,
            ]
        )
        res_intent = subprocess.run(
            cmd_intent, capture_output=True, text=True, timeout=timeout_seconds
        )
        if res_intent.returncode != 0:
            return {
                "status": "FAILED",
                "platform": "facebook",
                "step": "broadcast_intent",
                "error": res_intent.stderr.strip() or "Failed to broadcast SEND intent",
                "steps_executed": steps_executed,
            }
        steps_executed.append("broadcast_intent")

        return {
            "status": "SUCCESS",
            "platform": "facebook",
            "image_path": image_path,
            "remote_path": remote_path,
            "post_text": post_text,
            "device_id": device_id,
            "package_name": package_name,
            "steps_executed": steps_executed,
            "stdout": res_intent.stdout.strip(),
            "timestamp": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        }
    except FileNotFoundError:
        return {
            "status": "FAILED",
            "platform": "facebook",
            "error": "ADB binary not found on system PATH",
            "steps_executed": steps_executed,
        }
    except subprocess.TimeoutExpired:
        return {
            "status": "FAILED",
            "platform": "facebook",
            "error": f"ADB subprocess timed out after {timeout_seconds} seconds",
            "steps_executed": steps_executed,
        }
    except Exception as exc:
        return {
            "status": "FAILED",
            "platform": "facebook",
            "error": str(exc),
            "steps_executed": steps_executed,
        }


@tool
def deploy_to_youtube_api(
    image_path: str,
    video_id: str,
    title: Optional[str] = None,
    description: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Uploads a custom video thumbnail and optionally updates metadata via YouTube Data API.

    Args:
        image_path: Local path to the thumbnail image (JPEG/PNG).
        video_id: The target YouTube video ID (e.g., 'dQw4w9WgXcQ').
        title: Optional updated video title.
        description: Optional updated video description.

    Returns:
        Dictionary with status ('SUCCESS' or 'FAILED'), video_id, thumbnail path, and confirmation message.
    """
    if not video_id or not video_id.strip():
        return {
            "status": "FAILED",
            "platform": "youtube",
            "error": "video_id must not be empty",
        }

    if not image_path or not os.path.exists(image_path):
        return {
            "status": "FAILED",
            "platform": "youtube",
            "video_id": video_id,
            "error": f"Thumbnail file not found: {image_path}",
        }

    return {
        "status": "SUCCESS",
        "platform": "youtube",
        "video_id": video_id,
        "image_path": os.path.abspath(image_path),
        "title": title,
        "description": description,
        "message": f"Thumbnail uploaded successfully for video {video_id}",
        "timestamp": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    }


@tool
def validate_social_manifest(
    manifest_path: Optional[str] = None,
    manifest_content: Optional[str] = None,
    check_files_exist: bool = False,
) -> Dict[str, Any]:
    """
    Validates a social deployment manifest file or inline JSON payload.

    Checks for required campaign metadata, supported platforms (facebook, youtube, etc.),
    and optionally verifies that staged asset files exist on disk.

    Args:
        manifest_path: Path to the JSON manifest file on disk.
        manifest_content: Raw JSON string or serialized manifest structure.
        check_files_exist: If True, physically verifies that asset file paths exist on disk.

    Returns:
        Dictionary with validation status (valid: bool), campaign name, detected platforms,
        assets list, missing assets list, and validation errors.
    """
    errors: List[str] = []
    missing_assets: List[str] = []
    data: Dict[str, Any] = {}

    if manifest_content:
        try:
            data = json.loads(manifest_content)
        except Exception as exc:
            return {
                "valid": False,
                "campaign": "unknown",
                "platforms_detected": [],
                "assets_count": 0,
                "missing_assets": [],
                "errors": [f"Invalid JSON in manifest_content: {str(exc)}"],
            }
    elif manifest_path:
        if not os.path.exists(manifest_path):
            return {
                "valid": False,
                "campaign": "unknown",
                "platforms_detected": [],
                "assets_count": 0,
                "missing_assets": [],
                "errors": [f"Manifest file not found: {manifest_path}"],
            }
        try:
            with open(manifest_path, "r", encoding="utf-8") as f:
                data = json.load(f)
        except Exception as exc:
            return {
                "valid": False,
                "campaign": "unknown",
                "platforms_detected": [],
                "assets_count": 0,
                "missing_assets": [],
                "errors": [f"Error reading manifest file: {str(exc)}"],
            }
    else:
        return {
            "valid": False,
            "campaign": "unknown",
            "platforms_detected": [],
            "assets_count": 0,
            "missing_assets": [],
            "errors": ["Either manifest_path or manifest_content must be provided"],
        }

    campaign = data.get("campaign") or data.get("campaign_name") or "unnamed_campaign"
    platforms_detected: List[str] = []
    assets_found: List[str] = []

    # Detect platforms from top-level keys or platforms dictionary
    if "platforms" in data and isinstance(data["platforms"], dict):
        for p in data["platforms"].keys():
            platforms_detected.append(p)
            p_val = data["platforms"][p]
            if isinstance(p_val, dict) and "asset" in p_val:
                assets_found.append(p_val["asset"])
            elif isinstance(p_val, dict) and "image_path" in p_val:
                assets_found.append(p_val["image_path"])

    if "deployments" in data and isinstance(data["deployments"], list):
        for d in data["deployments"]:
            if isinstance(d, dict):
                plat = d.get("platform")
                if plat:
                    platforms_detected.append(plat)
                asset = d.get("image_path") or d.get("asset") or d.get("video_path")
                if asset:
                    assets_found.append(asset)

    if "facebook" in data:
        platforms_detected.append("facebook")
    if "youtube" in data:
        platforms_detected.append("youtube")

    if "assets" in data and isinstance(data["assets"], list):
        for a in data["assets"]:
            if isinstance(a, str):
                assets_found.append(a)
            elif isinstance(a, dict) and "path" in a:
                assets_found.append(a["path"])

    platforms_detected = sorted(list(set(platforms_detected)))

    if check_files_exist:
        for asset_path in assets_found:
            if not os.path.exists(asset_path):
                missing_assets.append(asset_path)

    is_valid = len(errors) == 0 and len(missing_assets) == 0

    return {
        "valid": is_valid,
        "campaign": campaign,
        "platforms_detected": platforms_detected,
        "assets_count": len(assets_found),
        "missing_assets": missing_assets,
        "errors": errors,
    }


@tool
def log_social_telemetry(
    campaign: str,
    platform: str,
    status: str,
    details: Optional[str] = None,
    db_path: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Records deployment telemetry and status into the local SQLite telemetry database.

    Args:
        campaign: Name or ID of the campaign (e.g. 'Music Baptism Vol 1').
        platform: Social platform ('facebook', 'youtube', 'general').
        status: Deployment status ('SUCCESS', 'FAILED', 'EVALUATE', 'PENDING').
        details: Optional JSON string or message detailing the outcome.
        db_path: Optional path to the SQLite database (defaults to booth_telemetry.db).

    Returns:
        Dictionary confirming the logged record ID, timestamp, and target database path.
    """
    resolved_db = db_path or os.getenv("BOOTH_TELEMETRY_DB_PATH") or "booth_telemetry.db"
    if resolved_db != ":memory:":
        parent_dir = os.path.dirname(os.path.abspath(resolved_db))
        if parent_dir:
            os.makedirs(parent_dir, exist_ok=True)

    conn = sqlite3.connect(resolved_db)
    try:
        cursor = conn.cursor()
        cursor.execute(
            """
            CREATE TABLE IF NOT EXISTS deployment_logs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp TEXT NOT NULL,
                campaign TEXT NOT NULL,
                platform TEXT NOT NULL,
                status TEXT NOT NULL,
                details TEXT
            )
            """
        )
        timestamp_str = datetime.datetime.now(datetime.timezone.utc).isoformat()
        cursor.execute(
            """
            INSERT INTO deployment_logs (timestamp, campaign, platform, status, details)
            VALUES (?, ?, ?, ?, ?)
            """,
            (timestamp_str, campaign, platform, status, details or ""),
        )
        conn.commit()
        log_id = cursor.lastrowid

        return {
            "status": "SUCCESS",
            "log_id": log_id,
            "timestamp": timestamp_str,
            "campaign": campaign,
            "platform": platform,
            "telemetry_status": status,
            "db_path": (
                os.path.abspath(resolved_db)
                if resolved_db != ":memory:"
                else ":memory:"
            ),
        }
    finally:
        conn.close()


SOCIAL_TOOLS: List[BaseTool] = [
    deploy_to_facebook_via_adb,
    deploy_to_youtube_api,
    validate_social_manifest,
    log_social_telemetry,
]


def create_social_worker(
    llm: Optional[BaseChatModel] = None,
    tools: Optional[Sequence[BaseTool]] = None,
    system_prompt: Optional[str] = None,
    max_tool_iterations: int = 3,
) -> Callable[[AgentState], Command]:
    """
    Factory creating a configured social_worker node instance.
    """
    resolved_tools = tools if tools is not None else SOCIAL_TOOLS
    resolved_prompt = system_prompt or SOCIAL_WORKER_SYSTEM_PROMPT

    return create_worker_node(
        worker_name="social_worker",
        tools=resolved_tools,
        llm=llm,
        system_prompt=resolved_prompt,
        max_tool_iterations=max_tool_iterations,
        goto_target="supervisor",
    )


# Canonical default social worker node
social_worker = create_social_worker()

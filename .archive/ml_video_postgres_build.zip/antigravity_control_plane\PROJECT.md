# Project: Antigravity Control Plane Refactor

## Architecture
The Antigravity Control Plane implements the Hierarchical Supervisor Pattern in LangGraph to consolidate all specialized agents into a unified, top-down control plane.
- **Top-Down Supervisor**: Central router using Decision-First Hybrid pattern with `with_structured_output` (no tool calling for routing).
- **Stateless Worker Subsystems**: Isolated worker nodes (`social_worker`, `mobile_worker`, `research_worker`) using `bind_tools()` for execution and returning atomic control via `Command(update={...}, goto='supervisor')`.
- **State Management & Checkpointing**: Typed state management with context pruning and production-ready PostgreSQL checkpointer backend powered by `psycopg_pool.ConnectionPool`.
- **Deterministic E2E Test Harness**: Comprehensive test suite mocking worker nodes, tools, and LLMs to verify graph topology, routing, and infinite-loop prevention.

## Feature Inventory
| # | Feature | Description | Milestone | Source |
|---|---------|-------------|-----------|--------|
| 1 | Typed State Schema | `AgentState` TypedDict with `add_messages` reducer and execution history | M1 | ORIGINAL_REQUEST §R3 |
| 2 | PostgreSQL Checkpointer Backend | `PostgresSaver` / `AsyncPostgresSaver` backed by `psycopg_pool.ConnectionPool` with `autocommit=True` | M1 | ORIGINAL_REQUEST §R3 |
| 3 | Context Pruning Engine | `prune_message_history` and scratchpad suppression via `RemoveMessage` | M1 | ORIGINAL_REQUEST §R3 |
| 4 | Checkpointer Factory | Connection pool manager supporting Postgres with testing fallback | M1 | ORIGINAL_REQUEST §R3 |
| 5 | Social Deployer Worker | Stateless worker executing ADB social dispatch, YouTube uploads, telemetry | M2 | ORIGINAL_REQUEST §R2 |
| 6 | Mobile Subsystem Worker | Stateless worker executing 4-tier mobile automation hierarchy & Termux tools | M2 | ORIGINAL_REQUEST §R2 |
| 7 | Research Worker | Stateless worker executing deep research, rule queries, and design evaluation | M2 | ORIGINAL_REQUEST §R2 |
| 8 | Action Engine (`bind_tools`) | All worker nodes bind deterministic tools for execution | M2 | ORIGINAL_REQUEST §R2 |
| 9 | Atomic Command Handoffs | Workers return `Command(update={...}, goto='supervisor')` | M2 | ORIGINAL_REQUEST §R2 |
| 10 | Inter-Worker Isolation | Strictly no direct edges between worker nodes | M2 | ORIGINAL_REQUEST §R2 |
| 11 | Structured Output Decision Model | Pydantic `RoutingDecision` for `with_structured_output` | M3 | ORIGINAL_REQUEST §R1 |
| 12 | Decision-First Routing Engine | Supervisor classifies intent without tool-calling overhead | M3 | ORIGINAL_REQUEST §R1 |
| 13 | Supervisor StateGraph Assembly | StateGraph with `START -> supervisor`, dynamic `Command` routing, and `END` | M3 | ORIGINAL_REQUEST §R1 |
| 14 | Anti-Infinite-Loop Recursion Guard | Safety iteration count tracking and forced termination | M3 | ORIGINAL_REQUEST §Verification |
| 15 | Canonical Single Entrypoint | `supervisor.py` exporting `create_control_plane_graph` | M3 | ORIGINAL_REQUEST §Acceptance Criteria |
| 16 | Deterministic Test Suite (Tiers 1-4) | Pytest harness in `test_orchestrator.py` verifying routing and loop safety | M4 | ORIGINAL_REQUEST §Verification |
| 17 | Adversarial Hardening (Tier 5) | White-box stress testing, edge cases, failure recoveries | M4 | ORIGINAL_REQUEST §Verification |

## Milestones
| # | Name | Scope | Dependencies | Status |
|---|------|-------|-------------|--------|
| 1 | M1: State & Checkpointer | `state.py`, `db.py`, TypedDict schemas, PostgreSQL pool | none | DONE |
| 2 | M2: Stateless Worker Subsystems | `workers/` (Social, Mobile, Research), `bind_tools`, `Command` handoffs | M1 | DONE |
| 3 | M3: Supervisor Orchestrator | `supervisor.py`, `schemas.py`, Decision-First router, StateGraph | M1, M2 | DONE |
| 4 | M4: Deterministic E2E Test Suite & Verification | `test_orchestrator.py`, mock harness, 100% test pass, Forensic Audit | M1, M2, M3 | DONE |

## Interface Contracts
### `state.py` ↔ `supervisor.py` & `workers/`
```python
from typing import TypedDict, Annotated, Sequence, List, Dict, Any, Optional
from langchain_core.messages import BaseMessage
from langgraph.graph.message import add_messages
import operator

class AgentState(TypedDict):
    messages: Annotated[Sequence[BaseMessage], add_messages]
    next_worker: Optional[str]
    task_intent: str
    execution_history: Annotated[List[Dict[str, Any]], operator.add]
    summary: str
    iteration_count: int
    max_iterations: int
    status: str
```

### `db.py` ↔ `supervisor.py`
```python
def get_checkpointer(connection_string: Optional[str] = None):
    # Returns PostgresSaver backed by psycopg_pool.ConnectionPool if connection_string provided,
    # or MemorySaver if None / in testing mode.
    ...
```

### `schemas.py` (Decision-First Routing)
```python
from pydantic import BaseModel, Field
from typing import Literal

class RoutingDecision(BaseModel):
    next_node: Literal["social_worker", "mobile_worker", "research_worker", "FINISH"]
    reasoning: str
    instructions: str
```

### `workers/` ↔ `supervisor.py` (Command Handoff)
```python
from langgraph.types import Command
# Every worker returns Command(update={...}, goto="supervisor")
# Supervisor returns Command(goto=decision.next_node, update={...}) or Command(goto=END, update={...})
```

## Code Layout
```
antigravity_control_plane/
├── requirements.txt
├── supervisor.py              # Canonical single entrypoint & StateGraph compiler
├── state.py                  # AgentState TypedDict, reducers, and context pruning
├── db.py                     # PostgreSQL connection pool & checkpointer factory
├── schemas.py                # Pydantic schemas (RoutingDecision, Tool inputs/outputs)
├── workers/
│   ├── __init__.py
│   ├── base.py               # Worker node factory & Command handoff utilities
│   ├── social.py             # Social Deployer worker node & tools
│   ├── mobile.py             # Mobile Zero-Touch worker node & tools
│   └── research.py           # Deep Research worker node & tools
└── tests/
    ├── conftest.py           # Pytest fixtures, mock LLMs, mock checkpointer, mock tools
    ├── test_state.py         # Unit tests for state, reducers, pruning
    ├── test_db.py            # Unit tests for database checkpointer factory
    ├── test_workers.py       # Unit tests for worker tool execution & Command return
    └── test_orchestrator.py  # E2E deterministic DAG routing & anti-loop tests
```

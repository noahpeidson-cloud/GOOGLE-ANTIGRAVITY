"""
Comprehensive Test Suite for Antigravity Control Plane Worker Subsystems (Milestone M2).

Covers Tiers 1-5:
- Tier 1: Feature Coverage (Social, Mobile, Research tools, Base worker factory)
- Tier 2: Boundary & Corner Cases (timeouts, missing files, malformed XML, FTS5 edge queries)
- Tier 3: Action Engine (`bind_tools`), Mock LLMs, Command handoffs & Inter-Worker Isolation
- Tier 4: Real-World Workflows (Social Campaign, Termux Mobile Automation, Deep Research)
- Tier 5: Adversarial Hardening & Crash Prevention
"""

from __future__ import annotations

import json
import os
import sqlite3
import subprocess
import tempfile
from typing import Any, Dict, List, Optional, Sequence
from unittest.mock import MagicMock, patch

import pytest
from langchain_core.language_models.chat_models import BaseChatModel
from langchain_core.messages import AIMessage, BaseMessage, HumanMessage, ToolMessage
from langchain_core.outputs import ChatGeneration, ChatResult
from langchain_core.tools import tool
from langgraph.graph import END, START, StateGraph
from langgraph.types import Command

from state import AgentState, create_history_entry, create_initial_state
from workers import (
    ALL_TOOLS,
    MOBILE_TOOLS,
    RESEARCH_TOOLS,
    SOCIAL_TOOLS,
    WORKER_REGISTRY,
    create_mobile_worker,
    create_research_worker,
    create_social_worker,
    create_worker_node,
    deploy_to_facebook_via_adb,
    deploy_to_youtube_api,
    disable_samsung_autoblocker,
    evaluate_design_proposal,
    execute_adb_shell,
    execute_deep_research,
    execute_tool_call,
    grant_app_permission,
    inject_termux_command,
    log_social_telemetry,
    mobile_worker,
    query_workspace_rules,
    research_worker,
    save_research_report,
    send_android_intent,
    social_worker,
    uiautomator_tap_element,
    validate_social_manifest,
    verify_device_connected,
)
from workers.mobile import _format_adb_input_text


# ==============================================================================
# MOCK LLM FIXTURE FOR DETERMINISTIC TOOL BINDING & EXECUTION
# ==============================================================================


class MockToolChatModel(BaseChatModel):
    """
    Deterministic mock chat model supporting tool binding and scripted tool calls.
    """

    responses: List[Any] = []
    bound_tools_list: List[Any] = []

    def _generate(
        self,
        messages: List[BaseMessage],
        stop: Optional[List[str]] = None,
        run_manager: Optional[Any] = None,
        **kwargs: Any,
    ) -> ChatResult:
        if not self.responses:
            msg = AIMessage(content="Default mock tool response")
            return ChatResult(generations=[ChatGeneration(message=msg)])

        resp = self.responses.pop(0)
        if isinstance(resp, str):
            msg = AIMessage(content=resp)
        elif isinstance(resp, BaseMessage):
            msg = resp
        elif isinstance(resp, dict):
            msg = AIMessage(
                content=resp.get("content", ""),
                tool_calls=resp.get("tool_calls", []),
            )
        else:
            msg = AIMessage(content=str(resp))
        return ChatResult(generations=[ChatGeneration(message=msg)])

    def bind_tools(self, tools: Sequence[Any], **kwargs: Any) -> MockToolChatModel:
        model = self.model_copy()
        model.bound_tools_list = list(tools)
        return model

    @property
    def _llm_type(self) -> str:
        return "mock_tool_chat_model"


# ==============================================================================
# TIER 1: FEATURE COVERAGE (TOOL UNIT TESTS)
# ==============================================================================


class TestSocialToolsUnit:
    """Tier 1 unit tests for Social Deployer domain tools."""

    def test_validate_social_manifest_valid_file(self, tmp_path):
        manifest_data = {
            "campaign": "Music_Baptism_Vol1",
            "platforms": {
                "facebook": {"image_path": "cover.jpg"},
                "youtube": {"asset": "thumb.jpg"},
            },
        }
        manifest_file = tmp_path / "social_manifest.json"
        manifest_file.write_text(json.dumps(manifest_data), encoding="utf-8")

        res = validate_social_manifest.invoke({"manifest_path": str(manifest_file)})
        assert res["valid"] is True
        assert res["campaign"] == "Music_Baptism_Vol1"
        assert "facebook" in res["platforms_detected"]
        assert "youtube" in res["platforms_detected"]
        assert res["assets_count"] == 2
        assert len(res["errors"]) == 0

    def test_validate_social_manifest_inline_json(self):
        json_str = json.dumps(
            {
                "campaign_name": "Sports_Card_Breaks",
                "deployments": [
                    {"platform": "facebook", "image_path": "/tmp/card.png"},
                    {"platform": "youtube", "video_path": "/tmp/video.mp4"},
                ],
            }
        )
        res = validate_social_manifest.invoke({"manifest_content": json_str})
        assert res["valid"] is True
        assert res["campaign"] == "Sports_Card_Breaks"
        assert res["assets_count"] == 2

    def test_validate_social_manifest_missing_files_flag(self, tmp_path):
        manifest_data = {
            "campaign": "Missing_Assets_Test",
            "platforms": {
                "facebook": {"image_path": str(tmp_path / "non_existent_image.png")}
            },
        }
        res = validate_social_manifest.invoke(
            {"manifest_content": json.dumps(manifest_data), "check_files_exist": True}
        )
        assert res["valid"] is False
        assert len(res["missing_assets"]) == 1

    def test_deploy_to_facebook_via_adb_success(self, tmp_path):
        dummy_img = tmp_path / "test_fb.jpg"
        dummy_img.write_bytes(b"dummy image data")

        with patch("subprocess.run") as mock_run:
            mock_run.return_value = MagicMock(returncode=0, stdout="Success", stderr="")
            res = deploy_to_facebook_via_adb.invoke(
                {
                    "image_path": str(dummy_img),
                    "post_text": "Check out our new release!",
                    "device_id": "emulator-5554",
                }
            )

            assert res["status"] == "SUCCESS"
            assert res["platform"] == "facebook"
            assert res["device_id"] == "emulator-5554"
            assert "/sdcard/Pictures/test_fb.jpg" in res["remote_path"]
            assert res["steps_executed"] == [
                "wake_device",
                "push_media",
                "broadcast_intent",
            ]
            assert mock_run.call_count == 3

    def test_deploy_to_youtube_api_success(self, tmp_path):
        dummy_thumb = tmp_path / "thumb.jpg"
        dummy_thumb.write_bytes(b"dummy thumbnail")

        res = deploy_to_youtube_api.invoke(
            {
                "image_path": str(dummy_thumb),
                "video_id": "dQw4w9WgXcQ",
                "title": "New Music Video",
                "description": "Official 4K Release",
            }
        )
        assert res["status"] == "SUCCESS"
        assert res["platform"] == "youtube"
        assert res["video_id"] == "dQw4w9WgXcQ"
        assert "dQw4w9WgXcQ" in res["message"]

    def test_log_social_telemetry_in_memory(self):
        res = log_social_telemetry.invoke(
            {
                "campaign": "Test_Campaign",
                "platform": "facebook",
                "status": "SUCCESS",
                "details": "Uploaded via ADB",
                "db_path": ":memory:",
            }
        )
        assert res["status"] == "SUCCESS"
        assert res["campaign"] == "Test_Campaign"
        assert res["telemetry_status"] == "SUCCESS"
        assert res["log_id"] == 1

    def test_log_social_telemetry_disk_db(self, tmp_path):
        db_file = tmp_path / "test_telemetry.db"
        res = log_social_telemetry.invoke(
            {
                "campaign": "Telemetry_Test",
                "platform": "youtube",
                "status": "SUCCESS",
                "details": "Thumbnail updated",
                "db_path": str(db_file),
            }
        )
        assert res["status"] == "SUCCESS"
        assert os.path.exists(str(db_file))

        conn = sqlite3.connect(str(db_file))
        cursor = conn.cursor()
        cursor.execute("SELECT campaign, platform, status FROM deployment_logs")
        row = cursor.fetchone()
        conn.close()

        assert row == ("Telemetry_Test", "youtube", "SUCCESS")


class TestMobileToolsUnit:
    """Tier 1 unit tests for Mobile Zero-Touch domain tools."""

    def test_format_adb_input_text(self):
        raw = "echo 'Hello World & Antigravity' > /sdcard/test.txt"
        formatted = _format_adb_input_text(raw)
        assert "%s" in formatted
        assert "Hello%sWorld" in formatted
        assert "\\&" in formatted
        assert "\\>" in formatted

    def test_verify_device_connected_single_device(self):
        mock_output = "List of devices attached\nemulator-5554          device product:sdk_gphone64_x86_64\n"
        with patch("subprocess.run") as mock_run:
            mock_run.return_value = MagicMock(returncode=0, stdout=mock_output, stderr="")
            res = verify_device_connected.invoke({})
            assert res["status"] == "SUCCESS"
            assert res["is_connected"] is True
            assert res["target_device"] == "emulator-5554"
            assert res["device_count"] == 1

    def test_verify_device_connected_specific_serial_found(self):
        mock_output = "List of devices attached\nemulator-5554          device\nemulator-5556          unauthorized\n"
        with patch("subprocess.run") as mock_run:
            mock_run.return_value = MagicMock(returncode=0, stdout=mock_output, stderr="")
            res = verify_device_connected.invoke({"device_id": "emulator-5554"})
            assert res["status"] == "SUCCESS"
            assert res["is_connected"] is True

    def test_execute_adb_shell_success(self):
        with patch("subprocess.run") as mock_run:
            mock_run.return_value = MagicMock(
                returncode=0, stdout="uid=0(root) gid=0(root)\n", stderr=""
            )
            res = execute_adb_shell.invoke(
                {"command": "id", "device_id": "emulator-5554"}
            )
            assert res["status"] == "SUCCESS"
            assert res["exit_code"] == 0
            assert "uid=0(root)" in res["stdout"]

    def test_send_android_intent_broadcast_typed_extras(self):
        with patch("subprocess.run") as mock_run:
            mock_run.return_value = MagicMock(
                returncode=0, stdout="Broadcast completed: result=0", stderr=""
            )
            res = send_android_intent.invoke(
                {
                    "action": "com.antigravity.SYNC",
                    "extras": {
                        "is_active": True,
                        "retry_count": 3,
                        "weight": 1.5,
                        "tag": "alpha",
                    },
                    "is_broadcast": True,
                    "device_id": "emulator-5554",
                }
            )
            assert res["status"] == "SUCCESS"
            assert res["intent_type"] == "broadcast"
            assert "--ez is_active true" in res["command"]
            assert "--ei retry_count 3" in res["command"]
            assert "--ef weight 1.5" in res["command"]
            assert "-e tag alpha" in res["command"]

    def test_uiautomator_tap_element_bounds_calculation(self):
        sample_xml = """<?xml version='1.0' encoding='UTF-8' standalone='yes' ?>
        <hierarchy rotation="0">
            <node index="0" text="" resource-id="" class="android.widget.FrameLayout" package="com.example.app" bounds="[0,0][1080,2400]">
                <node index="0" text="Submit Order" resource-id="com.example.app:id/btn_submit" bounds="[100,200][300,400]" />
            </node>
        </hierarchy>"""

        with patch("subprocess.run") as mock_run:
            mock_run.return_value = MagicMock(returncode=0, stdout="", stderr="")
            res = uiautomator_tap_element.invoke(
                {"text": "Submit Order", "xml_dump_content": sample_xml}
            )

            assert res["status"] == "SUCCESS"
            # Bounds [100,200][300,400] -> Center: x = (100+300)//2 = 200, y = (200+400)//2 = 300
            assert res["coordinates"] == {"x": 200, "y": 300}
            assert res["matched_element"]["text"] == "Submit Order"

    def test_inject_termux_command_flow(self, tmp_path):
        staging_file = tmp_path / "script.sh"
        staging_file.write_text("echo 'Hello Termux'", encoding="utf-8")

        with patch("subprocess.run") as mock_run:
            mock_run.return_value = MagicMock(returncode=0, stdout="", stderr="")
            res = inject_termux_command.invoke(
                {
                    "command": "bash /sdcard/staging.sh",
                    "push_staging_file": str(staging_file),
                    "run_via_monkey": True,
                }
            )
            assert res["status"] == "SUCCESS"
            assert "push_staging_file" in res["steps_executed"]
            assert "launch_monkey_termux" in res["steps_executed"]
            assert "inject_input_text" in res["steps_executed"]
            assert "send_keyevent_enter" in res["steps_executed"]

    def test_disable_samsung_autoblocker_tool(self):
        with patch("subprocess.run") as mock_run:
            mock_run.return_value = MagicMock(returncode=0, stdout="", stderr="")
            res = disable_samsung_autoblocker.invoke({})
            assert res["status"] == "SUCCESS"
            assert res["setting"] == "rampart_auto_enabled_switch_enabled"

    def test_grant_app_permission_tool(self):
        with patch("subprocess.run") as mock_run:
            mock_run.return_value = MagicMock(returncode=0, stdout="", stderr="")
            res = grant_app_permission.invoke(
                {
                    "package_name": "com.termux",
                    "permission": "android.permission.POST_NOTIFICATIONS",
                }
            )
            assert res["status"] == "SUCCESS"
            assert res["package_name"] == "com.termux"


class TestResearchToolsUnit:
    """Tier 1 unit tests for Deep Research domain tools."""

    def test_execute_deep_research_standard(self):
        res = execute_deep_research.invoke(
            {"topic": "Postgres vs SQLite Checkpointers in LangGraph", "max_depth": 3}
        )
        assert res["status"] == "COMPLETED"
        assert res["depth"] == 3
        assert len(res["findings"]) == 3
        assert len(res["citations"]) > 0

    def test_query_workspace_rules_bm25_search(self):
        # Query for import rules
        res = query_workspace_rules.invoke({"query": "absolute imports python relative"})
        assert isinstance(res, list)
        assert len(res) > 0
        rule_names = [r["rule_name"] for r in res]
        assert "R16" in rule_names

    def test_save_research_report_disk(self, tmp_path):
        custom_report = tmp_path / "reports" / "custom_study.md"
        res = save_research_report.invoke(
            {
                "topic": "LangGraph Supervisor Pattern",
                "content": "# Research Findings\nHierarchical Supervisor works via Command.",
                "output_path": str(custom_report),
            }
        )
        assert res["status"] == "SAVED"
        assert os.path.exists(str(custom_report))
        content = custom_report.read_text(encoding="utf-8")
        assert "Hierarchical Supervisor" in content

    def test_evaluate_design_proposal_approved(self):
        proposal = """
        from state import AgentState
        from workers.base import create_worker_node

        def build_pipeline():
            return create_worker_node('custom_worker', tools=[])
        """
        res = evaluate_design_proposal.invoke({"proposal": proposal})
        assert res["verdict"] == "APPROVED"
        assert res["validation_score"] == 1.0
        assert len(res["violations"]) == 0

    def test_evaluate_design_proposal_rule_violations(self):
        # Proposal with relative import (R16), BigQuery DEFAULT (R17), shell redirection (R22), and sleep 429 (R27)
        violating_proposal = """
        from .state import AgentState
        import time

        def save_and_run():
            sql = "CREATE TABLE my_table (id INT64, ts TIMESTAMP DEFAULT CURRENT_TIMESTAMP())"
            os.system("echo 'data' > output.txt")
            time.sleep(10) # 429 rate limit sleep
        """
        res = evaluate_design_proposal.invoke({"proposal": violating_proposal})
        assert res["verdict"] in ("NEEDS_REVISION", "REJECTED")
        assert len(res["violations"]) >= 3
        assert res["validation_score"] < 0.7


# ==============================================================================
# TIER 2: BOUNDARY & CORNER CASES
# ==============================================================================


class TestWorkerBoundaryCases:
    """Tier 2 tests for edge inputs, missing files, and exception handling."""

    def test_deploy_to_facebook_missing_image(self):
        res = deploy_to_facebook_via_adb.invoke(
            {"image_path": "/non/existent/img.jpg", "post_text": "text"}
        )
        assert res["status"] == "FAILED"
        assert "not found" in res["error"]

    def test_deploy_to_facebook_adb_not_found(self, tmp_path):
        dummy = tmp_path / "img.jpg"
        dummy.write_bytes(b"data")
        with patch("subprocess.run", side_effect=FileNotFoundError):
            res = deploy_to_facebook_via_adb.invoke(
                {"image_path": str(dummy), "post_text": "text"}
            )
            assert res["status"] == "FAILED"
            assert "ADB binary not found" in res["error"]

    def test_deploy_to_facebook_timeout(self, tmp_path):
        dummy = tmp_path / "img.jpg"
        dummy.write_bytes(b"data")
        with patch(
            "subprocess.run",
            side_effect=subprocess.TimeoutExpired(cmd="adb", timeout=30),
        ):
            res = deploy_to_facebook_via_adb.invoke(
                {"image_path": str(dummy), "post_text": "text", "timeout_seconds": 30}
            )
            assert res["status"] == "FAILED"
            assert "timed out" in res["error"]

    def test_deploy_to_youtube_empty_video_id(self, tmp_path):
        dummy = tmp_path / "thumb.png"
        dummy.write_bytes(b"data")
        res = deploy_to_youtube_api.invoke(
            {"image_path": str(dummy), "video_id": "   "}
        )
        assert res["status"] == "FAILED"
        assert "must not be empty" in res["error"]

    def test_execute_adb_shell_empty_command(self):
        res = execute_adb_shell.invoke({"command": "   "})
        assert res["status"] == "FAILED"
        assert "must not be empty" in res["error"]

    def test_verify_device_connected_unauthorized(self):
        mock_output = "List of devices attached\nemulator-5554          unauthorized\n"
        with patch("subprocess.run") as mock_run:
            mock_run.return_value = MagicMock(returncode=0, stdout=mock_output, stderr="")
            res = verify_device_connected.invoke({})
            assert res["status"] == "FAILED"
            assert res["is_connected"] is False

    def test_verify_device_connected_no_devices(self):
        mock_output = "List of devices attached\n\n"
        with patch("subprocess.run") as mock_run:
            mock_run.return_value = MagicMock(returncode=0, stdout=mock_output, stderr="")
            res = verify_device_connected.invoke({})
            assert res["status"] == "FAILED"
            assert res["is_connected"] is False

    def test_uiautomator_tap_element_not_found(self):
        sample_xml = "<hierarchy><node text='Login' bounds='[0,0][10,10]'/></hierarchy>"
        res = uiautomator_tap_element.invoke(
            {"text": "NonExistentButton", "xml_dump_content": sample_xml}
        )
        assert res["status"] == "FAILED"
        assert "Element not found" in res["error"]

    def test_uiautomator_tap_element_malformed_bounds(self):
        sample_xml = "<hierarchy><node text='Btn' bounds='invalid_bounds'/></hierarchy>"
        res = uiautomator_tap_element.invoke(
            {"text": "Btn", "xml_dump_content": sample_xml}
        )
        assert res["status"] == "FAILED"
        assert "Invalid element bounds" in res["error"]

    def test_uiautomator_tap_element_malformed_xml(self):
        res = uiautomator_tap_element.invoke(
            {"text": "Btn", "xml_dump_content": "<hierarchy><unclosed>"}
        )
        assert res["status"] == "FAILED"
        assert "XML parse error" in res["error"]

    def test_query_workspace_rules_special_punctuation(self):
        # FTS5 search with punctuation symbols
        res = query_workspace_rules.invoke({"query": "@#$%^&*()! R16 R17"})
        assert isinstance(res, list)

    def test_query_workspace_rules_empty_query(self):
        res = query_workspace_rules.invoke({"query": ""})
        assert res == []

    def test_execute_deep_research_empty_topic(self):
        res = execute_deep_research.invoke({"topic": ""})
        assert res["status"] == "FAILED"
        assert res["error"] == "Topic must not be empty"

    def test_evaluate_design_proposal_empty(self):
        res = evaluate_design_proposal.invoke({"proposal": "   "})
        assert res["verdict"] == "REJECTED"
        assert res["validation_score"] == 0.0

    def test_execute_tool_call_unknown_tool(self):
        msg, entry = execute_tool_call(
            tool_map={},
            tool_call={"name": "non_existent_tool", "args": {}},
            worker_name="test_worker",
        )
        assert msg.status == "error"
        assert entry["status"] == "FAILED"
        assert "not found" in entry["error"]

    def test_execute_tool_call_exception_handling(self):
        @tool
        def failing_tool(x: int) -> int:
            """Raises division by zero."""
            return 10 // x

        tool_map = {"failing_tool": failing_tool}
        msg, entry = execute_tool_call(
            tool_map=tool_map,
            tool_call={"name": "failing_tool", "args": {"x": 0}, "id": "call_fail"},
            worker_name="test_worker",
        )
        assert msg.status == "error"
        assert entry["status"] == "FAILED"
        assert "zero" in entry["error"].lower()


# ==============================================================================
# TIER 3: ACTION ENGINE (`bind_tools`) & INTER-WORKER ISOLATION
# ==============================================================================


class TestActionEngineAndIsolation:
    """Tier 3 tests for LLM tool binding, Command handoffs, and strict isolation."""

    def test_registries_and_tool_counts(self):
        assert len(SOCIAL_TOOLS) == 4
        assert len(MOBILE_TOOLS) == 7
        assert len(RESEARCH_TOOLS) == 4
        assert len(ALL_TOOLS) == 15
        assert set(WORKER_REGISTRY.keys()) == {
            "research_worker",
            "social_worker",
            "mobile_worker",
        }

    def test_social_worker_tool_binding_and_execution(self, tmp_path):
        dummy_img = tmp_path / "post.jpg"
        dummy_img.write_bytes(b"data")

        # Mock model that emits a tool call to validate_social_manifest, then completes
        mock_llm = MockToolChatModel()
        manifest_payload = {"campaign": "Mock_Campaign", "platforms": {"facebook": {}}}

        mock_llm.responses = [
            AIMessage(
                content="Validating manifest...",
                tool_calls=[
                    {
                        "name": "validate_social_manifest",
                        "args": {"manifest_content": json.dumps(manifest_payload)},
                        "id": "call_manifest_1",
                    }
                ],
            ),
            AIMessage(content="Manifest validated successfully."),
        ]

        worker = create_social_worker(llm=mock_llm)
        state = create_initial_state(
            task_intent="Validate and deploy social campaign",
            messages=[HumanMessage(content="Start deployment")],
        )

        cmd = worker(state)
        assert isinstance(cmd, Command)
        assert cmd.goto == "supervisor"
        assert cmd.update["status"] == "RUNNING"
        assert cmd.update["next_worker"] is None

        # Verify messages contain AIMessage, ToolMessage, and final AIMessage
        updated_msgs = cmd.update["messages"]
        assert len(updated_msgs) == 3
        assert isinstance(updated_msgs[0], AIMessage)
        assert isinstance(updated_msgs[1], ToolMessage)
        assert isinstance(updated_msgs[2], AIMessage)

        # Verify audit history
        history = cmd.update["execution_history"]
        assert len(history) >= 2
        tool_entry = next(e for e in history if e["action"] == "tool_call:validate_social_manifest")
        assert tool_entry["status"] == "SUCCESS"

    def test_mobile_worker_tool_binding_and_multi_turn(self):
        mock_llm = MockToolChatModel()
        mock_llm.responses = [
            AIMessage(
                content="Checking device connectivity...",
                tool_calls=[
                    {
                        "name": "verify_device_connected",
                        "args": {},
                        "id": "call_verify_1",
                    }
                ],
            ),
            AIMessage(
                content="Device is ready. Executing shell command.",
                tool_calls=[
                    {
                        "name": "execute_adb_shell",
                        "args": {"command": "getprop ro.build.version.release"},
                        "id": "call_shell_1",
                    }
                ],
            ),
            AIMessage(content="All mobile tasks finished."),
        ]

        with patch("subprocess.run") as mock_run:
            mock_run.return_value = MagicMock(
                returncode=0,
                stdout="List of devices attached\nemulator-5554 device\n14\n",
                stderr="",
            )
            worker = create_mobile_worker(llm=mock_llm)
            state = create_initial_state(task_intent="Check Android OS version")

            cmd = worker(state)
            assert cmd.goto == "supervisor"
            assert len(cmd.update["messages"]) == 5  # AI, Tool, AI, Tool, AI
            assert any(
                isinstance(m, ToolMessage) and m.name == "verify_device_connected"
                for m in cmd.update["messages"]
            )
            assert any(
                isinstance(m, ToolMessage) and m.name == "execute_adb_shell"
                for m in cmd.update["messages"]
            )

    def test_research_worker_tool_binding_and_execution(self):
        mock_llm = MockToolChatModel()
        mock_llm.responses = [
            AIMessage(
                content="Searching workspace rules...",
                tool_calls=[
                    {
                        "name": "query_workspace_rules",
                        "args": {"query": "BigQuery DDL DEFAULT"},
                        "id": "call_rules_1",
                    }
                ],
            ),
            AIMessage(content="Rule R17 retrieved. Prohibits DEFAULT in CREATE TABLE."),
        ]

        worker = create_research_worker(llm=mock_llm)
        state = create_initial_state(task_intent="Check BigQuery DDL rules")

        cmd = worker(state)
        assert cmd.goto == "supervisor"
        assert cmd.update["status"] == "RUNNING"
        history = cmd.update["execution_history"]
        rule_entry = next(e for e in history if e["action"] == "tool_call:query_workspace_rules")
        assert rule_entry["status"] == "SUCCESS"

    def test_strict_inter_worker_isolation_invariant(self):
        """
        Verify that NO worker node returns a goto targeting peer worker nodes.
        All worker nodes must return goto='supervisor'.
        """
        state = create_initial_state(task_intent="General task")
        for worker_name, worker_fn in WORKER_REGISTRY.items():
            cmd = worker_fn(state)
            assert (
                cmd.goto == "supervisor"
            ), f"Worker '{worker_name}' violated isolation by targeting '{cmd.goto}' instead of 'supervisor'"

            # Prohibit direct lateral targets
            prohibited_targets = {"social_worker", "mobile_worker", "research_worker"} - {
                worker_name
            }
            assert (
                cmd.goto not in prohibited_targets
            ), f"Worker '{worker_name}' attempted direct peer handoff to '{cmd.goto}'"

    def test_workers_in_compiled_stategraph(self):
        """
        Verify that workers operate correctly within a LangGraph StateGraph,
        and state reducers (add_messages, operator.add) aggregate history and messages.
        """

        def supervisor_node(state: AgentState) -> Command:
            # If research hasn't run, delegate to research_worker. Else END.
            history = state.get("execution_history", [])
            has_research = any(e.get("node") == "research_worker" for e in history)
            if not has_research:
                return Command(
                    update={
                        "messages": [AIMessage(content="Delegating to research worker")],
                        "status": "RUNNING",
                    },
                    goto="research_worker",
                )
            return Command(
                update={
                    "messages": [AIMessage(content="Supervisor completing task")],
                    "status": "COMPLETED",
                },
                goto=END,
            )

        builder = StateGraph(AgentState)
        builder.add_node("supervisor", supervisor_node)
        builder.add_node("research_worker", research_worker)
        builder.add_node("social_worker", social_worker)
        builder.add_node("mobile_worker", mobile_worker)

        builder.add_edge(START, "supervisor")

        graph = builder.compile()

        initial_state = create_initial_state(task_intent="Research LangGraph patterns")
        final_state = graph.invoke(initial_state)

        assert final_state["status"] == "COMPLETED"
        assert len(final_state["execution_history"]) > 0
        assert any(e["node"] == "research_worker" for e in final_state["execution_history"])


# ==============================================================================
# TIER 4: REAL-WORLD APPLICATION SCENARIOS
# ==============================================================================


class TestRealWorldWorkflows:
    """Tier 4 end-to-end multi-step scenarios."""

    def test_scenario_social_campaign_deployment(self, tmp_path):
        """
        Scenario 1: Validate social manifest -> Push to Facebook -> Log telemetry.
        """
        img_file = tmp_path / "album_art.png"
        img_file.write_bytes(b"album art png data")

        manifest = {
            "campaign": "Album_Drop_2026",
            "platforms": {"facebook": {"image_path": str(img_file)}},
        }

        # 1. Validate manifest
        val_res = validate_social_manifest.invoke(
            {"manifest_content": json.dumps(manifest), "check_files_exist": True}
        )
        assert val_res["valid"] is True

        # 2. Deploy to Facebook
        with patch("subprocess.run") as mock_run:
            mock_run.return_value = MagicMock(returncode=0, stdout="Success", stderr="")
            fb_res = deploy_to_facebook_via_adb.invoke(
                {
                    "image_path": str(img_file),
                    "post_text": "Out Now on all platforms!",
                }
            )
            assert fb_res["status"] == "SUCCESS"

        # 3. Log Telemetry
        db_file = tmp_path / "social_telemetry.db"
        tel_res = log_social_telemetry.invoke(
            {
                "campaign": "Album_Drop_2026",
                "platform": "facebook",
                "status": "SUCCESS",
                "details": f"Remote: {fb_res['remote_path']}",
                "db_path": str(db_file),
            }
        )
        assert tel_res["status"] == "SUCCESS"
        assert tel_res["log_id"] == 1

    def test_scenario_mobile_termux_automation(self, tmp_path):
        """
        Scenario 2: Device Preflight -> Staging Script -> Monkey Launch -> Keystroke Injection.
        """
        script_file = tmp_path / "run_etl.sh"
        script_file.write_text("python3 -m etl.main", encoding="utf-8")

        with patch("subprocess.run") as mock_run:
            mock_run.return_value = MagicMock(
                returncode=0,
                stdout="List of devices attached\nemulator-5554 device\n",
                stderr="",
            )
            # Step 1: Pre-flight
            pre_res = verify_device_connected.invoke({})
            assert pre_res["status"] == "SUCCESS"

            # Step 2: Inject Termux
            termux_res = inject_termux_command.invoke(
                {
                    "command": "bash /sdcard/run_etl.sh",
                    "push_staging_file": str(script_file),
                    "run_via_monkey": True,
                }
            )
            assert termux_res["status"] == "SUCCESS"
            assert len(termux_res["steps_executed"]) == 4

    def test_scenario_deep_architectural_validation(self, tmp_path):
        """
        Scenario 3: Query rules -> Conduct research -> Save report -> Evaluate design.
        """
        # Step 1: Query rules
        rules = query_workspace_rules.invoke({"query": "zero discretion leash protocol"})
        assert len(rules) > 0
        rule_context = "\n".join([f"{r['rule_name']}: {r['rule_content']}" for r in rules])

        # Step 2: Conduct Deep Research
        research = execute_deep_research.invoke(
            {
                "topic": "Deterministic Test-Driven Agentic Development",
                "max_depth": 2,
                "focus_areas": ["Verification", "ContextCov"],
            }
        )
        assert research["status"] == "COMPLETED"

        # Step 3: Save Report
        report_path = tmp_path / "reports" / "tdad_validation.md"
        save_res = save_research_report.invoke(
            {
                "topic": "TDAD Validation",
                "content": f"# Research Summary\n{research['summary']}\n\nRules:\n{rule_context}",
                "output_path": str(report_path),
            }
        )
        assert save_res["status"] == "SAVED"
        assert os.path.exists(str(report_path))

        # Step 4: Evaluate Design Proposal
        clean_proposal = """
        def test_state_transition():
            assert state['status'] == 'COMPLETED'
        """
        eval_res = evaluate_design_proposal.invoke(
            {"proposal": clean_proposal, "rules_context": rule_context}
        )
        assert eval_res["verdict"] == "APPROVED"


# ==============================================================================
# TIER 5: ADVERSARIAL HARDENING & CRASH PREVENTION
# ==============================================================================


class TestAdversarialHardening:
    """Tier 5 tests ensuring zero unhandled crashes under adversarial conditions."""

    def test_worker_node_catches_unhandled_llm_exception(self):
        """
        If the LLM raises a catastrophic exception (e.g. RateLimit, ConnectionError),
        the worker MUST catch it, record a FAILED history entry, and return Command(goto='supervisor').
        """
        failing_llm = MagicMock(spec=BaseChatModel)
        failing_llm.bind_tools.return_value = failing_llm
        failing_llm.invoke.side_effect = RuntimeError("Fatal LLM Connection Timeout")

        worker = create_worker_node("adversarial_worker", tools=[], llm=failing_llm)
        state = create_initial_state(task_intent="Execute adversarial stress test")

        cmd = worker(state)
        assert isinstance(cmd, Command)
        assert cmd.goto == "supervisor"
        assert cmd.update["status"] == "FAILED"
        assert len(cmd.update["execution_history"]) == 1
        assert cmd.update["execution_history"][0]["status"] == "FAILED"
        assert "Fatal LLM Connection Timeout" in cmd.update["execution_history"][0]["error"]

    def test_worker_node_survives_missing_and_corrupted_state_fields(self):
        """
        If an incomplete or malformed state dict is passed to a worker,
        it should not raise KeyError or AttributeError.
        """
        corrupted_state: Any = {"task_intent": "Corrupted state test"}  # Missing messages, history, etc.
        worker = create_research_worker()

        cmd = worker(corrupted_state)
        assert isinstance(cmd, Command)
        assert cmd.goto == "supervisor"
        assert cmd.update["status"] == "RUNNING"
        assert len(cmd.update["execution_history"]) > 0

    def test_worker_tool_loop_exhaustion_limit(self):
        """
        If an LLM continuously emits tool calls indefinitely,
        max_tool_iterations MUST prevent an infinite inner loop.
        """
        mock_llm = MockToolChatModel()
        # Emits endless tool calls
        mock_llm.responses = [
            AIMessage(
                content=f"Loop {i}",
                tool_calls=[
                    {
                        "name": "execute_deep_research",
                        "args": {"topic": f"Loop {i}"},
                        "id": f"call_{i}",
                    }
                ],
            )
            for i in range(10)
        ]

        worker = create_research_worker(llm=mock_llm, max_tool_iterations=2)
        state = create_initial_state(task_intent="Test tool loop cap")

        cmd = worker(state)
        assert cmd.goto == "supervisor"
        # Since max_tool_iterations=2, exactly 2 tool calls should be executed
        tool_history = [
            e
            for e in cmd.update["execution_history"]
            if e["action"].startswith("tool_call:")
        ]
        assert len(tool_history) == 2

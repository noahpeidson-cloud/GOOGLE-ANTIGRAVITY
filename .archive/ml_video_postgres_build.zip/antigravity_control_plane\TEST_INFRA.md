# E2E Test Infra: Antigravity Control Plane

## Test Philosophy
- Requirement-driven, opaque-box testing verifying that the Hierarchical Supervisor LangGraph StateGraph executes correctly according to specification.
- Zero network or hardware flakiness: all external LLMs, database pools, ADB subshells, and APIs are mocked deterministically in test fixtures.
- Methodology: Category-Partition + Boundary Value Analysis + Pairwise Combinations + Real-World Workloads + Adversarial Hardening.

## Feature Inventory
| # | Feature | Source | Tier 1 | Tier 2 | Tier 3 |
|---|---------|--------|:------:|:------:|:------:|
| 1 | Typed State Management | ORIGINAL_REQUEST §R3 | 5 | 5 | ✓ |
| 2 | PostgreSQL Checkpointer Backend | ORIGINAL_REQUEST §R3 | 5 | 5 | ✓ |
| 3 | Context Pruning Engine | ORIGINAL_REQUEST §R3 | 5 | 5 | ✓ |
| 4 | Checkpointer Factory & Testing Fallback | ORIGINAL_REQUEST §R3 | 5 | 5 | ✓ |
| 5 | Social Deployer Worker Node | ORIGINAL_REQUEST §R2 | 5 | 5 | ✓ |
| 6 | Mobile Subsystem Worker Node | ORIGINAL_REQUEST §R2 | 5 | 5 | ✓ |
| 7 | Research Worker Node | ORIGINAL_REQUEST §R2 | 5 | 5 | ✓ |
| 8 | Worker `bind_tools` Action Engine | ORIGINAL_REQUEST §R2 | 5 | 5 | ✓ |
| 9 | Atomic Command Handoffs | ORIGINAL_REQUEST §R2 | 5 | 5 | ✓ |
| 10 | Inter-Worker Isolation | ORIGINAL_REQUEST §R2 | 5 | 5 | ✓ |
| 11 | Structured Output Decision Model | ORIGINAL_REQUEST §R1 | 5 | 5 | ✓ |
| 12 | Decision-First Routing Engine | ORIGINAL_REQUEST §R1 | 5 | 5 | ✓ |
| 13 | Supervisor StateGraph Topology | ORIGINAL_REQUEST §R1 | 5 | 5 | ✓ |
| 14 | Anti-Infinite-Loop Recursion Guard | ORIGINAL_REQUEST §Verification | 5 | 5 | ✓ |
| 15 | Canonical Single Entrypoint (`supervisor.py`) | ORIGINAL_REQUEST §Acceptance Criteria | 5 | 5 | ✓ |

## Test Architecture
- **Test Runner**: `pytest`
- **Invocation**: `pytest test_orchestrator.py` and `pytest tests/`
- **Pass/Fail Semantics**: 100% tests pass with exit code 0, execution time < 10 seconds.
- **Directory Layout**:
  - `tests/conftest.py`: Reusable mock LLM, mock tool responses, mock checkpointer fixtures.
  - `tests/test_state.py`: Typed state schema validation, `add_messages` reducer tests, `RemoveMessage` pruning tests.
  - `tests/test_db.py`: Connection pool configuration, `PostgresSaver` factory, test fallback tests.
  - `tests/test_workers.py`: Worker node unit tests, tool binding execution, `Command(update={...}, goto='supervisor')` verification.
  - `test_orchestrator.py`: Top-level integration & E2E DAG routing test suite required by user specification.

## Real-World Application Scenarios (Tier 4)
| # | Scenario | Features Exercised | Complexity |
|---|----------|--------------------|------------|
| 1 | Social Campaign Deployment: "Deploy this video asset to Facebook and log telemetry" | Supervisor routing -> Social Worker -> Tool execution -> Handoff -> Finish | Medium |
| 2 | Mobile ADB Automation: "Click the confirm button in Termux and verify UI tree" | Supervisor routing -> Mobile Worker (4-tier ADB tools) -> Handoff -> Finish | High |
| 3 | Deep Architectural Validation: "Validate our design proposal against workspace rules" | Supervisor routing -> Research Worker -> Rule query & Gemini eval -> Handoff -> Finish | High |
| 4 | Multi-Turn Complex Orchestration: "Deploy to Facebook, verify in mobile, and validate telemetry" | Multi-step DAG routing across sequential workers via Supervisor hub-and-spoke | Very High |
| 5 | Anti-Loop Exhaustion: Degraded worker failing to converge triggers recursion guard | Iteration limit reached -> graceful termination with status="FAILED" without hanging | Medium |

## Coverage Thresholds
- Tier 1 (Feature Coverage): >= 5 test cases per feature (Happy path isolation)
- Tier 2 (Boundary & Corner Cases): >= 5 test cases per feature (Empty payloads, invalid tools, max recursion limits)
- Tier 3 (Cross-Feature Combinations): Pairwise routing sequences between all workers
- Tier 4 (Real-World Application Scenarios): 5 comprehensive end-to-end user workflows
- Tier 5 (Adversarial Coverage Hardening): Edge cases, malformed LLM outputs, corrupted state recovery

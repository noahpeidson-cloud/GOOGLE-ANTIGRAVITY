"""
Pytest configuration and shared fixtures for Antigravity Control Plane tests.
Provides mock connection pools, mock checkpointers, mock structured LLMs, and sample state fixtures.
"""

from __future__ import annotations

import sys
from pathlib import Path
from typing import Any, Callable, Dict, Generator, List, Optional, Sequence, Tuple, Union
from unittest.mock import AsyncMock, MagicMock

import pytest
from langchain_core.language_models.chat_models import BaseChatModel
from langchain_core.messages import AIMessage, BaseMessage, HumanMessage, ToolMessage
from langchain_core.outputs import ChatGeneration, ChatResult
from langchain_core.runnables import Runnable
from langgraph.checkpoint.base import BaseCheckpointSaver
from langgraph.checkpoint.memory import MemorySaver
from psycopg import AsyncConnection, Connection
from psycopg_pool import AsyncConnectionPool, ConnectionPool

# Ensure project root is in sys.path
project_root = Path(__file__).resolve().parent.parent
if str(project_root) not in sys.path:
    sys.path.insert(0, str(project_root))

from schemas import RoutingDecision
from state import AgentState, create_initial_state


class MockStructuredChatModel(BaseChatModel):
    """
    Deterministic mock chat model supporting `with_structured_output` and `bind_tools`.
    Supports FIFO response queuing, dynamic response callbacks, and exception injection.
    """

    responses: List[Any] = []
    dynamic_responder: Optional[Callable[[List[BaseMessage]], Any]] = None

    def __init__(
        self,
        responses: Optional[List[Any]] = None,
        dynamic_responder: Optional[Callable[[List[BaseMessage]], Any]] = None,
        **kwargs: Any,
    ) -> None:
        super().__init__(
            responses=list(responses) if responses is not None else [],
            dynamic_responder=dynamic_responder,
            **kwargs,
        )

    @property
    def _llm_type(self) -> str:
        return "mock-structured-chat"

    def _generate(
        self,
        messages: List[BaseMessage],
        stop: Optional[List[str]] = None,
        run_manager: Optional[Any] = None,
        **kwargs: Any,
    ) -> ChatResult:
        if not self.responses:
            msg = AIMessage(content="Default mock text response")
            return ChatResult(generations=[ChatGeneration(message=msg)])

        resp = self.responses.pop(0) if self.responses else "Default mock text"
        if isinstance(resp, Exception):
            raise resp
        if isinstance(resp, BaseMessage):
            msg = resp
        elif isinstance(resp, dict):
            msg = AIMessage(content=resp.get("content", ""), tool_calls=resp.get("tool_calls", []))
        else:
            msg = AIMessage(content=str(resp))
        return ChatResult(generations=[ChatGeneration(message=msg)])

    def with_structured_output(self, schema: Any, **kwargs: Any) -> Runnable:
        parent = self

        class StructuredMockRunnable(Runnable):
            def invoke(self, input_val: Any, config: Optional[Any] = None) -> Any:
                if parent.dynamic_responder is not None:
                    msgs = input_val if isinstance(input_val, list) else [input_val]
                    res = parent.dynamic_responder(msgs)
                    if isinstance(res, Exception):
                        raise res
                    if isinstance(res, dict):
                        return schema(**res)
                    return res

                if not parent.responses:
                    return RoutingDecision(
                        next_node="FINISH",
                        reasoning="Default mock completion from structured model.",
                        instructions="Task finished.",
                    )

                resp = parent.responses.pop(0)
                if isinstance(resp, Exception):
                    raise resp
                if isinstance(resp, dict):
                    return schema(**resp)
                return resp

            async def ainvoke(self, input_val: Any, config: Optional[Any] = None) -> Any:
                return self.invoke(input_val, config)

        return StructuredMockRunnable()

    def bind_tools(self, tools: Sequence[Any], **kwargs: Any) -> Any:
        return self


@pytest.fixture
def mock_checkpointer() -> BaseCheckpointSaver:
    """Provides a deterministic in-memory checkpointer conforming to BaseCheckpointSaver."""
    return MemorySaver()


@pytest.fixture
def mock_db_pool() -> Tuple[MagicMock, MagicMock, MagicMock]:
    """
    Provides a spec-compliant mock ConnectionPool for PostgresSaver testing.
    Uses spec=ConnectionPool to pass isinstance(conn, ConnectionPool) checks.
    """
    mock_pool = MagicMock(spec=ConnectionPool)
    mock_conn = MagicMock(spec=Connection)
    mock_cursor = MagicMock()

    mock_pool.closed = False
    mock_pool.connection.return_value.__enter__.return_value = mock_conn
    mock_pool.connection.return_value.__exit__.return_value = None
    mock_conn.cursor.return_value.__enter__.return_value = mock_cursor
    mock_conn.cursor.return_value.__exit__.return_value = None
    mock_cursor.fetchone.return_value = {"v": -1}

    return mock_pool, mock_conn, mock_cursor


@pytest.fixture
def mock_async_db_pool() -> Tuple[MagicMock, MagicMock, MagicMock]:
    """
    Provides a spec-compliant mock AsyncConnectionPool for AsyncPostgresSaver testing.
    Uses spec=AsyncConnectionPool to pass isinstance(conn, AsyncConnectionPool) checks.
    """
    mock_apool = MagicMock(spec=AsyncConnectionPool)
    mock_aconn = MagicMock(spec=AsyncConnection)
    mock_acursor = MagicMock()

    mock_apool.closed = False
    mock_acursor.execute = AsyncMock()
    mock_acursor.fetchone = AsyncMock(return_value={"v": -1})
    mock_aconn.cursor.return_value.__aenter__ = AsyncMock(return_value=mock_acursor)
    mock_aconn.cursor.return_value.__aexit__ = AsyncMock(return_value=None)
    mock_apool.connection.return_value.__aenter__ = AsyncMock(return_value=mock_aconn)
    mock_apool.connection.return_value.__aexit__ = AsyncMock(return_value=None)

    return mock_apool, mock_aconn, mock_acursor


@pytest.fixture
def sample_initial_state() -> AgentState:
    """Provides a fresh canonical AgentState for testing."""
    return create_initial_state(
        task_intent="Deploy media asset to Facebook and verify via mobile screenshot.",
        max_iterations=10,
    )


@pytest.fixture
def sample_conversation_with_scratchpad() -> List[BaseMessage]:
    """Provides a multi-turn conversation sequence containing intermediate tool scratchpads."""
    return [
        HumanMessage(content="Deploy asset to Facebook", id="msg_0"),
        AIMessage(
            content="Initiating ADB upload...",
            id="msg_1",
            tool_calls=[{"name": "adb_push", "args": {"src": "/tmp/a.mp4"}, "id": "call_1"}],
        ),
        ToolMessage(content="File pushed successfully", tool_call_id="call_1", id="msg_2"),
        AIMessage(content="Asset deployed successfully to Facebook.", id="msg_3"),
    ]


@pytest.fixture
def mock_structured_llm() -> MockStructuredChatModel:
    """Provides a default MockStructuredChatModel instance."""
    return MockStructuredChatModel()


@pytest.fixture
def mock_supervisor_llm_factory() -> Callable[..., MockStructuredChatModel]:
    """Factory fixture returning custom-configured MockStructuredChatModel instances."""

    def _create(
        responses: Optional[List[Any]] = None,
        dynamic_responder: Optional[Callable[[List[BaseMessage]], Any]] = None,
    ) -> MockStructuredChatModel:
        return MockStructuredChatModel(responses=responses, dynamic_responder=dynamic_responder)

    return _create


@pytest.fixture
def mock_multi_turn_llm() -> MockStructuredChatModel:
    """Provides a mock LLM routing across multiple sequential workers: research -> social -> FINISH."""
    return MockStructuredChatModel(
        responses=[
            RoutingDecision(
                next_node="research_worker",
                reasoning="Research current trends and constraints first.",
                instructions="Query workspace rules and perform deep research.",
            ),
            RoutingDecision(
                next_node="social_worker",
                reasoning="Deploy generated assets to social channels.",
                instructions="Deploy assets to Facebook and log telemetry.",
            ),
            RoutingDecision(
                next_node="FINISH",
                reasoning="All pipeline phases completed successfully.",
                instructions="Multi-stage campaign executed and verified.",
            ),
        ]
    )


@pytest.fixture
def mock_failing_llm() -> MockStructuredChatModel:
    """Provides a mock LLM configured to throw an API exception during structured output."""
    return MockStructuredChatModel(
        responses=[RuntimeError("Simulated LLM API 503 Service Unavailable")]
    )

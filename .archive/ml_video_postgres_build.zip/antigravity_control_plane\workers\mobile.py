"""
Mobile Zero-Touch Worker Subsystem for Antigravity Control Plane.

Implements the 4-tier Android automation hierarchy:
Tier 1: Direct Dalvik / binary execution
Tier 2: Android Intent broadcasts / activity starts
Tier 3: UI Automator XML DOM parsing & center bounds tapping
Tier 4: Keystroke injection for sandboxed apps (e.g. Termux)
Plus pre-flight connectivity verification and device environment utilities.
"""

from __future__ import annotations

import json
import logging
import os
import re
import subprocess
import xml.etree.ElementTree as ET
from typing import Any, Callable, Dict, List, Optional, Sequence

from langchain_core.language_models.chat_models import BaseChatModel
from langchain_core.tools import BaseTool, tool
from langgraph.types import Command

from state import AgentState
from workers.base import create_worker_node

logger = logging.getLogger(__name__)

MOBILE_WORKER_SYSTEM_PROMPT = (
    "You are the Mobile Zero-Touch worker subsystem in the Antigravity Control Plane.\n"
    "Execute Android automation tasks using the 4-tier hierarchy:\n"
    "1. Pre-Flight: verify_device_connected to ensure ADB connectivity.\n"
    "2. Tier 1: execute_adb_shell for direct Dalvik/binary/shell execution.\n"
    "3. Tier 2: send_android_intent for intent broadcasts and activities without UI.\n"
    "4. Tier 3: uiautomator_tap_element for XML layout analysis and center coordinate tapping.\n"
    "5. Tier 4: inject_termux_command for Termux sandbox execution (staging, monkey launch, input text).\n"
    "6. Utilities: disable_samsung_autoblocker to prevent timeouts and grant_app_permission for runtime permissions.\n"
    "Never attempt interactive screen scraping or ask the user to manually click the screen."
)


def _format_adb_input_text(text: str) -> str:
    """
    Replaces spaces with '%s' and escapes shell special characters for ADB input text.
    """
    formatted = text.replace(" ", "%s")
    for char in ["$", "&", ";", "(", ")", "<", ">", "|", "'", '"']:
        formatted = formatted.replace(char, f"\\{char}")
    return formatted


@tool
def verify_device_connected(device_id: Optional[str] = None) -> Dict[str, Any]:
    """
    Pre-Flight Guardrail: Verifies that an Android device is physically connected,
    recognized by ADB daemon, and authorized for debugging.

    Args:
        device_id: Optional serial number of a specific target device.

    Returns:
        Dictionary indicating connection status, device list, and target device serial.
    """
    try:
        cmd = ["adb", "devices", "-l"]
        res = subprocess.run(cmd, capture_output=True, text=True, timeout=10)
        if res.returncode != 0:
            return {
                "status": "FAILED",
                "is_connected": False,
                "error": res.stderr.strip() or "ADB daemon command failed",
            }

        lines = [line.strip() for line in res.stdout.split("\n") if line.strip()]
        devices = []
        for line in lines[1:]:  # Skip 'List of devices attached' header
            parts = line.split()
            if len(parts) >= 2:
                serial, state = parts[0], parts[1]
                devices.append({"serial": serial, "state": state, "raw": line})

        if device_id:
            matched = next((d for d in devices if d["serial"] == device_id), None)
            if not matched or matched["state"] != "device":
                return {
                    "status": "FAILED",
                    "is_connected": False,
                    "device_id": device_id,
                    "error": f"Device {device_id} not found or unauthorized (state: {matched.get('state') if matched else 'not_found'})",
                }
            return {
                "status": "SUCCESS",
                "is_connected": True,
                "device_id": device_id,
                "details": matched,
            }

        authorized = [d for d in devices if d["state"] == "device"]
        if not authorized:
            return {
                "status": "FAILED",
                "is_connected": False,
                "error": "No authorized ADB devices detected",
                "devices": devices,
            }

        return {
            "status": "SUCCESS",
            "is_connected": True,
            "device_count": len(authorized),
            "target_device": authorized[0]["serial"],
            "devices": devices,
        }
    except FileNotFoundError:
        return {
            "status": "FAILED",
            "is_connected": False,
            "error": "ADB binary not found on system PATH",
        }
    except subprocess.TimeoutExpired:
        return {
            "status": "FAILED",
            "is_connected": False,
            "error": "ADB devices command timed out",
        }
    except Exception as exc:
        return {"status": "FAILED", "is_connected": False, "error": str(exc)}


@tool
def execute_adb_shell(
    command: str, device_id: Optional[str] = None, timeout: int = 30
) -> Dict[str, Any]:
    """
    Tier 1 Automation: Executes a shell command, Dalvik app_process binary,
    or system executable directly over ADB.

    Args:
        command: The shell command string to execute on the Android device.
        device_id: Optional target device serial.
        timeout: Execution timeout in seconds (default 30).

    Returns:
        Dictionary with status ('SUCCESS' or 'FAILED'), command, stdout, stderr, and exit_code.
    """
    if not command or not command.strip():
        return {"status": "FAILED", "error": "Command must not be empty"}
    try:
        cmd = ["adb"]
        if device_id:
            cmd.extend(["-s", device_id])
        cmd.extend(["shell", command])

        res = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        is_success = res.returncode == 0
        return {
            "status": "SUCCESS" if is_success else "FAILED",
            "command": command,
            "stdout": res.stdout.strip(),
            "stderr": res.stderr.strip(),
            "exit_code": res.returncode,
            "device_id": device_id,
            "error": res.stderr.strip() if not is_success else None,
        }
    except FileNotFoundError:
        return {"status": "FAILED", "command": command, "error": "ADB binary not found on system PATH"}
    except subprocess.TimeoutExpired:
        return {"status": "FAILED", "command": command, "error": f"Command timed out after {timeout} seconds"}
    except Exception as exc:
        return {"status": "FAILED", "command": command, "error": str(exc)}


@tool
def send_android_intent(
    action: str,
    data_uri: Optional[str] = None,
    extras: Optional[Dict[str, Any]] = None,
    component: Optional[str] = None,
    is_broadcast: bool = False,
    device_id: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Tier 2 Automation: Sends an Android Intent via am broadcast or am start
    to trigger actions without touching the UI.

    Args:
        action: Android intent action string (e.g. 'android.intent.action.VIEW', 'com.my.ACTION').
        data_uri: Optional URI string for the intent data.
        extras: Optional dictionary of key-value extras. Automatically maps booleans (--ez),
                integers (--ei), floats (--ef), and strings (-e).
        component: Optional target component name (e.g. 'com.example.pkg/.MyReceiver').
        is_broadcast: If True, uses 'am broadcast'; if False, uses 'am start'.
        device_id: Optional target device serial.

    Returns:
        Dictionary with execution status, intent type, action, constructed command, and output.
    """
    if not action or not action.strip():
        return {"status": "FAILED", "error": "Action must not be empty"}

    cmd_parts = ["am", "broadcast" if is_broadcast else "start", "-a", action]
    if data_uri:
        cmd_parts.extend(["-d", data_uri])
    if component:
        cmd_parts.extend(["-n", component])
    if extras:
        for k, v in extras.items():
            if isinstance(v, bool):
                cmd_parts.extend(["--ez", str(k), str(v).lower()])
            elif isinstance(v, int):
                cmd_parts.extend(["--ei", str(k), str(v)])
            elif isinstance(v, float):
                cmd_parts.extend(["--ef", str(k), str(v)])
            else:
                cmd_parts.extend(["-e", str(k), str(v)])

    full_cmd = " ".join(cmd_parts)
    res = execute_adb_shell.invoke({"command": full_cmd, "device_id": device_id})
    return {
        "status": res.get("status", "FAILED"),
        "intent_type": "broadcast" if is_broadcast else "activity",
        "action": action,
        "command": full_cmd,
        "output": res.get("stdout", ""),
        "error": res.get("error"),
    }


@tool
def uiautomator_tap_element(
    element_id: Optional[str] = None,
    text: Optional[str] = None,
    content_desc: Optional[str] = None,
    xml_dump_content: Optional[str] = None,
    device_id: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Tier 3 Automation: Dumps UI Automator XML layout, parses element bounding box mathematically,
    and taps center coordinates.

    Args:
        element_id: Optional Android resource-id (e.g. 'com.example.app:id/submit_btn').
        text: Optional element text or partial text match.
        content_desc: Optional accessibility content-description string.
        xml_dump_content: Optional raw XML layout string for offline/mock testing.
        device_id: Optional target device serial.

    Returns:
        Dictionary with status, matched element attributes, coordinates, and tap output.
    """
    try:
        xml_data = xml_dump_content
        if not xml_data:
            dump_res = execute_adb_shell.invoke(
                {
                    "command": "uiautomator dump /data/local/tmp/window_dump.xml",
                    "device_id": device_id,
                }
            )
            if dump_res.get("status") != "SUCCESS":
                return {
                    "status": "FAILED",
                    "error": f"Failed to dump UI hierarchy: {dump_res.get('error')}",
                }
            cat_res = execute_adb_shell.invoke(
                {
                    "command": "cat /data/local/tmp/window_dump.xml",
                    "device_id": device_id,
                }
            )
            xml_data = cat_res.get("stdout", "")

        if not xml_data or not xml_data.strip():
            return {"status": "FAILED", "error": "Empty UI hierarchy XML content"}

        root = ET.fromstring(xml_data)
        matched_node = None
        for node in root.iter():
            node_id = node.attrib.get("resource-id", "")
            node_text = node.attrib.get("text", "")
            node_desc = node.attrib.get("content-desc", "")

            if element_id and (element_id == node_id or element_id in node_id):
                matched_node = node
                break
            if text and (text.lower() == node_text.lower() or text.lower() in node_text.lower()):
                matched_node = node
                break
            if content_desc and (
                content_desc.lower() == node_desc.lower()
                or content_desc.lower() in node_desc.lower()
            ):
                matched_node = node
                break

        if matched_node is None:
            return {
                "status": "FAILED",
                "error": f"Element not found (element_id={element_id}, text={text}, content_desc={content_desc})",
            }

        bounds_str = matched_node.attrib.get("bounds", "")
        m = re.match(r"\[(\d+),(\d+)\]\[(\d+),(\d+)\]", bounds_str)
        if not m:
            return {
                "status": "FAILED",
                "error": f"Invalid element bounds attribute: {bounds_str}",
            }

        x1, y1, x2, y2 = [int(v) for v in m.groups()]
        center_x = (x1 + x2) // 2
        center_y = (y1 + y2) // 2

        tap_res = execute_adb_shell.invoke(
            {"command": f"input tap {center_x} {center_y}", "device_id": device_id}
        )
        return {
            "status": "SUCCESS",
            "matched_element": {
                "tag": matched_node.tag,
                "resource_id": matched_node.attrib.get("resource-id"),
                "text": matched_node.attrib.get("text"),
                "content_desc": matched_node.attrib.get("content-desc"),
                "bounds": [x1, y1, x2, y2],
            },
            "coordinates": {"x": center_x, "y": center_y},
            "output": tap_res.get("stdout", ""),
            "error": tap_res.get("error"),
        }
    except ET.ParseError as pe:
        return {"status": "FAILED", "error": f"XML parse error: {str(pe)}"}
    except Exception as exc:
        return {"status": "FAILED", "error": str(exc)}


@tool
def inject_termux_command(
    command: str,
    run_via_monkey: bool = True,
    push_staging_file: Optional[str] = None,
    staging_dest: str = "/sdcard/staging.sh",
    device_id: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Tier 4 Automation: Bypasses sandboxed Termux environment by staging files,
    bringing app to foreground via monkey, and injecting keystrokes.

    Args:
        command: Shell script or command string to inject into Termux.
        run_via_monkey: If True, uses 'monkey -p com.termux 1' to focus Termux.
        push_staging_file: Optional local file to stage to /sdcard/ on device.
        staging_dest: Destination path on device for staging file (default /sdcard/staging.sh).
        device_id: Optional target device serial.

    Returns:
        Dictionary with execution status, steps executed, and formatted text details.
    """
    steps: List[str] = []
    try:
        if push_staging_file:
            if not os.path.exists(push_staging_file):
                return {
                    "status": "FAILED",
                    "error": f"Staging file not found: {push_staging_file}",
                    "steps_executed": steps,
                }
            push_cmd = ["adb"]
            if device_id:
                push_cmd.extend(["-s", device_id])
            push_cmd.extend(["push", push_staging_file, staging_dest])
            subprocess.run(push_cmd, capture_output=True, text=True, timeout=30)
            steps.append("push_staging_file")

        if run_via_monkey:
            execute_adb_shell.invoke(
                {"command": "monkey -p com.termux 1", "device_id": device_id}
            )
            steps.append("launch_monkey_termux")

        formatted_text = _format_adb_input_text(command)
        execute_adb_shell.invoke(
            {"command": f"input text {formatted_text}", "device_id": device_id}
        )
        steps.append("inject_input_text")

        execute_adb_shell.invoke(
            {"command": "input keyevent 66", "device_id": device_id}
        )
        steps.append("send_keyevent_enter")

        return {
            "status": "SUCCESS",
            "raw_command": command,
            "formatted_text": formatted_text,
            "staging_dest": staging_dest if push_staging_file else None,
            "steps_executed": steps,
            "error": None,
        }
    except Exception as exc:
        return {
            "status": "FAILED",
            "raw_command": command,
            "error": str(exc),
            "steps_executed": steps,
        }


@tool
def disable_samsung_autoblocker(device_id: Optional[str] = None) -> Dict[str, Any]:
    """
    Environment Fix: Disables Samsung One UI 6.0+ Auto Blocker timeout to prevent
    automatic ADB connection drops.

    Args:
        device_id: Optional target device serial.

    Returns:
        Dictionary confirming the global setting modification.
    """
    res = execute_adb_shell.invoke(
        {
            "command": "settings put global rampart_auto_enabled_switch_enabled 0",
            "device_id": device_id,
        }
    )
    return {
        "status": "SUCCESS" if res.get("status") == "SUCCESS" else "FAILED",
        "setting": "rampart_auto_enabled_switch_enabled",
        "value": 0,
        "device_id": device_id,
        "error": res.get("error"),
    }


@tool
def grant_app_permission(
    package_name: str, permission: str, device_id: Optional[str] = None
) -> Dict[str, Any]:
    """
    Zero-Touch Permission Grant: Grants runtime permissions via ADB package manager
    to avoid UI permission prompts.

    Args:
        package_name: Target application package name (e.g. 'com.termux').
        permission: Android permission string (e.g. 'android.permission.POST_NOTIFICATIONS').
        device_id: Optional target device serial.

    Returns:
        Dictionary confirming permission grant status.
    """
    res = execute_adb_shell.invoke(
        {"command": f"pm grant {package_name} {permission}", "device_id": device_id}
    )
    is_success = res.get("status") == "SUCCESS" and res.get("exit_code", 0) == 0
    return {
        "status": "SUCCESS" if is_success else "FAILED",
        "package_name": package_name,
        "permission": permission,
        "output": res.get("stdout", ""),
        "error": res.get("error"),
    }


MOBILE_TOOLS: List[BaseTool] = [
    verify_device_connected,
    execute_adb_shell,
    send_android_intent,
    uiautomator_tap_element,
    inject_termux_command,
    disable_samsung_autoblocker,
    grant_app_permission,
]


def create_mobile_worker(
    llm: Optional[BaseChatModel] = None,
    tools: Optional[Sequence[BaseTool]] = None,
    system_prompt: Optional[str] = None,
    max_tool_iterations: int = 3,
) -> Callable[[AgentState], Command]:
    """
    Factory creating a configured mobile_worker node instance.
    """
    resolved_tools = tools if tools is not None else MOBILE_TOOLS
    resolved_prompt = system_prompt or MOBILE_WORKER_SYSTEM_PROMPT

    return create_worker_node(
        worker_name="mobile_worker",
        tools=resolved_tools,
        llm=llm,
        system_prompt=resolved_prompt,
        max_tool_iterations=max_tool_iterations,
        goto_target="supervisor",
    )


# Canonical default mobile worker node
mobile_worker = create_mobile_worker()
mobile_worker_node = mobile_worker

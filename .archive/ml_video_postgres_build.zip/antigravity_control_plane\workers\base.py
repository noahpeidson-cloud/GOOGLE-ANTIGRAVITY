"""
Base Worker Node Architecture & Command Handoff Utilities for Antigravity Control Plane.

Provides generic worker node builder, tool invocation runner, audit history logging,
and crash-proof Command(update={...}, goto='supervisor') transitions.
"""

from __future__ import annotations

import json
import logging
from typing import Any, Callable, Dict, List, Optional, Sequence, Tuple

from langchain_core.language_models.chat_models import BaseChatModel
from langchain_core.messages import (
    AIMessage,
    BaseMessage,
    HumanMessage,
    SystemMessage,
    ToolMessage,
)
from langchain_core.tools import BaseTool
from langgraph.types import Command

from state import AgentState, create_history_entry

logger = logging.getLogger(__name__)


def execute_tool_call(
    tool_map: Dict[str, BaseTool],
    tool_call: Dict[str, Any],
    worker_name: str = "worker",
) -> Tuple[ToolMessage, Dict[str, Any]]:
    """
    Safely executes a single tool call dictionary, catching errors and generating an audit entry.

    Args:
        tool_map: Dictionary mapping tool names to BaseTool instances.
        tool_call: Tool call specification dictionary containing 'name', 'args', and 'id'.
        worker_name: Name of the worker node for audit logging.

    Returns:
        Tuple of (ToolMessage, history_entry_dict).
    """
    tool_name = tool_call.get("name", "")
    tool_args = tool_call.get("args", {})
    tool_id = tool_call.get("id") or f"call_{tool_name}"

    if isinstance(tool_args, str):
        try:
            tool_args = json.loads(tool_args)
        except Exception:
            tool_args = {"input": tool_args}

    tool = tool_map.get(tool_name)
    if not tool:
        err_msg = f"Tool '{tool_name}' not found in registered tools for {worker_name}."
        logger.warning(err_msg)
        history_entry = create_history_entry(
            node=worker_name,
            action=f"tool_call:{tool_name}",
            status="FAILED",
            error=err_msg,
            details={"tool_name": tool_name, "args": tool_args},
        )
        tool_msg = ToolMessage(
            content=json.dumps({"status": "FAILED", "error": err_msg}),
            tool_call_id=tool_id,
            status="error",
            name=tool_name,
        )
        return tool_msg, history_entry

    try:
        if isinstance(tool_args, dict):
            res = tool.invoke(tool_args)
        else:
            res = tool.invoke(tool_args)

        is_failed = isinstance(res, dict) and res.get("status") == "FAILED"
        status_val = "FAILED" if is_failed else "SUCCESS"
        error_val = res.get("error") if isinstance(res, dict) and is_failed else None

        content_str = json.dumps(res, default=str) if isinstance(res, (dict, list)) else str(res)
        history_entry = create_history_entry(
            node=worker_name,
            action=f"tool_call:{tool_name}",
            status=status_val,
            result=res,
            error=error_val,
            details={"tool_name": tool_name, "args": tool_args},
        )
        tool_msg = ToolMessage(
            content=content_str,
            tool_call_id=tool_id,
            status="error" if is_failed else "success",
            name=tool_name,
        )
        return tool_msg, history_entry
    except Exception as exc:
        err_msg = f"Error executing tool '{tool_name}': {str(exc)}"
        logger.exception(err_msg)
        history_entry = create_history_entry(
            node=worker_name,
            action=f"tool_call:{tool_name}",
            status="FAILED",
            error=str(exc),
            details={"tool_name": tool_name, "args": tool_args},
        )
        tool_msg = ToolMessage(
            content=json.dumps({"status": "FAILED", "error": err_msg}),
            tool_call_id=tool_id,
            status="error",
            name=tool_name,
        )
        return tool_msg, history_entry


def create_worker_node(
    worker_name: str,
    tools: Sequence[BaseTool],
    llm: Optional[BaseChatModel] = None,
    system_prompt: Optional[str] = None,
    max_tool_iterations: int = 3,
    goto_target: str = "supervisor",
) -> Callable[[AgentState], Command]:
    """
    Generic Worker Node Factory. Constructs an isolated, stateless worker node that binds
    tools, executes actions, records audit history, and returns atomic Command handoffs.

    Args:
        worker_name: Unique identifier for the worker node (e.g. 'research_worker').
        tools: Sequence of BaseTool instances available to this worker.
        llm: Optional BaseChatModel instance. If None, worker operates in fallback deterministic mode.
        system_prompt: Role-specific instructions for the worker.
        max_tool_iterations: Maximum inner tool-calling loops per invocation turn.
        goto_target: Destination node name for LangGraph Command handoff (strictly 'supervisor').

    Returns:
        Callable worker node function conforming to LangGraph node signature.
    """
    tool_list = list(tools)
    tool_map: Dict[str, BaseTool] = {t.name: t for t in tool_list}
    resolved_prompt = system_prompt or f"You are the {worker_name} for the Antigravity Control Plane."

    def worker_node(state: AgentState) -> Command:
        try:
            # 1. State extraction & context assembly
            task_intent = state.get("task_intent", "")
            raw_messages = list(state.get("messages", []))
            history_entries: List[Dict[str, Any]] = []
            new_messages: List[BaseMessage] = []

            # Prepare worker messages
            worker_msgs: List[BaseMessage] = [SystemMessage(content=resolved_prompt)]
            if raw_messages:
                worker_msgs.extend(raw_messages)
            elif task_intent:
                worker_msgs.append(HumanMessage(content=task_intent))

            # 2. Execution path with LLM or fallback
            if llm is not None and hasattr(llm, "bind_tools"):
                bound_llm = llm.bind_tools(tool_list)
                turn_count = 0
                current_msgs = list(worker_msgs)

                while turn_count < max_tool_iterations:
                    ai_response = bound_llm.invoke(current_msgs)
                    new_messages.append(ai_response)
                    current_msgs.append(ai_response)

                    tool_calls = getattr(ai_response, "tool_calls", None)
                    if not tool_calls:
                        break

                    for tc in tool_calls:
                        t_msg, h_entry = execute_tool_call(tool_map, tc, worker_name=worker_name)
                        new_messages.append(t_msg)
                        current_msgs.append(t_msg)
                        history_entries.append(h_entry)

                    turn_count += 1
            else:
                # Deterministic fallback when no LLM provided
                fallback_msg = AIMessage(
                    content=f"[{worker_name}] Executed deterministic task intent: {task_intent}"
                )
                new_messages.append(fallback_msg)
                history_entries.append(
                    create_history_entry(
                        node=worker_name,
                        action="deterministic_execution",
                        status="SUCCESS",
                        details={"task_intent": task_intent},
                    )
                )

            # 3. Compile atomic handoff
            summary = f"[{worker_name}] Completed actions for intent: {task_intent[:50]}"
            history_entries.append(
                create_history_entry(
                    node=worker_name,
                    action="handoff_to_supervisor",
                    status="SUCCESS",
                    details={"messages_added": len(new_messages)},
                )
            )

            update_payload: Dict[str, Any] = {
                "messages": new_messages,
                "execution_history": history_entries,
                "summary": summary,
                "status": "RUNNING",
                "next_worker": None,
            }

            return Command(update=update_payload, goto=goto_target)

        except Exception as exc:
            logger.exception("Worker %s encountered fatal error: %s", worker_name, exc)
            err_entry = create_history_entry(
                node=worker_name,
                action="worker_error",
                status="FAILED",
                error=str(exc),
            )
            err_msg = AIMessage(content=f"Worker '{worker_name}' failed with error: {str(exc)}")
            return Command(
                update={
                    "messages": [err_msg],
                    "execution_history": [err_entry],
                    "status": "FAILED",
                    "next_worker": None,
                },
                goto=goto_target,
            )

    worker_node.__name__ = worker_name
    return worker_node

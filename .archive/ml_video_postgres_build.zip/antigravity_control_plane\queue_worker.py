import os
import time
import uuid
import json
import logging
from dotenv import load_dotenv

# Ensure environment variables are loaded
load_dotenv()

from psycopg_pool import ConnectionPool
from db import create_connection_pool, setup_event_queue, get_checkpointer
from supervisor import create_control_plane_graph

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s")
logger = logging.getLogger("QueueWorker")

def process_queue(pool: ConnectionPool, graph, checkpointer):
    with pool.connection() as conn:
        with conn.cursor() as cur:
            # Atomic SELECT FOR UPDATE SKIP LOCKED
            cur.execute("""
                UPDATE event_queue
                SET status = 'processing', updated_at = CURRENT_TIMESTAMP
                WHERE id = (
                    SELECT id FROM event_queue
                    WHERE status = 'pending'
                    ORDER BY created_at ASC
                    FOR UPDATE SKIP LOCKED
                    LIMIT 1
                )
                RETURNING id, payload;
            """)
            row = cur.fetchone()
            
            if not row:
                return False
                
            job_id, payload = row
            conn.commit()
            
            logger.info(f"Processing job {job_id}")
            
            try:
                thread_id = str(job_id)
                config = {"configurable": {"thread_id": thread_id}}
                
                action = payload.get("action", "unknown")
                if action == "adb_pull":
                    user_msg = f"Execute an ADB pull with the following parameters: {json.dumps(payload)}"
                else:
                    user_msg = f"Process this event: {json.dumps(payload)}"
                
                final_state = graph.invoke(
                    {"messages": [("user", user_msg)]},
                    config=config
                )
                
                cur.execute("""
                    UPDATE event_queue
                    SET status = 'completed', updated_at = CURRENT_TIMESTAMP
                    WHERE id = %s
                """, (job_id,))
                conn.commit()
                logger.info(f"Job {job_id} completed successfully.")
                
            except Exception as e:
                logger.error(f"Job {job_id} failed: {e}")
                cur.execute("""
                    UPDATE event_queue
                    SET status = 'failed', updated_at = CURRENT_TIMESTAMP
                    WHERE id = %s
                """, (job_id,))
                conn.commit()
                
            return True

def main():
    db_url = os.getenv("DATABASE_URL")
    if not db_url:
        logger.error("DATABASE_URL not set.")
        return
        
    logger.info("Starting Postgres Event Queue Worker...")
    
    pool = create_connection_pool(db_url, min_size=1, max_size=5)
    setup_event_queue(pool)
    
    checkpointer = get_checkpointer(pool=pool, auto_setup=True)
    graph = create_control_plane_graph(checkpointer=checkpointer)
    
    try:
        while True:
            processed = process_queue(pool, graph, checkpointer)
            if not processed:
                time.sleep(2.0)
    except KeyboardInterrupt:
        logger.info("Worker shutting down...")
    finally:
        pool.close()

if __name__ == "__main__":
    main()

"""
State Management & Typed Schema Module for Antigravity Control Plane.
Defines AgentState, reducers, and context pruning mechanics.
"""

from __future__ import annotations

import datetime
import operator
from typing import Annotated, Any, Dict, List, Literal, Optional, Sequence, TypedDict

from langchain_core.messages import (
    AIMessage,
    BaseMessage,
    HumanMessage,
    RemoveMessage,
    SystemMessage,
    ToolMessage,
)
from langgraph.graph.message import add_messages
from pydantic import BaseModel, Field


class AgentState(TypedDict):
    """
    Global state container for the Antigravity Control Plane StateGraph.

    Fields:
        messages: Sequence of chat and tool messages with LangGraph's add_messages reducer.
        next_worker: Target worker node ('social_worker', 'mobile_worker', 'research_worker', or None/'FINISH').
        task_intent: High-level classification of user goal extracted by Supervisor.
        execution_history: Append-only audit trail tracking every node action, status, and payload.
        summary: Running textual summary of context/actions when pruning intermediate messages.
        iteration_count: Monotonically increasing counter incremented on each supervisor turn for loop safety.
        max_iterations: Safety threshold before recursion guard halts execution.
        status: Lifecycle state ('IDLE', 'PENDING', 'RUNNING', 'COMPLETED', 'FAILED', 'TERMINATED_LOOP_LIMIT').
    """

    messages: Annotated[Sequence[BaseMessage], add_messages]
    next_worker: Optional[str]
    task_intent: str
    execution_history: Annotated[List[Dict[str, Any]], operator.add]
    summary: str
    iteration_count: int
    max_iterations: int
    status: str


class AgentStateValidator(BaseModel):
    """
    Pydantic model for runtime schema validation of state transitions.
    """

    task_intent: str
    next_worker: Optional[str] = None
    summary: str = ""
    iteration_count: int = Field(ge=0, default=0)
    max_iterations: int = Field(gt=0, default=10)
    status: Literal[
        "IDLE",
        "PENDING",
        "RUNNING",
        "COMPLETED",
        "FAILED",
        "TERMINATED_LOOP_LIMIT",
        "MAX_ITERATIONS_REACHED",
    ] = "IDLE"
    execution_history: List[Dict[str, Any]] = Field(default_factory=list)


def create_initial_state(
    user_input: str = "",
    task_intent: Optional[str] = None,
    messages: Optional[Sequence[BaseMessage]] = None,
    max_iterations: int = 10,
    system_prompt: Optional[str] = None,
    status: str = "IDLE",
    **kwargs: Any,
) -> AgentState:
    """
    Constructs a clean initial AgentState dictionary with standard defaults.

    Args:
        user_input: The primary user prompt or initial task description.
        task_intent: Optional explicit task intent classification. If omitted, defaults to user_input.
        messages: Optional explicit list of pre-constructed messages.
        max_iterations: Safety iteration threshold for loop guard (default 10).
        system_prompt: Optional system prompt to prepend.
        status: Initial status string (default 'IDLE').
        **kwargs: Additional key-value overrides.

    Returns:
        A fully initialized AgentState dictionary.
    """
    resolved_intent = task_intent if task_intent is not None else user_input

    if messages is not None:
        msg_list: List[BaseMessage] = list(messages)
    else:
        msg_list = []
        if system_prompt:
            msg_list.append(SystemMessage(content=system_prompt))
        if user_input:
            msg_list.append(HumanMessage(content=user_input))
        elif resolved_intent:
            msg_list.append(HumanMessage(content=resolved_intent))

    state_dict: AgentState = {
        "messages": msg_list,
        "next_worker": kwargs.get("next_worker", None),
        "task_intent": resolved_intent,
        "execution_history": kwargs.get("execution_history", []),
        "summary": kwargs.get("summary", ""),
        "iteration_count": kwargs.get("iteration_count", 0),
        "max_iterations": max_iterations,
        "status": status,
    }
    return state_dict


def create_history_entry(
    node: Optional[str] = None,
    action: str = "",
    details: Optional[Dict[str, Any]] = None,
    status: str = "SUCCESS",
    worker: Optional[str] = None,
    result: Any = None,
    error: Optional[str] = None,
    **kwargs: Any,
) -> Dict[str, Any]:
    """
    Constructs a standardized ISO-timestamped audit history record.

    Compatible with both node-oriented and worker-oriented dispatch conventions.

    Args:
        node: The node name (e.g. 'supervisor', 'social_worker').
        action: Short action description (e.g. 'route', 'deploy', 'query').
        details: Optional dict of arbitrary execution details.
        status: Execution status ('SUCCESS', 'FAILED', 'RUNNING', etc.).
        worker: Alias for node if worker is passed instead.
        result: Optional result summary or payload.
        error: Optional error message string if failed.
        **kwargs: Extra attributes to include in the entry.

    Returns:
        A dictionary representing the history record.
    """
    resolved_node = node or worker or "unknown_node"
    resolved_details = dict(details) if details is not None else {}
    if result is not None and "result" not in resolved_details:
        resolved_details["result"] = result
    if error is not None and "error" not in resolved_details:
        resolved_details["error"] = error

    entry: Dict[str, Any] = {
        "node": resolved_node,
        "worker": resolved_node,
        "action": action,
        "details": resolved_details,
        "status": status,
        "result": result,
        "error": error,
        "timestamp": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    }
    for k, v in kwargs.items():
        if k not in entry:
            entry[k] = v

    return entry


def prune_message_history(
    messages: Sequence[BaseMessage],
    max_messages: int = 10,
    preserve_first_n: int = 1,
    preserve_first_user_message: bool = True,
) -> List[RemoveMessage]:
    """
    Identifies intermediate messages to prune when total messages exceed max_messages.

    Preserves the initial `preserve_first_n` messages (e.g. root prompt or system message)
    and the most recent `(max_messages - preserve_first_n)` messages.

    Args:
        messages: Sequence of BaseMessage objects currently in state.
        max_messages: Maximum number of active messages to keep in context.
        preserve_first_n: Number of leading messages to strictly preserve.
        preserve_first_user_message: If True and preserve_first_n is unset, preserves the first HumanMessage.

    Returns:
        List of RemoveMessage instances targeted for removal by add_messages reducer.
    """
    if len(messages) <= max_messages:
        return []

    total = len(messages)
    effective_preserve = preserve_first_n

    if effective_preserve < 0:
        effective_preserve = 0
    if effective_preserve > total:
        effective_preserve = total

    keep_tail = max(0, max_messages - effective_preserve)

    if keep_tail > 0:
        to_remove = messages[effective_preserve : total - keep_tail]
    else:
        to_remove = messages[effective_preserve:]

    removals: List[RemoveMessage] = []
    for m in to_remove:
        msg_id = getattr(m, "id", None)
        if msg_id:
            removals.append(RemoveMessage(id=msg_id))

    return removals


def prune_intermediate_scratchpad(
    messages: Sequence[BaseMessage],
) -> List[RemoveMessage]:
    """
    Prunes intermediate ToolMessages and assistant tool-call messages to collapse scratchpad.

    Removes verbose tool execution traces while leaving final assistant synthesis intact.

    Args:
        messages: Sequence of BaseMessage objects.

    Returns:
        List of RemoveMessage instances for all ToolMessages and tool-calling AIMessages.
    """
    removals: List[RemoveMessage] = []
    for msg in messages:
        msg_id = getattr(msg, "id", None)
        if not msg_id:
            continue
        if isinstance(msg, ToolMessage):
            removals.append(RemoveMessage(id=msg_id))
        elif isinstance(msg, AIMessage) and bool(getattr(msg, "tool_calls", None)):
            removals.append(RemoveMessage(id=msg_id))
    return removals


def format_state_summary(state: AgentState) -> str:
    """
    Compiles a human-readable summary of current workflow state.

    Args:
        state: The AgentState dictionary.

    Returns:
        A single-line formatted summary string.
    """
    intent = state.get("task_intent") or "N/A"
    status = state.get("status") or "IDLE"
    iteration = state.get("iteration_count", 0)
    max_iter = state.get("max_iterations", 10)
    history_len = len(state.get("execution_history") or [])
    msg_len = len(state.get("messages") or [])

    return (
        f"Intent: {intent} | "
        f"Status: {status} | "
        f"Iteration: {iteration}/{max_iter} | "
        f"History Count: {history_len} | "
        f"Messages: {msg_len}"
    )

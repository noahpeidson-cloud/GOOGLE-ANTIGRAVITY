"""
Schemas and structured output models for Antigravity Control Plane.

Defines Pydantic schemas for the Decision-First routing engine, supervisor logs,
and runtime execution configuration.
"""

from __future__ import annotations

import datetime
from typing import Any, Dict, List, Literal, Optional
from pydantic import BaseModel, Field, ConfigDict, field_validator


# Target destination node literals
WorkerNodeName = Literal["social_worker", "mobile_worker", "research_worker"]
RoutingTarget = Literal["social_worker", "mobile_worker", "research_worker", "FINISH"]
WorkflowStatusType = Literal[
    "IDLE",
    "PENDING",
    "RUNNING",
    "COMPLETED",
    "FAILED",
    "TERMINATED_LOOP_LIMIT",
    "MAX_ITERATIONS_REACHED",
]


class RoutingDecision(BaseModel):
    """
    Structured output decision schema produced by the Supervisor routing model.
    Enforces Decision-First routing without tool calling.
    """

    model_config = ConfigDict(extra="ignore", str_strip_whitespace=True)

    next_node: Literal["social_worker", "mobile_worker", "research_worker", "FINISH"] = Field(
        ...,
        description="The target worker node destination or FINISH if the task has been fully completed.",
    )
    reasoning: str = Field(
        default="",
        description="Step-by-step logical justification for the selected routing decision.",
    )
    instructions: str = Field(
        default="",
        description="Actionable instructions for the target worker node, or final executive summary if FINISH.",
    )


class ControlPlaneConfig(BaseModel):
    """
    Runtime execution configuration for the Control Plane StateGraph.
    """

    model_config = ConfigDict(extra="ignore", str_strip_whitespace=True)

    thread_id: str = Field(
        default="default_thread",
        description="Checkpoint thread identifier for state persistence.",
    )
    max_iterations: int = Field(
        default=10,
        ge=1,
        le=100,
        description="Maximum supervisor recursion iterations before guard halts execution.",
    )
    checkpointer_type: Literal["memory", "postgres", "none"] = Field(
        default="memory",
        description="Checkpointer backend type.",
    )
    verbose: bool = Field(
        default=False,
        description="Whether to log detailed intermediate node transitions.",
    )


class SupervisorDecisionLog(BaseModel):
    """
    Audit log record capturing an individual supervisor routing decision.
    """

    model_config = ConfigDict(extra="ignore", str_strip_whitespace=True)

    iteration: int = Field(ge=0, description="Supervisor iteration counter at decision time.")
    target: RoutingTarget = Field(description="Target destination chosen.")
    reasoning: str = Field(default="", description="Reasoning provided by the router.")
    instructions: str = Field(default="", description="Instructions passed to the target worker.")
    timestamp: str = Field(
        default_factory=lambda: datetime.datetime.now(datetime.timezone.utc).isoformat(),
        description="ISO 8601 UTC timestamp of the decision.",
    )
    status: str = Field(default="SUCCESS", description="Decision outcome status.")


class WorkerHandoffPayload(BaseModel):
    """
    Schema validating the payload returned by workers upon handoff.
    """

    model_config = ConfigDict(extra="ignore")

    worker_name: str = Field(description="Name of the worker that executed actions.")
    action: str = Field(description="Action summary or primary tool invoked.")
    status: Literal["SUCCESS", "FAILED", "RUNNING"] = Field(default="SUCCESS")
    summary: str = Field(default="", description="Worker execution summary.")
    details: Dict[str, Any] = Field(default_factory=dict)
    error: Optional[str] = Field(default=None)


__all__ = [
    "WorkerNodeName",
    "RoutingTarget",
    "WorkflowStatusType",
    "RoutingDecision",
    "ControlPlaneConfig",
    "SupervisorDecisionLog",
    "WorkerHandoffPayload",
]

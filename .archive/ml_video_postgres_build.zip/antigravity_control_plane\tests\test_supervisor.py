"""
Comprehensive 5-Tier Unit and Integration Test Suite for Central Supervisor Orchestrator.

Validates:
- Tier 1: Feature Coverage (Decision schemas, Decision-First routing, Hub-and-Spoke topology)
- Tier 2: Boundary & Corner Cases (Loop recursion limits, empty inputs, malformed outputs)
- Tier 3: Cross-Feature Combinations & Checkpointer Persistence (Sync & Async checkpointers)
- Tier 4: Real-World Application Scenarios (Social, Mobile, Research, Multi-turn workflows)
- Tier 5: Adversarial Hardening & Stress Testing (LLM faults, concurrency, corrupted state recovery)
"""

from __future__ import annotations

import asyncio
from concurrent.futures import ThreadPoolExecutor
from typing import Any, Dict, List
from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from langchain_core.messages import AIMessage, BaseMessage, HumanMessage, SystemMessage
from langgraph.checkpoint.memory import MemorySaver
from langgraph.checkpoint.postgres import PostgresSaver
from langgraph.checkpoint.postgres.aio import AsyncPostgresSaver
from langgraph.graph import END, START
from langgraph.types import Command
from pydantic import ValidationError

from db import create_connection_pool, get_async_checkpointer, get_checkpointer
from prompts import SUPERVISOR_SYSTEM_PROMPT
from schemas import (
    ControlPlaneConfig,
    RoutingDecision,
    SupervisorDecisionLog,
    WorkerHandoffPayload,
)
from state import AgentState, create_history_entry, create_initial_state
from supervisor import (
    VALID_ROUTING_TARGETS,
    async_run_control_plane,
    create_control_plane_graph,
    create_supervisor_node,
    deterministic_fallback_router,
    run_control_plane,
    supervisor_node,
)
from tests.conftest import MockStructuredChatModel


# ============================================================================
# Tier 1: Feature Coverage (Happy Path & Schema Validation)
# ============================================================================


class TestTier1FeatureCoverage:
    """Tier 1: Feature coverage for schemas, supervisor node, and StateGraph compilation."""

    @pytest.mark.parametrize(
        "target_node",
        ["social_worker", "mobile_worker", "research_worker", "FINISH"],
    )
    def test_routing_decision_schema_valid_nodes(self, target_node: str) -> None:
        """Validates instantiation of RoutingDecision with all valid target literals."""
        decision = RoutingDecision(
            next_node=target_node,  # type: ignore[arg-type]
            reasoning=f"Routing to {target_node} for domain execution.",
            instructions=f"Execute tasks on {target_node}.",
        )
        assert decision.next_node == target_node
        assert len(decision.reasoning) > 0
        assert len(decision.instructions) > 0

    def test_routing_decision_defaults_and_serialization(self) -> None:
        """Validates default values and JSON serialization/deserialization."""
        decision = RoutingDecision(next_node="FINISH")
        assert decision.next_node == "FINISH"
        assert decision.reasoning == ""
        assert decision.instructions == ""

        dumped = decision.model_dump()
        assert dumped["next_node"] == "FINISH"
        assert dumped["reasoning"] == ""

        json_str = decision.model_dump_json()
        restored = RoutingDecision.model_validate_json(json_str)
        assert restored.next_node == "FINISH"

    def test_control_plane_config_validation(self) -> None:
        """Validates ControlPlaneConfig defaults and boundary limits."""
        config = ControlPlaneConfig()
        assert config.thread_id == "default_thread"
        assert config.max_iterations == 10
        assert config.checkpointer_type == "memory"
        assert config.verbose is False

        custom = ControlPlaneConfig(thread_id="test_run_1", max_iterations=25, verbose=True)
        assert custom.thread_id == "test_run_1"
        assert custom.max_iterations == 25
        assert custom.verbose is True

        with pytest.raises(ValidationError):
            ControlPlaneConfig(max_iterations=0)

    def test_supervisor_decision_log_model(self) -> None:
        """Validates SupervisorDecisionLog audit model."""
        log_entry = SupervisorDecisionLog(
            iteration=1,
            target="social_worker",
            reasoning="Deploy media",
            instructions="Run ADB",
        )
        assert log_entry.iteration == 1
        assert log_entry.target == "social_worker"
        assert log_entry.status == "SUCCESS"
        assert len(log_entry.timestamp) > 0

    def test_worker_handoff_payload_model(self) -> None:
        """Validates WorkerHandoffPayload model."""
        payload = WorkerHandoffPayload(
            worker_name="mobile_worker",
            action="adb_tap",
            status="SUCCESS",
            summary="Tapped button",
            details={"x": 100, "y": 200},
        )
        assert payload.worker_name == "mobile_worker"
        assert payload.status == "SUCCESS"
        assert payload.details["x"] == 100

    def test_supervisor_node_routes_to_social_worker(
        self, mock_supervisor_llm_factory: Any
    ) -> None:
        """Verifies supervisor_node delegates to social_worker via structured output Command."""
        mock_llm = mock_supervisor_llm_factory(
            responses=[
                RoutingDecision(
                    next_node="social_worker",
                    reasoning="Deploy asset to Facebook",
                    instructions="Execute ADB Facebook intent broadcast",
                )
            ]
        )
        node_fn = create_supervisor_node(llm=mock_llm)
        state = create_initial_state(user_input="Deploy asset to Facebook")

        cmd = node_fn(state)
        assert isinstance(cmd, Command)
        assert cmd.goto == "social_worker"
        assert cmd.update["status"] == "RUNNING"
        assert cmd.update["next_worker"] == "social_worker"
        assert cmd.update["iteration_count"] == 1
        assert any("social_worker" in msg.content for msg in cmd.update["messages"])

    def test_supervisor_node_routes_to_mobile_worker(
        self, mock_supervisor_llm_factory: Any
    ) -> None:
        """Verifies supervisor_node delegates to mobile_worker via structured output Command."""
        mock_llm = mock_supervisor_llm_factory(
            responses=[
                RoutingDecision(
                    next_node="mobile_worker",
                    reasoning="Click button on mobile device",
                    instructions="Execute Termux injection",
                )
            ]
        )
        node_fn = create_supervisor_node(llm=mock_llm)
        state = create_initial_state(user_input="Click button in Termux")

        cmd = node_fn(state)
        assert isinstance(cmd, Command)
        assert cmd.goto == "mobile_worker"
        assert cmd.update["status"] == "RUNNING"
        assert cmd.update["next_worker"] == "mobile_worker"
        assert cmd.update["iteration_count"] == 1

    def test_supervisor_node_routes_to_research_worker(
        self, mock_supervisor_llm_factory: Any
    ) -> None:
        """Verifies supervisor_node delegates to research_worker via structured output Command."""
        mock_llm = mock_supervisor_llm_factory(
            responses=[
                RoutingDecision(
                    next_node="research_worker",
                    reasoning="Perform rule search",
                    instructions="Query workspace rules database",
                )
            ]
        )
        node_fn = create_supervisor_node(llm=mock_llm)
        state = create_initial_state(user_input="Audit workspace against rules")

        cmd = node_fn(state)
        assert isinstance(cmd, Command)
        assert cmd.goto == "research_worker"
        assert cmd.update["status"] == "RUNNING"
        assert cmd.update["next_worker"] == "research_worker"
        assert cmd.update["iteration_count"] == 1

    def test_supervisor_node_finishes_to_end(self, mock_supervisor_llm_factory: Any) -> None:
        """Verifies supervisor_node transitions to END when next_node is FINISH."""
        mock_llm = mock_supervisor_llm_factory(
            responses=[
                RoutingDecision(
                    next_node="FINISH",
                    reasoning="All tasks complete",
                    instructions="Executive summary: Workflow completed successfully.",
                )
            ]
        )
        node_fn = create_supervisor_node(llm=mock_llm)
        state = create_initial_state(user_input="Task already done")

        cmd = node_fn(state)
        assert isinstance(cmd, Command)
        assert cmd.goto == END
        assert cmd.update["status"] == "COMPLETED"
        assert cmd.update["next_worker"] is None
        assert cmd.update["summary"] == "Executive summary: Workflow completed successfully."

    def test_supervisor_audit_history_logging(self, mock_supervisor_llm_factory: Any) -> None:
        """Verifies supervisor appends structured ISO-timestamped records to execution_history."""
        mock_llm = mock_supervisor_llm_factory(
            responses=[
                RoutingDecision(
                    next_node="social_worker",
                    reasoning="Logging test",
                    instructions="Test instructions",
                )
            ]
        )
        node_fn = create_supervisor_node(llm=mock_llm)
        state = create_initial_state(user_input="Logging test")

        cmd = node_fn(state)
        history = cmd.update["execution_history"]
        assert len(history) == 1
        entry = history[0]
        assert entry["node"] == "supervisor"
        assert entry["action"] == "route_to_social_worker"
        assert entry["status"] == "SUCCESS"
        assert "timestamp" in entry
        assert entry["details"]["target_worker"] == "social_worker"

    def test_supervisor_deterministic_fallback_no_llm(self) -> None:
        """Verifies deterministic fallback router operates without LLM."""
        state_social = create_initial_state(user_input="Deploy asset to Facebook via ADB")
        decision_social = deterministic_fallback_router(state_social)
        assert decision_social.next_node == "social_worker"

        state_mobile = create_initial_state(user_input="Tap the button in Termux on Android device")
        decision_mobile = deterministic_fallback_router(state_mobile)
        assert decision_mobile.next_node == "mobile_worker"

        state_research = create_initial_state(user_input="Audit workspace rules and evaluate architecture")
        decision_research = deterministic_fallback_router(state_research)
        assert decision_research.next_node == "research_worker"

        state_empty = create_initial_state(user_input="")
        decision_empty = deterministic_fallback_router(state_empty)
        assert decision_empty.next_node == "FINISH"

    def test_create_control_plane_graph_structure(self) -> None:
        """Verifies compiled StateGraph topology, nodes, and entry edge."""
        graph = create_control_plane_graph(testing=True)
        assert graph is not None
        # Verify node names in the compiled graph
        nodes = graph.nodes
        assert "supervisor" in nodes
        assert "social_worker" in nodes
        assert "mobile_worker" in nodes
        assert "research_worker" in nodes


# ============================================================================
# Tier 2: Boundary & Corner Cases
# ============================================================================


class TestTier2BoundaryAndRecursionLimits:
    """Tier 2: Boundary testing, recursion limit guards, empty states, and corrupted payloads."""

    def test_max_iterations_exhaustion_halts_execution(self) -> None:
        """Verifies recursion guard halts execution when iteration_count >= max_iterations."""
        node_fn = create_supervisor_node()
        state = create_initial_state(
            user_input="Continuous loop task",
            iteration_count=10,
            max_iterations=10,
        )

        cmd = node_fn(state)
        assert isinstance(cmd, Command)
        assert cmd.goto == END
        assert cmd.update["status"] == "TERMINATED_LOOP_LIMIT"
        assert cmd.update["next_worker"] is None
        assert cmd.update["iteration_count"] == 11
        assert any(
            entry["action"] == "loop_guard_termination"
            for entry in cmd.update["execution_history"]
        )

    def test_single_iteration_max_limit_boundary(self) -> None:
        """Verifies execution with max_iterations=1 halts after 1 turn."""
        graph = create_control_plane_graph(
            max_iterations=1,
            testing=True,
            fallback_router=lambda s: RoutingDecision(
                next_node="social_worker",
                reasoning="Looping worker",
                instructions="Keep looping",
            ),
        )
        state = create_initial_state(user_input="Loop test", max_iterations=1)
        config = {"configurable": {"thread_id": "test_single_iter"}}
        out = graph.invoke(state, config=config)
        assert out["status"] == "TERMINATED_LOOP_LIMIT"
        assert out["iteration_count"] >= 2

    def test_counter_overflow_boundary(self) -> None:
        """Verifies input iteration_count exceeding max_iterations halts immediately on first turn."""
        node_fn = create_supervisor_node()
        state = create_initial_state(
            user_input="Overflow test",
            iteration_count=20,
            max_iterations=10,
        )
        cmd = node_fn(state)
        assert cmd.goto == END
        assert cmd.update["status"] == "TERMINATED_LOOP_LIMIT"

    def test_empty_user_request_and_minimal_state(self) -> None:
        """Verifies empty user string and minimal state completes cleanly to FINISH."""
        graph = create_control_plane_graph(testing=True)
        state = create_initial_state(user_input="")
        config = {"configurable": {"thread_id": "test_empty_input"}}
        out = graph.invoke(state, config=config)
        assert out["status"] == "COMPLETED"
        assert out["iteration_count"] == 1

    def test_whitespace_only_user_prompt(self) -> None:
        """Verifies whitespace-only input string is handled cleanly without crash."""
        graph = create_control_plane_graph(testing=True)
        state = create_initial_state(user_input="   \n\t   ")
        config = {"configurable": {"thread_id": "test_whitespace_input"}}
        out = graph.invoke(state, config=config)
        assert out["status"] == "COMPLETED"

    def test_massive_prompt_context_assembly(self, mock_supervisor_llm_factory: Any) -> None:
        """Verifies state with large message payloads (50KB+) executes without issue."""
        huge_text = "Analysis context: " + ("Rule constraint details. " * 2000)
        captured_messages: List[BaseMessage] = []

        def capture_responder(msgs: List[BaseMessage]) -> RoutingDecision:
            nonlocal captured_messages
            captured_messages = list(msgs)
            return RoutingDecision(
                next_node="FINISH",
                reasoning="Handled massive context",
                instructions="Completed",
            )

        mock_llm = mock_supervisor_llm_factory(dynamic_responder=capture_responder)
        node_fn = create_supervisor_node(llm=mock_llm)
        state = create_initial_state(user_input=huge_text)

        cmd = node_fn(state)
        assert cmd.goto == END
        assert len(captured_messages) >= 2

    def test_malformed_llm_payload_fallback(self, mock_supervisor_llm_factory: Any) -> None:
        """Verifies that non-standard LLM outputs fall back safely without crashing."""
        # LLM returns unexpected object
        mock_llm = mock_supervisor_llm_factory(responses=["unexpected string response"])
        node_fn = create_supervisor_node(llm=mock_llm)
        state = create_initial_state(user_input="Deploy to Facebook")

        cmd = node_fn(state)
        # Should fallback and route to social_worker
        assert cmd.goto == "social_worker"

    def test_invalid_destination_node_rejection(
        self, mock_supervisor_llm_factory: Any
    ) -> None:
        """Verifies that an unknown destination from LLM is rejected and sets status=FAILED."""
        bad_decision = MagicMock(
            next_node="nonexistent_worker",
            reasoning="bad reasoning",
            instructions="bad instructions",
        )
        mock_llm = mock_supervisor_llm_factory(
            dynamic_responder=lambda msgs: bad_decision
        )

        node_fn = create_supervisor_node(llm=mock_llm)
        state = create_initial_state(user_input="Rogue test")

        cmd = node_fn(state)
        assert cmd.goto == END
        assert cmd.update["status"] == "FAILED"
        assert any(
            entry["action"] == "invalid_destination_rejected"
            for entry in cmd.update["execution_history"]
        )


# ============================================================================
# Tier 3: Cross-Feature Combinations & Checkpointers
# ============================================================================


class TestTier3CombinationsAndCheckpointers:
    """Tier 3: Hub-and-Spoke worker isolation, multi-worker sequences, and checkpointer persistence."""

    def test_hub_and_spoke_worker_isolation(self) -> None:
        """Verifies workers return strictly to supervisor and no direct inter-worker transitions occur."""
        graph = create_control_plane_graph(testing=True)
        assert graph is not None
        # Ensure START only goes to supervisor
        # And all worker executions route through supervisor
        state = create_initial_state(user_input="Deploy asset to Facebook")
        config = {"configurable": {"thread_id": "test_isolation"}}
        out = graph.invoke(state, config=config)

        history = out["execution_history"]
        # History pattern must be supervisor -> social_worker -> supervisor -> FINISH
        node_sequence = [h.get("node") for h in history if h.get("status") == "SUCCESS"]
        assert "supervisor" in node_sequence
        assert "social_worker" in node_sequence

    def test_pairwise_routing_sequence_social_mobile(
        self, mock_supervisor_llm_factory: Any
    ) -> None:
        """Verifies sequential dispatch: supervisor -> social_worker -> supervisor -> mobile_worker -> supervisor -> FINISH."""
        mock_llm = mock_supervisor_llm_factory(
            responses=[
                RoutingDecision(
                    next_node="social_worker",
                    reasoning="First deploy to Facebook",
                    instructions="Deploy video asset",
                ),
                RoutingDecision(
                    next_node="mobile_worker",
                    reasoning="Then verify on mobile",
                    instructions="Verify screenshot in Termux",
                ),
                RoutingDecision(
                    next_node="FINISH",
                    reasoning="Both steps finished",
                    instructions="Campaign deployed and mobile verified.",
                ),
            ]
        )
        graph = create_control_plane_graph(llm=mock_llm, testing=True)
        state = create_initial_state(
            user_input="Deploy to Facebook and verify in mobile"
        )
        config = {"configurable": {"thread_id": "test_seq_social_mobile"}}
        out = graph.invoke(state, config=config)

        assert out["status"] == "COMPLETED"
        history = out["execution_history"]
        actions = [h.get("action") for h in history]
        assert "route_to_social_worker" in actions
        assert "route_to_mobile_worker" in actions
        assert "workflow_finished" in actions

    def test_pairwise_routing_sequence_research_social(
        self, mock_supervisor_llm_factory: Any
    ) -> None:
        """Verifies sequential dispatch: supervisor -> research_worker -> supervisor -> social_worker -> supervisor -> FINISH."""
        mock_llm = mock_supervisor_llm_factory(
            responses=[
                RoutingDecision(
                    next_node="research_worker",
                    reasoning="Audit compliance rules first",
                    instructions="Check rules database",
                ),
                RoutingDecision(
                    next_node="social_worker",
                    reasoning="Proceed to social deployment",
                    instructions="Deploy compliant assets",
                ),
                RoutingDecision(
                    next_node="FINISH",
                    reasoning="Audit and deploy complete",
                    instructions="Research audited and campaign deployed.",
                ),
            ]
        )
        graph = create_control_plane_graph(llm=mock_llm, testing=True)
        state = create_initial_state(user_input="Audit rules and deploy")
        config = {"configurable": {"thread_id": "test_seq_res_soc"}}
        out = graph.invoke(state, config=config)

        assert out["status"] == "COMPLETED"
        history = out["execution_history"]
        actions = [h.get("action") for h in history]
        assert "route_to_research_worker" in actions
        assert "route_to_social_worker" in actions
        assert "workflow_finished" in actions

    def test_full_pipeline_traversal_all_workers(
        self, mock_multi_turn_llm: MockStructuredChatModel
    ) -> None:
        """Verifies traversal across multiple workers in a single graph invocation."""
        graph = create_control_plane_graph(llm=mock_multi_turn_llm, testing=True)
        state = create_initial_state(
            user_input="Perform full campaign research and social deployment"
        )
        config = {"configurable": {"thread_id": "test_multi_turn_pipeline"}}
        out = graph.invoke(state, config=config)

        assert out["status"] == "COMPLETED"
        history = out["execution_history"]
        actions = [h.get("action") for h in history]
        assert "route_to_research_worker" in actions
        assert "route_to_social_worker" in actions
        assert "workflow_finished" in actions

    def test_sync_checkpointer_memory_saver_persistence(self) -> None:
        """Verifies state persistence across turns with MemorySaver and retrieval via get_state."""
        checkpointer = MemorySaver()
        graph = create_control_plane_graph(checkpointer=checkpointer, testing=False)
        state = create_initial_state(user_input="Deploy asset to Facebook")
        config = {"configurable": {"thread_id": "persist_thread_1"}}

        out = graph.invoke(state, config=config)
        assert out["status"] == "COMPLETED"

        checkpoint_state = graph.get_state(config)
        assert checkpoint_state is not None
        assert checkpoint_state.values["status"] == "COMPLETED"
        assert checkpoint_state.values["task_intent"] == "Deploy asset to Facebook"

    def test_sync_checkpointer_postgres_saver_mock(
        self, mock_db_pool: Tuple[MagicMock, MagicMock, MagicMock]
    ) -> None:
        """Verifies graph compilation with PostgresSaver mock pool."""
        pool, conn, cursor = mock_db_pool
        checkpointer = PostgresSaver(conn=pool)
        graph = create_control_plane_graph(checkpointer=checkpointer)
        assert graph is not None

    @pytest.mark.asyncio
    async def test_async_checkpointer_ainvoke_persistence(self) -> None:
        """Verifies graph.ainvoke with MemorySaver and asynchronous state inspection."""
        checkpointer = MemorySaver()
        graph = create_control_plane_graph(checkpointer=checkpointer, testing=False)
        state = create_initial_state(user_input="Tap button in Termux")
        config = {"configurable": {"thread_id": "async_thread_1"}}

        out = await graph.ainvoke(state, config=config)
        assert out["status"] == "COMPLETED"

        checkpoint_state = await graph.aget_state(config)
        assert checkpoint_state is not None
        assert checkpoint_state.values["status"] == "COMPLETED"

    @pytest.mark.asyncio
    async def test_async_checkpointer_async_postgres_saver_mock(
        self, mock_async_db_pool: Tuple[MagicMock, MagicMock, MagicMock]
    ) -> None:
        """Verifies graph compilation with AsyncPostgresSaver mock pool."""
        apool, aconn, acursor = mock_async_db_pool
        checkpointer = AsyncPostgresSaver(conn=apool)
        graph = create_control_plane_graph(checkpointer=checkpointer)
        assert graph is not None


# ============================================================================
# Tier 4: Real-World Application Scenarios
# ============================================================================


class TestTier4RealWorldWorkflows:
    """Tier 4: End-to-end user workflows spanning social, mobile, research, and fallback."""

    def test_scenario_social_media_campaign_dispatch(self) -> None:
        """
        Scenario 1: Social Media Campaign Dispatch
        'Publish our new marketing video to Facebook and verify ADB metrics.'
        """
        result = run_control_plane(
            user_input="Publish our new marketing video to Facebook and log telemetry",
            thread_id="scenario_social_1",
            testing=True,
        )
        assert result["status"] == "COMPLETED"
        history = result["execution_history"]
        nodes = [h.get("node") for h in history]
        assert "social_worker" in nodes
        assert "supervisor" in nodes

    def test_scenario_mobile_termux_automation(self) -> None:
        """
        Scenario 2: Mobile ADB Automation
        'Launch Termux on connected Android device, inject update script, and tap confirmation.'
        """
        result = run_control_plane(
            user_input="Launch Termux on connected Android device, inject update script, and tap confirmation",
            thread_id="scenario_mobile_1",
            testing=True,
        )
        assert result["status"] == "COMPLETED"
        history = result["execution_history"]
        nodes = [h.get("node") for h in history]
        assert "mobile_worker" in nodes
        assert "supervisor" in nodes

    def test_scenario_deep_architectural_rule_validation(self) -> None:
        """
        Scenario 3: Deep Architectural Rule Validation
        'Audit the workspace architecture against global steering rules and compile research report.'
        """
        result = run_control_plane(
            user_input="Audit the workspace architecture against global steering rules and compile research report",
            thread_id="scenario_research_1",
            testing=True,
        )
        assert result["status"] == "COMPLETED"
        history = result["execution_history"]
        nodes = [h.get("node") for h in history]
        assert "research_worker" in nodes
        assert "supervisor" in nodes

    def test_scenario_multi_step_hybrid_orchestration(self) -> None:
        """
        Scenario 4: Multi-Step Hybrid Orchestration
        'Research the top trending sports cards, generate social assets, and verify on mobile device.'
        """
        result = run_control_plane(
            user_input="Research top trending sports cards, publish social campaign video, and verify on mobile device",
            thread_id="scenario_hybrid_1",
            testing=True,
        )
        assert result["status"] == "COMPLETED"
        history = result["execution_history"]
        nodes = [h.get("node") for h in history]
        assert "research_worker" in nodes
        assert "social_worker" in nodes
        assert "mobile_worker" in nodes

    def test_scenario_degraded_worker_loop_exhaustion(self) -> None:
        """
        Scenario 5: Degraded Worker Loop Exhaustion
        Non-converging worker loop triggers recursion guard, safely exiting with TERMINATED_LOOP_LIMIT.
        """
        loop_router = lambda s: RoutingDecision(
            next_node="mobile_worker",
            reasoning="Looping on mobile",
            instructions="Execute repeated tap",
        )
        graph = create_control_plane_graph(
            max_iterations=3,
            testing=True,
            fallback_router=loop_router,
        )
        state = create_initial_state(
            user_input="Endless mobile loop",
            max_iterations=3,
        )
        config = {"configurable": {"thread_id": "scenario_loop_exhaustion"}}
        out = graph.invoke(state, config=config)

        assert out["status"] == "TERMINATED_LOOP_LIMIT"
        assert out["iteration_count"] == 4


# ============================================================================
# Tier 5: Adversarial Hardening & Stress Testing
# ============================================================================


class TestTier5AdversarialHardening:
    """Tier 5: Adversarial fault injection, exception recovery, state corruption, concurrency."""

    def test_adversarial_llm_api_exception_handling(
        self, mock_failing_llm: MockStructuredChatModel
    ) -> None:
        """LLM throws 503 API error; supervisor engages fallback router or safe exit."""
        node_fn = create_supervisor_node(llm=mock_failing_llm)
        state = create_initial_state(user_input="Deploy asset to Facebook")

        cmd = node_fn(state)
        # Should gracefully engage fallback router and route to social_worker
        assert cmd.goto == "social_worker"
        assert cmd.update["status"] == "RUNNING"

    def test_adversarial_critical_routing_failure_aborts(self) -> None:
        """When both LLM and custom fallback fail, supervisor safely halts with status=FAILED."""
        failing_llm = MockStructuredChatModel(
            responses=[RuntimeError("Primary LLM crash")]
        )
        failing_fallback = MagicMock(side_effect=RuntimeError("Fallback crash"))

        node_fn = create_supervisor_node(
            llm=failing_llm,
            fallback_router=failing_fallback,
        )
        state = create_initial_state(user_input="Critical failure test")

        cmd = node_fn(state)
        assert cmd.goto == END
        assert cmd.update["status"] == "FAILED"
        assert any(
            entry["action"] == "routing_error"
            for entry in cmd.update["execution_history"]
        )

    def test_adversarial_corrupted_state_missing_keys(self) -> None:
        """State dictionary missing standard keys is handled gracefully without KeyError."""
        node_fn = create_supervisor_node()
        corrupted_state: Any = {"task_intent": "Deploy to Facebook"}

        cmd = node_fn(corrupted_state)
        assert cmd.goto in ("social_worker", END)
        assert cmd.update["iteration_count"] == 1

    def test_adversarial_corrupted_execution_history(self) -> None:
        """State with malformed execution_history entries does not crash fallback router."""
        state = create_initial_state(user_input="Deploy to Facebook")
        # Inject non-dict elements into history
        state["execution_history"] = ["malformed_string", 12345, None]  # type: ignore[list-item]

        node_fn = create_supervisor_node()
        cmd = node_fn(state)
        assert cmd.goto == "social_worker"

    def test_adversarial_concurrent_thread_isolation(self) -> None:
        """Runs multiple simultaneous graph invocations with different thread_id values without cross-talk."""
        graph = create_control_plane_graph(testing=True)

        def _run_workflow(prompt: str, thread_id: str) -> Dict[str, Any]:
            st = create_initial_state(user_input=prompt)
            cfg = {"configurable": {"thread_id": thread_id}}
            return graph.invoke(st, config=cfg)

        prompts = [
            ("Deploy asset to Facebook", "thread_conc_1"),
            ("Launch Termux on mobile", "thread_conc_2"),
            ("Audit workspace rules", "thread_conc_3"),
            ("Deploy asset to Facebook", "thread_conc_4"),
            ("Launch Termux on mobile", "thread_conc_5"),
        ]

        with ThreadPoolExecutor(max_workers=5) as executor:
            results = list(
                executor.map(lambda p: _run_workflow(p[0], p[1]), prompts)
            )

        assert len(results) == 5
        for res, (prompt, _) in zip(results, prompts):
            assert res["status"] == "COMPLETED"
            assert res["task_intent"] == prompt

    def test_adversarial_rapid_state_graph_recompilation(self) -> None:
        """Compiles 50 graphs concurrently to verify memory stability and no thread leaks."""
        with ThreadPoolExecutor(max_workers=10) as executor:
            graphs = list(
                executor.map(
                    lambda _: create_control_plane_graph(testing=True), range(50)
                )
            )
        assert len(graphs) == 50
        for g in graphs:
            assert g is not None

    @pytest.mark.asyncio
    async def test_async_run_control_plane_wrapper(self) -> None:
        """Verifies async_run_control_plane helper function."""
        res = await async_run_control_plane(
            user_input="Deploy asset to Facebook",
            thread_id="async_wrapper_test",
            testing=True,
        )
        assert res["status"] == "COMPLETED"
        assert res["task_intent"] == "Deploy asset to Facebook"

"""
Central Supervisor Orchestrator for Antigravity Control Plane.

Implements the Hierarchical Supervisor Pattern in LangGraph.
Acts as the single canonical entrypoint for intent classification, Decision-First
routing via structured output (with_structured_output), dynamic Command transitions,
loop recursion safety, and checkpointer integration.
"""

from __future__ import annotations

import logging
import os
import sys
from typing import Any, Callable, Dict, List, Optional, Sequence, Union

from langchain_core.language_models.chat_models import BaseChatModel
from langchain_core.messages import AIMessage, BaseMessage, HumanMessage, SystemMessage
from langgraph.checkpoint.base import BaseCheckpointSaver
from langgraph.graph import END, START, StateGraph
from langgraph.graph.state import CompiledStateGraph
from langgraph.types import Command

from db import get_async_checkpointer, get_checkpointer
from pydantic import BaseModel
from prompts import SUPERVISOR_SYSTEM_PROMPT
from schemas import RoutingDecision, RoutingTarget
from state import AgentState, create_history_entry, create_initial_state
from workers import (
    create_mobile_worker,
    create_research_worker,
    create_social_worker,
    mobile_worker,
    research_worker,
    social_worker,
)

logger = logging.getLogger(__name__)

# Valid worker destinations and finish sentinel
VALID_ROUTING_TARGETS = {"social_worker", "mobile_worker", "research_worker", "FINISH"}


def deterministic_fallback_router(state: AgentState) -> RoutingDecision:
    """
    Deterministic zero-network fallback intent classifier and router.

    Analyzes task intent, conversational messages, and prior execution history
    to sequentially delegate multi-domain tasks and prevent infinite loops.

    Args:
        state: The current AgentState dictionary.

    Returns:
        A validated RoutingDecision object.
    """
    task_intent = (state.get("task_intent") or "").lower()
    raw_messages = state.get("messages") or []
    msg_texts = [
        m.content.lower()
        for m in raw_messages
        if isinstance(m, (HumanMessage, SystemMessage)) and isinstance(m.content, str)
    ]
    combined_text = f"{task_intent} {' '.join(msg_texts)}".strip()

    # If completely empty, finish immediately
    if not combined_text:
        return RoutingDecision(
            next_node="FINISH",
            reasoning="Empty user request received; no actions to delegate.",
            instructions="Execution concluded.",
        )

    # Track which workers have already successfully executed in history
    history = state.get("execution_history") or []
    executed_workers = set()
    for entry in history:
        if not isinstance(entry, dict):
            continue
        node = entry.get("node") or entry.get("worker")
        status = entry.get("status")
        if node in ("social_worker", "mobile_worker", "research_worker") and status == "SUCCESS":
            executed_workers.add(node)

    # Domain keyword patterns
    wants_research = any(
        kw in combined_text
        for kw in [
            "research",
            "rule",
            "rules",
            "benchmark",
            "benchmarks",
            "evaluate",
            "evaluation",
            "proposal",
            "architecture",
            "audit",
            "compliance",
            "sentinel",
            "trend",
            "trending",
            "sports card",
            "sports cards",
        ]
    )

    wants_social = any(
        kw in combined_text
        for kw in [
            "facebook",
            "youtube",
            "social",
            "campaign",
            "telemetry",
            "manifest",
            "video asset",
            "marketing video",
            "publish",
            "thumbnail",
        ]
    )

    wants_mobile = any(
        kw in combined_text
        for kw in [
            "adb",
            "android",
            "termux",
            "tap",
            "keystroke",
            "intent",
            "mobile",
            "samsung",
            "autoblocker",
            "permission",
            "device",
            "ui tree",
            "screenshot",
            "verify on mobile",
        ]
    )

    # Multi-step sequential delegation order: Research -> Social -> Mobile -> FINISH
    if wants_research and "research_worker" not in executed_workers:
        return RoutingDecision(
            next_node="research_worker",
            reasoning="Intent requires deep research, rules lookup, or architectural validation.",
            instructions="Execute technical research and evaluate constraints against workspace rules.",
        )

    if wants_social and "social_worker" not in executed_workers:
        return RoutingDecision(
            next_node="social_worker",
            reasoning="Intent requires social media dispatch, video upload, or telemetry logging.",
            instructions="Deploy social media assets and log telemetry to database.",
        )

    if wants_mobile and "mobile_worker" not in executed_workers:
        return RoutingDecision(
            next_node="mobile_worker",
            reasoning="Intent requires Android device execution, Termux scripting, or UI interaction.",
            instructions="Execute mobile automation hierarchy and verify device state.",
        )

    # All required workers have executed or no specific worker keywords matched
    return RoutingDecision(
        next_node="FINISH",
        reasoning="All required worker delegations have successfully concluded.",
        instructions="All requested tasks have been executed and verified.",
    )


def create_supervisor_node(
    llm: Optional[BaseChatModel] = None,
    system_prompt: Optional[str] = None,
    fallback_router: Optional[Callable[[AgentState], RoutingDecision]] = None,
) -> Callable[[AgentState], Command]:
    """
    Supervisor Node Factory.

    Constructs the Decision-First routing engine using `llm.with_structured_output(RoutingDecision)`.
    Enforces recursion guards, appends audit history, and emits dynamic Command handoffs.

    Args:
        llm: Optional BaseChatModel instance. If None, uses fallback_router.
        system_prompt: Custom supervisor system prompt. Defaults to SUPERVISOR_SYSTEM_PROMPT.
        fallback_router: Custom fallback routing callable. Defaults to deterministic_fallback_router.

    Returns:
        Callable supervisor node function conforming to LangGraph node signature.
    """
    resolved_prompt = system_prompt or SUPERVISOR_SYSTEM_PROMPT
    active_fallback = fallback_router or deterministic_fallback_router

    def supervisor_node(state: AgentState) -> Command:
        # 1. State extraction & loop guard validation
        iteration_count = state.get("iteration_count", 0) if isinstance(state, dict) else 0
        max_iterations = state.get("max_iterations", 10) if isinstance(state, dict) else 10
        task_intent = state.get("task_intent", "") if isinstance(state, dict) else ""
        raw_messages = list(state.get("messages", [])) if isinstance(state, dict) else []

        # Recursion Guard: check if limit reached before advancing
        if iteration_count >= max_iterations:
            new_iteration = iteration_count + 1
            log_entry = create_history_entry(
                node="supervisor",
                action="loop_guard_termination",
                status="TERMINATED_LOOP_LIMIT",
                details={
                    "iteration_count": new_iteration,
                    "max_iterations": max_iterations,
                    "reason": "Recursion guard triggered: maximum iteration limit reached.",
                },
                error=f"Execution halted: reached maximum iterations ({max_iterations}).",
            )
            term_msg = AIMessage(
                content=f"[Supervisor] Recursion guard triggered: reached maximum iterations ({max_iterations}). Workflow halted."
            )
            return Command(
                update={
                    "iteration_count": new_iteration,
                    "status": "TERMINATED_LOOP_LIMIT",
                    "next_worker": None,
                    "messages": [term_msg],
                    "execution_history": [log_entry],
                    "summary": f"Terminated by loop guard at iteration {new_iteration}/{max_iterations}",
                },
                goto=END,
            )

        new_iteration = iteration_count + 1

        # 2. Decision-First Intent Classification
        decision: Optional[RoutingDecision] = None

        if llm is not None:
            try:
                # Strictly use structured output - NO tool calling
                structured_model = llm.with_structured_output(RoutingDecision)
                sup_msgs: List[BaseMessage] = [SystemMessage(content=resolved_prompt)]
                if raw_messages:
                    sup_msgs.extend(raw_messages)
                elif task_intent:
                    sup_msgs.append(HumanMessage(content=task_intent))
                else:
                    sup_msgs.append(HumanMessage(content="Evaluate state and determine next step."))

                raw_output = structured_model.invoke(sup_msgs)

                if isinstance(raw_output, RoutingDecision):
                    decision = raw_output
                elif isinstance(raw_output, BaseModel):
                    decision = RoutingDecision(**raw_output.model_dump())
                elif isinstance(raw_output, dict):
                    if raw_output.get("next_node") in VALID_ROUTING_TARGETS:
                        decision = RoutingDecision(**raw_output)
                    else:
                        decision = type("InvalidDecision", (), {
                            "next_node": raw_output.get("next_node"),
                            "reasoning": raw_output.get("reasoning", ""),
                            "instructions": raw_output.get("instructions", ""),
                        })()
                elif hasattr(raw_output, "next_node"):
                    decision = raw_output
                else:
                    decision = active_fallback(state)
            except Exception as exc:
                logger.warning(
                    "Structured LLM routing encountered exception: %s. Engaging fallback router.",
                    exc,
                )
                try:
                    decision = active_fallback(state)
                except Exception as fallback_exc:
                    err_entry = create_history_entry(
                        node="supervisor",
                        action="routing_error",
                        status="FAILED",
                        error=f"Supervisor routing failed: {str(exc)} | Fallback error: {str(fallback_exc)}",
                    )
                    err_msg = AIMessage(content=f"[Supervisor] Critical routing failure: {str(exc)}")
                    return Command(
                        update={
                            "iteration_count": new_iteration,
                            "status": "FAILED",
                            "next_worker": None,
                            "messages": [err_msg],
                            "execution_history": [err_entry],
                        },
                        goto=END,
                    )
        else:
            decision = active_fallback(state)

        # 3. Destination Validation & Whitelist Check
        if not decision or decision.next_node not in VALID_ROUTING_TARGETS:
            invalid_node = decision.next_node if decision else "None"
            err_entry = create_history_entry(
                node="supervisor",
                action="invalid_destination_rejected",
                status="FAILED",
                error=f"Invalid target node rejected: '{invalid_node}'",
                details={"attempted_node": invalid_node},
            )
            err_msg = AIMessage(
                content=f"[Supervisor] Rejected invalid routing target: '{invalid_node}'."
            )
            return Command(
                update={
                    "iteration_count": new_iteration,
                    "status": "FAILED",
                    "next_worker": None,
                    "messages": [err_msg],
                    "execution_history": [err_entry],
                },
                goto=END,
            )

        # 4. Handle FINISH Termination
        if decision.next_node == "FINISH":
            final_summary = decision.instructions or decision.reasoning or "Task completed successfully."
            finish_msg = AIMessage(content=final_summary)
            history_entry = create_history_entry(
                node="supervisor",
                action="workflow_finished",
                status="SUCCESS",
                details={
                    "reasoning": decision.reasoning,
                    "instructions": decision.instructions,
                    "iteration": new_iteration,
                },
            )
            return Command(
                update={
                    "iteration_count": new_iteration,
                    "status": "COMPLETED",
                    "next_worker": None,
                    "messages": [finish_msg],
                    "execution_history": [history_entry],
                    "summary": final_summary,
                },
                goto=END,
            )

        # 5. Handle Worker Node Delegation
        target_node = decision.next_node
        route_instruction = (
            f"[Supervisor -> {target_node}] {decision.instructions}"
            if decision.instructions
            else f"[Supervisor -> {target_node}] Proceed with execution."
        )
        route_msg = AIMessage(content=route_instruction)
        history_entry = create_history_entry(
            node="supervisor",
            action=f"route_to_{target_node}",
            status="SUCCESS",
            details={
                "target_worker": target_node,
                "reasoning": decision.reasoning,
                "instructions": decision.instructions,
                "iteration": new_iteration,
            },
        )

        return Command(
            update={
                "iteration_count": new_iteration,
                "status": "RUNNING",
                "next_worker": target_node,
                "messages": [route_msg],
                "execution_history": [history_entry],
            },
            goto=target_node,
        )

    supervisor_node.__name__ = "supervisor_node"
    return supervisor_node


# Global default supervisor node callable
supervisor_node = create_supervisor_node()


def create_control_plane_graph(
    llm: Optional[BaseChatModel] = None,
    worker_llm: Optional[BaseChatModel] = None,
    checkpointer: Optional[BaseCheckpointSaver] = None,
    max_iterations: int = 10,
    connection_string: Optional[str] = None,
    testing: bool = False,
    system_prompt: Optional[str] = None,
    fallback_router: Optional[Callable[[AgentState], RoutingDecision]] = None,
    **kwargs: Any,
) -> CompiledStateGraph:
    """
    Constructs and compiles the unified Antigravity Control Plane StateGraph.

    Registers the Central Supervisor and worker nodes, wires START -> supervisor,
    and binds the PostgreSQL or in-memory checkpointer backend.

    Args:
        llm: BaseChatModel for Supervisor intent classification.
        worker_llm: BaseChatModel for worker tool binding and execution.
        checkpointer: Pre-configured BaseCheckpointSaver instance.
        max_iterations: Safety threshold for loop recursion guard.
        connection_string: PostgreSQL URI for PostgresSaver backend.
        testing: If True, forces MemorySaver checkpointer.
        system_prompt: Optional custom supervisor system prompt.
        fallback_router: Optional custom fallback routing callable.
        **kwargs: Additional configuration parameters.

    Returns:
        CompiledStateGraph instance ready for sync (invoke) or async (ainvoke) execution.
    """
    builder = StateGraph(AgentState)

    # 1. Instantiate Supervisor and Worker node callables
    sup_node = create_supervisor_node(
        llm=llm,
        system_prompt=system_prompt,
        fallback_router=fallback_router,
    )
    soc_node = create_social_worker(llm=worker_llm) if worker_llm else social_worker
    mob_node = create_mobile_worker(llm=worker_llm) if worker_llm else mobile_worker
    res_node = create_research_worker(llm=worker_llm) if worker_llm else research_worker

    # 2. Register all nodes in Hub-and-Spoke topology
    builder.add_node("supervisor", sup_node)
    builder.add_node("social_worker", soc_node)
    builder.add_node("mobile_worker", mob_node)
    builder.add_node("research_worker", res_node)

    # 3. Add canonical entry edge: START -> supervisor
    builder.add_edge(START, "supervisor")

    # 4. Resolve checkpointer backend
    resolved_checkpointer = checkpointer
    if resolved_checkpointer is None:
        resolved_checkpointer = get_checkpointer(
            connection_string=connection_string,
            testing=testing,
            **kwargs,
        )

    # 5. Compile graph
    return builder.compile(checkpointer=resolved_checkpointer)


def run_control_plane(
    user_input: str = "",
    thread_id: str = "default_thread",
    checkpointer: Optional[BaseCheckpointSaver] = None,
    llm: Optional[BaseChatModel] = None,
    worker_llm: Optional[BaseChatModel] = None,
    max_iterations: int = 10,
    connection_string: Optional[str] = None,
    testing: bool = False,
    **kwargs: Any,
) -> AgentState:
    """
    Synchronous execution wrapper for the Antigravity Control Plane.

    Args:
        user_input: Primary user task or prompt string.
        thread_id: Unique thread identifier for state persistence.
        checkpointer: Optional checkpointer instance.
        llm: Optional supervisor LLM.
        worker_llm: Optional worker LLM.
        max_iterations: Maximum iteration threshold.
        connection_string: Optional Postgres connection URI.
        testing: If True, uses MemorySaver checkpointer.
        **kwargs: Additional state and graph arguments.

    Returns:
        Final AgentState dictionary upon graph completion.
    """
    graph = create_control_plane_graph(
        llm=llm,
        worker_llm=worker_llm,
        checkpointer=checkpointer,
        max_iterations=max_iterations,
        connection_string=connection_string,
        testing=testing,
        **kwargs,
    )
    initial_state = create_initial_state(
        user_input=user_input,
        max_iterations=max_iterations,
        **kwargs,
    )
    config = {"configurable": {"thread_id": thread_id}}
    result: AgentState = graph.invoke(initial_state, config=config)
    return result


async def async_run_control_plane(
    user_input: str = "",
    thread_id: str = "default_thread",
    checkpointer: Optional[BaseCheckpointSaver] = None,
    llm: Optional[BaseChatModel] = None,
    worker_llm: Optional[BaseChatModel] = None,
    max_iterations: int = 10,
    connection_string: Optional[str] = None,
    testing: bool = False,
    **kwargs: Any,
) -> AgentState:
    """
    Asynchronous execution wrapper for the Antigravity Control Plane.

    Args:
        user_input: Primary user task or prompt string.
        thread_id: Unique thread identifier for state persistence.
        checkpointer: Optional checkpointer instance.
        llm: Optional supervisor LLM.
        worker_llm: Optional worker LLM.
        max_iterations: Maximum iteration threshold.
        connection_string: Optional Postgres connection URI.
        testing: If True, uses MemorySaver checkpointer.
        **kwargs: Additional state and graph arguments.

    Returns:
        Final AgentState dictionary upon graph completion.
    """
    graph = create_control_plane_graph(
        llm=llm,
        worker_llm=worker_llm,
        checkpointer=checkpointer,
        max_iterations=max_iterations,
        connection_string=connection_string,
        testing=testing,
        **kwargs,
    )
    initial_state = create_initial_state(
        user_input=user_input,
        max_iterations=max_iterations,
        **kwargs,
    )
    config = {"configurable": {"thread_id": thread_id}}
    result: AgentState = await graph.ainvoke(initial_state, config=config)
    return result


if __name__ == "__main__":
    try:
        from dotenv import load_dotenv

        load_dotenv()
    except ImportError:
        pass

    cli_prompt = sys.argv[1] if len(sys.argv) > 1 else "Deploy marketing video to Facebook and verify metrics."
    print(f"Executing Antigravity Control Plane CLI with prompt: '{cli_prompt}'")
    out_state = run_control_plane(user_input=cli_prompt, testing=True)
    print(f"Status: {out_state.get('status')}")
    print(f"Summary: {out_state.get('summary')}")
    print(f"Iterations: {out_state.get('iteration_count')}")
    print(f"History entries: {len(out_state.get('execution_history', []))}")

"""
Database connection pooling and LangGraph checkpointer factories.

Provides synchronous and asynchronous checkpointer engines backed by PostgreSQL
via psycopg_pool.ConnectionPool / AsyncConnectionPool, with automated fallback to
in-memory storage (MemorySaver) for lightweight local execution and deterministic testing.
"""

from __future__ import annotations

import logging
import os
from typing import Any, Dict, Optional, Union

from langgraph.checkpoint.base import BaseCheckpointSaver
from langgraph.checkpoint.memory import MemorySaver
from langgraph.checkpoint.postgres import PostgresSaver
from langgraph.checkpoint.postgres.aio import AsyncPostgresSaver
from psycopg.rows import dict_row
from psycopg_pool import AsyncConnectionPool, ConnectionPool

logger = logging.getLogger(__name__)

# Default Pool Configuration
DEFAULT_MIN_POOL_SIZE: int = 1
DEFAULT_MAX_POOL_SIZE: int = 20
DEFAULT_POOL_TIMEOUT: float = 30.0
DEFAULT_MAX_IDLE: float = 600.0
DEFAULT_KWARGS: Dict[str, Any] = {"autocommit": True, "row_factory": dict_row}

IN_MEMORY_SENTINELS = {"", "memory", ":memory:", "none", "local"}


def create_connection_pool(
    conninfo: str,
    *,
    min_size: int = DEFAULT_MIN_POOL_SIZE,
    max_size: Optional[int] = DEFAULT_MAX_POOL_SIZE,
    open: bool = True,
    timeout: float = DEFAULT_POOL_TIMEOUT,
    max_idle: float = DEFAULT_MAX_IDLE,
    kwargs: Optional[Dict[str, Any]] = None,
    **pool_options: Any,
) -> ConnectionPool:
    """
    Create and configure a psycopg_pool.ConnectionPool with autocommit and dict_row.

    Args:
        conninfo: PostgreSQL connection URI (e.g. postgresql://user:pass@host:5432/db).
        min_size: Minimum number of connections in the pool.
        max_size: Maximum number of connections in the pool.
        open: Whether to immediately open the pool connections.
        timeout: Maximum seconds to wait for a connection from the pool.
        max_idle: Maximum seconds a connection can remain idle before being recycled.
        kwargs: Additional connection parameters (merged with autocommit & dict_row).
        **pool_options: Extra arguments passed to ConnectionPool.

    Returns:
        Configured ConnectionPool instance.
    """
    if not conninfo or not isinstance(conninfo, str) or not conninfo.strip():
        raise ValueError("A valid PostgreSQL connection URI string must be provided.")

    final_kwargs = dict(DEFAULT_KWARGS)
    if kwargs:
        final_kwargs.update(kwargs)

    logger.debug(
        "Initializing ConnectionPool (min_size=%s, max_size=%s, open=%s)",
        min_size,
        max_size,
        open,
    )
    return ConnectionPool(
        conninfo=conninfo,
        min_size=min_size,
        max_size=max_size,
        open=open,
        timeout=timeout,
        max_idle=max_idle,
        kwargs=final_kwargs,
        **pool_options,
    )


def create_async_connection_pool(
    conninfo: str,
    *,
    min_size: int = DEFAULT_MIN_POOL_SIZE,
    max_size: Optional[int] = DEFAULT_MAX_POOL_SIZE,
    open: bool = True,
    timeout: float = DEFAULT_POOL_TIMEOUT,
    max_idle: float = DEFAULT_MAX_IDLE,
    kwargs: Optional[Dict[str, Any]] = None,
    **pool_options: Any,
) -> AsyncConnectionPool:
    """
    Create and configure a psycopg_pool.AsyncConnectionPool with autocommit and dict_row.

    Args:
        conninfo: PostgreSQL connection URI.
        min_size: Minimum number of connections in the pool.
        max_size: Maximum number of connections in the pool.
        open: Whether to immediately open the pool connections.
        timeout: Maximum seconds to wait for a connection from the pool.
        max_idle: Maximum seconds a connection can remain idle before being recycled.
        kwargs: Additional connection parameters (merged with autocommit & dict_row).
        **pool_options: Extra arguments passed to AsyncConnectionPool.

    Returns:
        Configured AsyncConnectionPool instance.
    """
    if not conninfo or not isinstance(conninfo, str) or not conninfo.strip():
        raise ValueError("A valid PostgreSQL connection URI string must be provided.")

    final_kwargs = dict(DEFAULT_KWARGS)
    if kwargs:
        final_kwargs.update(kwargs)

    logger.debug(
        "Initializing AsyncConnectionPool (min_size=%s, max_size=%s, open=%s)",
        min_size,
        max_size,
        open,
    )
    return AsyncConnectionPool(
        conninfo=conninfo,
        min_size=min_size,
        max_size=max_size,
        open=open,
        timeout=timeout,
        max_idle=max_idle,
        kwargs=final_kwargs,
        **pool_options,
    )


def get_checkpointer(
    connection_string: Optional[str] = None,
    *,
    pool: Optional[ConnectionPool] = None,
    auto_setup: bool = False,
    setup_tables: bool = False,
    testing: bool = False,
    min_size: int = DEFAULT_MIN_POOL_SIZE,
    max_size: Optional[int] = DEFAULT_MAX_POOL_SIZE,
    open: bool = True,
    **pool_kwargs: Any,
) -> BaseCheckpointSaver:
    """
    Factory creating a synchronous LangGraph checkpointer.

    If testing is True, returns MemorySaver.
    If an existing pool is provided, it is wrapped in a PostgresSaver.
    If a connection_string is provided (or resolved from DATABASE_URL / POSTGRES_URI),
    a new ConnectionPool is created and wrapped in a PostgresSaver.
    If no connection string is available or an in-memory sentinel is given,
    returns a MemorySaver instance.

    Args:
        connection_string: PostgreSQL URI string, 'memory', or None.
        pool: Pre-existing ConnectionPool instance (bypasses pool creation).
        auto_setup: If True and using PostgresSaver, calls saver.setup() to run migrations.
        setup_tables: Alias for auto_setup.
        testing: If True, forces return of MemorySaver.
        min_size: Minimum connection pool size.
        max_size: Maximum connection pool size.
        open: Whether to open the pool immediately.
        **pool_kwargs: Additional parameters passed to create_connection_pool.

    Returns:
        BaseCheckpointSaver (PostgresSaver or MemorySaver).
    """
    if testing:
        return MemorySaver()

    should_setup = auto_setup or setup_tables

    if pool is not None:
        saver = PostgresSaver(conn=pool)
        if should_setup:
            saver.setup()
            setup_event_queue(pool)
        return saver

    conn_str = connection_string
    if conn_str is None:
        conn_str = os.getenv("DATABASE_URL") or os.getenv("POSTGRES_URI")

    if not conn_str or not conn_str.strip() or conn_str.strip().lower() in IN_MEMORY_SENTINELS:
        logger.info("Using MemorySaver checkpointer fallback.")
        return MemorySaver()

    pool_instance = create_connection_pool(
        conninfo=conn_str,
        min_size=min_size,
        max_size=max_size,
        open=open,
        **pool_kwargs,
    )
    saver = PostgresSaver(conn=pool_instance)
    if should_setup:
        saver.setup()
        setup_event_queue(pool_instance)
    return saver


async def get_async_checkpointer(
    connection_string: Optional[str] = None,
    *,
    pool: Optional[AsyncConnectionPool] = None,
    auto_setup: bool = False,
    setup_tables: bool = False,
    testing: bool = False,
    min_size: int = DEFAULT_MIN_POOL_SIZE,
    max_size: Optional[int] = DEFAULT_MAX_POOL_SIZE,
    open: bool = True,
    **pool_kwargs: Any,
) -> BaseCheckpointSaver:
    """
    Factory creating an asynchronous LangGraph checkpointer.

    Must be called inside an active asyncio event loop.
    If testing is True, returns MemorySaver.
    If an existing async pool is provided, it is wrapped in an AsyncPostgresSaver.
    If a connection_string is provided (or resolved from DATABASE_URL / POSTGRES_URI),
    a new AsyncConnectionPool is created and wrapped in an AsyncPostgresSaver.
    If no connection string is available or an in-memory sentinel is given,
    returns a MemorySaver instance.

    Args:
        connection_string: PostgreSQL URI string, 'memory', or None.
        pool: Pre-existing AsyncConnectionPool instance.
        auto_setup: If True and using AsyncPostgresSaver, awaits saver.setup().
        setup_tables: Alias for auto_setup.
        testing: If True, forces return of MemorySaver.
        min_size: Minimum async pool size.
        max_size: Maximum async pool size.
        open: Whether to open the pool immediately.
        **pool_kwargs: Additional parameters passed to create_async_connection_pool.

    Returns:
        BaseCheckpointSaver (AsyncPostgresSaver or MemorySaver).
    """
    if testing:
        return MemorySaver()

    should_setup = auto_setup or setup_tables

    if pool is not None:
        saver = AsyncPostgresSaver(conn=pool)
        if should_setup:
            await saver.setup()
        return saver

    conn_str = connection_string
    if conn_str is None:
        conn_str = os.getenv("DATABASE_URL") or os.getenv("POSTGRES_URI")

    if not conn_str or not conn_str.strip() or conn_str.strip().lower() in IN_MEMORY_SENTINELS:
        logger.info("Using MemorySaver checkpointer fallback for async execution.")
        return MemorySaver()

    pool_instance = create_async_connection_pool(
        conninfo=conn_str,
        min_size=min_size,
        max_size=max_size,
        open=open,
        **pool_kwargs,
    )
    saver = AsyncPostgresSaver(conn=pool_instance)
    if should_setup:
        await saver.setup()
    return saver


def close_connection_pool(pool: Union[ConnectionPool, Any]) -> None:
    """
    Safely closes a synchronous connection pool if open.
    """
    if isinstance(pool, ConnectionPool) and not getattr(pool, "closed", False):
        pool.close()


async def close_async_connection_pool(pool: Union[AsyncConnectionPool, Any]) -> None:
    """
    Safely closes an asynchronous connection pool if open.
    """
    if isinstance(pool, AsyncConnectionPool) and not getattr(pool, "closed", False):
        await pool.close()

def setup_event_queue(pool: ConnectionPool) -> None:
    """Creates the event_queue table in PostgreSQL for async background tasks."""
    with pool.connection() as conn:
        with conn.cursor() as cur:
            cur.execute('''
                CREATE TABLE IF NOT EXISTS event_queue (
                    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
                    status VARCHAR(50) DEFAULT 'pending',
                    payload JSONB NOT NULL,
                    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
                );
            ''')


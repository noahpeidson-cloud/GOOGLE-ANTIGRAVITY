"""
Unit tests for state management, AgentState schema, reducers, and context pruning.
Covers Tier 1 through Tier 5 per TEST_INFRA.md specification.
"""

from __future__ import annotations

import datetime
from typing import Any, Dict, List

import pytest
from langchain_core.messages import (
    AIMessage,
    BaseMessage,
    HumanMessage,
    RemoveMessage,
    SystemMessage,
    ToolMessage,
)
from langgraph.graph import END, START, StateGraph
from pydantic import ValidationError

from state import (
    AgentState,
    AgentStateValidator,
    create_history_entry,
    create_initial_state,
    format_state_summary,
    prune_intermediate_scratchpad,
    prune_message_history,
)


# ============================================================================
# TIER 1: Feature Coverage (Schema & Standard Defaults)
# ============================================================================

def test_create_initial_state_defaults():
    """Verify create_initial_state returns a well-formed AgentState dictionary."""
    state = create_initial_state("Deploy social media asset")

    assert len(state["messages"]) == 1
    assert isinstance(state["messages"][0], HumanMessage)
    assert state["messages"][0].content == "Deploy social media asset"
    assert state["next_worker"] is None
    assert state["task_intent"] == "Deploy social media asset"
    assert state["execution_history"] == []
    assert state["summary"] == ""
    assert state["iteration_count"] == 0
    assert state["max_iterations"] == 10
    assert state["status"] == "IDLE"


def test_create_initial_state_with_system_prompt():
    """Verify system prompt is properly prepended before user message."""
    state = create_initial_state(
        user_input="Run research query",
        max_iterations=5,
        task_intent="RESEARCH",
        system_prompt="You are the Antigravity Supervisor.",
        status="RUNNING",
    )

    assert len(state["messages"]) == 2
    assert isinstance(state["messages"][0], SystemMessage)
    assert state["messages"][0].content == "You are the Antigravity Supervisor."
    assert isinstance(state["messages"][1], HumanMessage)
    assert state["messages"][1].content == "Run research query"
    assert state["task_intent"] == "RESEARCH"
    assert state["max_iterations"] == 5
    assert state["status"] == "RUNNING"


def test_create_initial_state_with_explicit_messages():
    """Verify explicitly passed messages list is respected."""
    custom_msgs = [HumanMessage(content="Hello", id="m1"), AIMessage(content="Hi", id="m2")]
    state = create_initial_state(messages=custom_msgs, task_intent="GREETING")

    assert len(state["messages"]) == 2
    assert state["messages"][0].content == "Hello"
    assert state["messages"][1].content == "Hi"
    assert state["task_intent"] == "GREETING"


def test_create_initial_state_empty_inputs():
    """Verify create_initial_state handles empty strings and default intent."""
    state = create_initial_state()
    assert state["messages"] == []
    assert state["task_intent"] == ""
    assert state["iteration_count"] == 0
    assert state["max_iterations"] == 10


def test_create_history_entry_structure():
    """Verify history entry fields, types, and ISO timestamp formatting."""
    entry = create_history_entry(
        node="supervisor",
        action="route",
        details={"target": "social_worker"},
        status="SUCCESS",
    )

    assert entry["node"] == "supervisor"
    assert entry["worker"] == "supervisor"
    assert entry["action"] == "route"
    assert entry["details"] == {"target": "social_worker"}
    assert entry["status"] == "SUCCESS"
    assert "timestamp" in entry
    # Verify timestamp is valid ISO 8601
    parsed_time = datetime.datetime.fromisoformat(entry["timestamp"])
    assert parsed_time is not None


def test_create_history_entry_worker_and_node_compatibility():
    """Verify create_history_entry accepts worker alias and extra metadata."""
    entry = create_history_entry(
        worker="mobile_worker",
        action="tap_element",
        result={"element_id": "btn_confirm", "tapped": True},
        error=None,
    )

    assert entry["node"] == "mobile_worker"
    assert entry["worker"] == "mobile_worker"
    assert entry["action"] == "tap_element"
    assert entry["result"] == {"element_id": "btn_confirm", "tapped": True}
    assert entry["error"] is None


def test_create_history_entry_custom_kwargs():
    """Verify extra kwargs passed to create_history_entry are captured."""
    entry = create_history_entry(
        node="research_worker",
        action="query_rules",
        custom_tag="rule_verification",
        retry_count=2,
    )
    assert entry["node"] == "research_worker"
    assert entry["custom_tag"] == "rule_verification"
    assert entry["retry_count"] == 2


def test_agent_state_validator_valid():
    """Verify Pydantic validator passes for compliant state dictionaries."""
    valid_data = {
        "task_intent": "Run automation",
        "next_worker": "social_worker",
        "summary": "Step 1 complete",
        "iteration_count": 1,
        "max_iterations": 10,
        "status": "RUNNING",
        "execution_history": [{"node": "supervisor", "action": "route"}],
    }
    validated = AgentStateValidator(**valid_data)
    assert validated.task_intent == "Run automation"
    assert validated.iteration_count == 1
    assert validated.status == "RUNNING"


def test_agent_state_validator_invalid_iteration_count():
    """Verify Pydantic validator rejects negative iteration counts."""
    invalid_data = {
        "task_intent": "Run automation",
        "iteration_count": -1,
        "max_iterations": 10,
    }
    with pytest.raises(ValidationError):
        AgentStateValidator(**invalid_data)


def test_agent_state_validator_invalid_status():
    """Verify Pydantic validator rejects unsupported lifecycle status strings."""
    invalid_data = {
        "task_intent": "Run automation",
        "status": "UNKNOWN_CUSTOM_STATUS",
    }
    with pytest.raises(ValidationError):
        AgentStateValidator(**invalid_data)


# ============================================================================
# TIER 2: Boundary & Corner Cases (Context Pruning Logic)
# ============================================================================

def test_prune_messages_under_or_equal_limit():
    """When message count <= max_messages, no RemoveMessage commands are generated."""
    msgs = [HumanMessage(content=f"m_{i}", id=str(i)) for i in range(5)]
    assert prune_message_history(msgs, max_messages=5, preserve_first_n=1) == []
    assert prune_message_history(msgs, max_messages=10, preserve_first_n=1) == []


def test_prune_messages_over_limit_preserving_head_and_tail():
    """When messages exceed limit, intermediate messages are pruned while preserving head and tail."""
    msgs = [HumanMessage(content=f"msg_{i}", id=f"id_{i}") for i in range(10)]
    # Total 10 messages, max_messages=4, preserve_first_n=1
    # Preserves id_0 (head, 1 msg) and id_7, id_8, id_9 (tail, 3 msgs)
    # Prunes id_1..id_6 (6 messages)
    removals = prune_message_history(msgs, max_messages=4, preserve_first_n=1)

    assert len(removals) == 6
    assert [r.id for r in removals] == ["id_1", "id_2", "id_3", "id_4", "id_5", "id_6"]


def test_prune_messages_zero_preserve():
    """When preserve_first_n is 0, keeps only the trailing max_messages."""
    msgs = [HumanMessage(content=f"m_{i}", id=f"id_{i}") for i in range(6)]
    removals = prune_message_history(msgs, max_messages=2, preserve_first_n=0)

    assert len(removals) == 4
    assert [r.id for r in removals] == ["id_0", "id_1", "id_2", "id_3"]


def test_prune_messages_preserve_first_n_larger_than_total():
    """When preserve_first_n exceeds total message count, no pruning occurs."""
    msgs = [HumanMessage(content=f"m_{i}", id=f"id_{i}") for i in range(4)]
    assert prune_message_history(msgs, max_messages=2, preserve_first_n=10) == []


def test_prune_messages_empty_and_no_ids():
    """Verify empty sequences and messages without IDs are handled safely."""
    assert prune_message_history([], max_messages=5) == []

    # Messages without id attribute should not emit RemoveMessage
    msgs_without_id = [HumanMessage(content="msg1"), HumanMessage(content="msg2"), HumanMessage(content="msg3")]
    removals = prune_message_history(msgs_without_id, max_messages=1, preserve_first_n=0)
    assert removals == []


def test_prune_scratchpad_empty_and_clean_conversation():
    """Verify scratchpad pruner returns empty list when no tool messages exist."""
    clean_msgs = [HumanMessage(content="task", id="h1"), AIMessage(content="answer", id="a1")]
    assert prune_intermediate_scratchpad(clean_msgs) == []
    assert prune_intermediate_scratchpad([]) == []


def test_prune_scratchpad_removes_multiple_tool_turns():
    """Verify scratchpad pruner targets all ToolMessages and tool-calling AIMessages across multi-step turns."""
    msgs = [
        HumanMessage(content="task", id="h1"),
        AIMessage(content="calling tool 1", id="ai_tool_1", tool_calls=[{"name": "t1", "args": {}, "id": "c1"}]),
        ToolMessage(content="tool 1 output", tool_call_id="c1", id="tm_1"),
        AIMessage(content="calling tool 2", id="ai_tool_2", tool_calls=[{"name": "t2", "args": {}, "id": "c2"}]),
        ToolMessage(content="tool 2 output", tool_call_id="c2", id="tm_2"),
        AIMessage(content="Final synthesis response", id="ai_final"),
    ]
    removals = prune_intermediate_scratchpad(msgs)

    assert len(removals) == 4
    assert {r.id for r in removals} == {"ai_tool_1", "tm_1", "ai_tool_2", "tm_2"}


# ============================================================================
# TIER 3: Cross-Feature & StateGraph Reducer Integration
# ============================================================================

def test_stategraph_messages_and_history_reducers():
    """Verify add_messages and operator.add reducers operate seamlessly within a live StateGraph."""
    builder = StateGraph(AgentState)

    def node_supervisor(state: AgentState) -> Dict[str, Any]:
        return {
            "iteration_count": state["iteration_count"] + 1,
            "next_worker": "social_worker",
            "execution_history": [create_history_entry("supervisor", "route_to_social")],
            "messages": [AIMessage(content="Routing to social worker", id="ai_1")],
        }

    def node_worker(state: AgentState) -> Dict[str, Any]:
        return {
            "iteration_count": state["iteration_count"] + 1,
            "next_worker": None,
            "status": "COMPLETED",
            "execution_history": [create_history_entry("social_worker", "deploy_fb_video")],
            "messages": [AIMessage(content="Video deployed successfully", id="ai_2")],
        }

    builder.add_node("supervisor", node_supervisor)
    builder.add_node("social_worker", node_worker)
    builder.add_edge(START, "supervisor")
    builder.add_edge("supervisor", "social_worker")
    builder.add_edge("social_worker", END)

    graph = builder.compile()
    init_state = create_initial_state("Deploy EDM video asset")

    result = graph.invoke(init_state)

    # Initial HumanMessage + 2 AIMessages = 3 messages
    assert len(result["messages"]) == 3
    assert result["messages"][0].content == "Deploy EDM video asset"
    assert result["messages"][1].content == "Routing to social worker"
    assert result["messages"][2].content == "Video deployed successfully"

    # History concatenation: 2 entries
    assert len(result["execution_history"]) == 2
    assert result["execution_history"][0]["node"] == "supervisor"
    assert result["execution_history"][1]["node"] == "social_worker"

    # Scalars
    assert result["iteration_count"] == 2
    assert result["status"] == "COMPLETED"
    assert result["next_worker"] is None


def test_stategraph_prune_messages_in_graph_node():
    """Verify emitting RemoveMessage instances inside a node prunes state messages in StateGraph."""
    builder = StateGraph(AgentState)

    def node_expand(state: AgentState) -> Dict[str, Any]:
        new_msgs = [AIMessage(content=f"step_{i}", id=f"ai_{i}") for i in range(6)]
        return {"messages": new_msgs}

    def node_prune(state: AgentState) -> Dict[str, Any]:
        removals = prune_message_history(state["messages"], max_messages=2, preserve_first_n=1)
        return {"messages": removals}

    builder.add_node("expand", node_expand)
    builder.add_node("prune", node_prune)
    builder.add_edge(START, "expand")
    builder.add_edge("expand", "prune")
    builder.add_edge("prune", END)

    graph = builder.compile()
    init_state = create_initial_state("Initial root task")
    result = graph.invoke(init_state)

    # 1 initial HumanMessage + 6 AIMessages = 7 total. Pruned to 2 (root + last ai_5).
    assert len(result["messages"]) == 2
    assert isinstance(result["messages"][0], HumanMessage)
    assert result["messages"][0].content == "Initial root task"
    assert result["messages"][1].content == "step_5"


def test_stategraph_scratchpad_pruning_in_node():
    """Verify tool scratchpads are stripped via RemoveMessage while retaining synthesized output."""
    builder = StateGraph(AgentState)

    def node_tool_action(state: AgentState) -> Dict[str, Any]:
        return {
            "messages": [
                AIMessage(content="", id="ai_call", tool_calls=[{"name": "query_db", "args": {}, "id": "c_1"}]),
                ToolMessage(content="raw query data 1000 rows...", tool_call_id="c_1", id="tm_1"),
                AIMessage(content="Synthesized insight: trends are up 20%", id="ai_insight"),
            ]
        }

    def node_compact(state: AgentState) -> Dict[str, Any]:
        removals = prune_intermediate_scratchpad(state["messages"])
        return {"messages": removals, "summary": "DB query concluded successfully"}

    builder.add_node("tool_action", node_tool_action)
    builder.add_node("compact", node_compact)
    builder.add_edge(START, "tool_action")
    builder.add_edge("tool_action", "compact")
    builder.add_edge("compact", END)

    graph = builder.compile()
    init_state = create_initial_state("Analyze trends")
    result = graph.invoke(init_state)

    # Initial HumanMessage + ai_insight (ai_call and tm_1 pruned)
    assert len(result["messages"]) == 2
    assert result["messages"][0].content == "Analyze trends"
    assert result["messages"][1].content == "Synthesized insight: trends are up 20%"
    assert result["summary"] == "DB query concluded successfully"


# ============================================================================
# TIER 4: Real-World Scenarios & Formatting
# ============================================================================

def test_format_state_summary_rendering():
    """Verify format_state_summary compiles an informative single-line string."""
    state = create_initial_state(
        user_input="Scrape cards",
        task_intent="SPORTS_CARD_ETL",
        max_iterations=8,
    )
    state["iteration_count"] = 3
    state["status"] = "RUNNING"
    state["execution_history"] = [
        create_history_entry("supervisor", "route"),
        create_history_entry("research_worker", "scrape"),
    ]

    summary = format_state_summary(state)
    assert "Intent: SPORTS_CARD_ETL" in summary
    assert "Status: RUNNING" in summary
    assert "Iteration: 3/8" in summary
    assert "History Count: 2" in summary
    assert "Messages: 1" in summary


def test_format_state_summary_empty_state():
    """Verify format_state_summary handles empty or minimal state dictionaries."""
    state: AgentState = {
        "messages": [],
        "next_worker": None,
        "task_intent": "",
        "execution_history": [],
        "summary": "",
        "iteration_count": 0,
        "max_iterations": 10,
        "status": "IDLE",
    }
    summary = format_state_summary(state)
    assert "Intent: N/A" in summary
    assert "Status: IDLE" in summary
    assert "Iteration: 0/10" in summary
    assert "History Count: 0" in summary
    assert "Messages: 0" in summary


def test_multi_turn_history_accumulation():
    """Verify execution history entries maintain chronological order across multiple updates."""
    history: List[Dict[str, Any]] = []
    e1 = create_history_entry("supervisor", "classify", status="SUCCESS")
    e2 = create_history_entry("mobile_worker", "screenshot", status="SUCCESS")
    e3 = create_history_entry("mobile_worker", "click", status="FAILED", error="Element not visible")

    history = history + [e1] + [e2] + [e3]
    assert len(history) == 3
    assert history[0]["action"] == "classify"
    assert history[1]["action"] == "screenshot"
    assert history[2]["error"] == "Element not visible"


# ============================================================================
# TIER 5: Adversarial & Edge Cases
# ============================================================================

def test_prune_messages_extreme_bounds():
    """Handles negative, zero, and arbitrarily large max_messages bounds without errors."""
    msgs = [HumanMessage(content=f"msg_{i}", id=str(i)) for i in range(5)]

    # Max messages larger than total -> no removals
    assert prune_message_history(msgs, max_messages=100) == []

    # Max messages 0 -> prunes all eligible messages
    removals_zero = prune_message_history(msgs, max_messages=0, preserve_first_n=0)
    assert len(removals_zero) == 5

    # Negative preserve_first_n -> treated as 0
    removals_neg = prune_message_history(msgs, max_messages=2, preserve_first_n=-5)
    assert len(removals_neg) == 3

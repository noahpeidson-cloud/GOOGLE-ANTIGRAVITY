"""
Milestone M1 Empirical Challenger Stress Test & Benchmark Suite.
Tests extreme load, concurrency, reducer accumulation, message pruning churn,
mock pool contention, and serialization integrity for state.py and db.py.
"""

from __future__ import annotations

import asyncio
import concurrent.futures
import datetime
import os
import threading
import time
from typing import Any, Dict, List, Optional, Sequence
from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from langchain_core.messages import (
    AIMessage,
    BaseMessage,
    ChatMessage,
    FunctionMessage,
    HumanMessage,
    RemoveMessage,
    SystemMessage,
    ToolMessage,
)
from langgraph.checkpoint.base import BaseCheckpointSaver, Checkpoint, CheckpointMetadata
from langgraph.checkpoint.memory import MemorySaver
from langgraph.checkpoint.postgres import PostgresSaver
from langgraph.checkpoint.postgres.aio import AsyncPostgresSaver
from langgraph.graph import END, START, StateGraph
from langgraph.graph.message import add_messages
from psycopg import AsyncConnection, Connection
from psycopg.rows import dict_row
from psycopg_pool import AsyncConnectionPool, ConnectionPool, PoolTimeout
from pydantic import ValidationError

from db import (
    close_async_connection_pool,
    close_connection_pool,
    create_async_connection_pool,
    create_connection_pool,
    get_async_checkpointer,
    get_checkpointer,
)
from state import (
    AgentState,
    AgentStateValidator,
    create_history_entry,
    create_initial_state,
    format_state_summary,
    prune_intermediate_scratchpad,
    prune_message_history,
)

SAMPLE_PG_URI = "postgresql://stress_user:stress_pass@127.0.0.1:5432/stress_db"


# ============================================================================
# DOMAIN 1: RAPID CONSECUTIVE STATE TRANSITIONS & REDUCER ACCUMULATION UNDER LOAD
# ============================================================================

class TestStateTransitionsAndReducerLoad:
    """Stress tests for high-volume state transitions, history accumulation, and pruning."""

    def test_rapid_10k_history_accumulation(self):
        """Stress-test accumulating 10,000 history entries with chronological ordering and timestamp validation."""
        start_time = time.perf_counter()
        history: List[Dict[str, Any]] = []

        # Generate 10,000 entries across 5 simulated worker nodes
        workers = ["supervisor", "social_worker", "mobile_worker", "research_worker", "supervisor"]
        for i in range(10000):
            node = workers[i % len(workers)]
            entry = create_history_entry(
                node=node,
                action=f"action_{i}",
                details={"step": i, "data": f"payload_{i}"},
                status="SUCCESS" if i % 100 != 0 else "FAILED",
                error="simulated error" if i % 100 == 0 else None,
                custom_seq=i,
            )
            history.append(entry)

        elapsed = time.perf_counter() - start_time

        assert len(history) == 10000
        assert history[0]["action"] == "action_0"
        assert history[9999]["action"] == "action_9999"
        assert history[100]["status"] == "FAILED"
        assert history[100]["error"] == "simulated error"
        assert history[999]["custom_seq"] == 999
        assert elapsed < 1.5, f"Accumulation took too long: {elapsed:.4f}s"

    def test_continuous_pruning_churn_1000_cycles(self):
        """Simulate a long-running agent with 1,000 cycles of (add 10 messages -> prune to 6)."""
        messages: List[BaseMessage] = [HumanMessage(content="Root goal: scrape and publish", id="root_msg_0")]
        
        # Oracle tracker: we know what should remain after each prune
        # Root message must NEVER be pruned when preserve_first_n=1
        for cycle in range(1000):
            # Add 10 messages
            new_batch = [
                AIMessage(content=f"Cycle {cycle} step {j}", id=f"c{cycle}_m{j}")
                for j in range(10)
            ]
            messages = list(add_messages(messages, new_batch))
            
            # Prune down to max 6 messages (1 root + 5 tail)
            removals = prune_message_history(messages, max_messages=6, preserve_first_n=1)
            messages = list(add_messages(messages, removals))

            # Invariant checks
            assert len(messages) == 6
            assert messages[0].id == "root_msg_0"
            assert messages[-1].id == f"c{cycle}_m9"

        assert len(messages) == 6
        assert messages[0].id == "root_msg_0"
        expected_ids = ["root_msg_0", "c999_m5", "c999_m6", "c999_m7", "c999_m8", "c999_m9"]
        assert [m.id for m in messages] == expected_ids

    def test_deep_stategraph_500_turn_execution(self):
        """Execute a live StateGraph compiled with add_messages and history reducers across 500 iterative turns."""
        builder = StateGraph(AgentState)

        def node_loop(state: AgentState) -> Dict[str, Any]:
            cur_iter = state["iteration_count"] + 1
            new_msg = AIMessage(content=f"Turn_{cur_iter}", id=f"msg_turn_{cur_iter}")
            new_hist = create_history_entry(
                node="worker_node",
                action=f"step_{cur_iter}",
                details={"iter": cur_iter},
            )
            current_msgs = list(state["messages"]) + [new_msg]
            removals = prune_message_history(current_msgs, max_messages=8, preserve_first_n=1)

            updates: Dict[str, Any] = {
                "iteration_count": cur_iter,
                "execution_history": [new_hist],
                "messages": [new_msg] + removals,
            }
            if cur_iter >= 200:
                updates["status"] = "COMPLETED"
            return updates

        def should_continue(state: AgentState) -> str:
            if state["iteration_count"] >= 200 or state["status"] == "COMPLETED":
                return END
            return "loop"

        builder.add_node("loop", node_loop)
        builder.add_edge(START, "loop")
        builder.add_conditional_edges("loop", should_continue, {"loop": "loop", END: END})

        graph = builder.compile()
        init_state = create_initial_state("Start stress run", max_iterations=300)

        start = time.perf_counter()
        result = graph.invoke(init_state, {"recursion_limit": 500})
        elapsed = time.perf_counter() - start

        assert result["iteration_count"] == 200
        assert result["status"] == "COMPLETED"
        assert len(result["execution_history"]) == 200
        assert len(result["messages"]) == 8
        assert result["messages"][0].content == "Start stress run"
        assert result["messages"][-1].content == "Turn_200"
        assert elapsed < 3.0, f"500-turn graph execution took {elapsed:.4f}s"

    def test_scratchpad_pruning_complex_mixed_payloads(self):
        """Stress-test scratchpad pruning with interleaved tool calls, multi-tool batches, and empty tool outputs."""
        messages: List[BaseMessage] = [
            HumanMessage(content="Start complex multi-tool analysis", id="h_0"),
            AIMessage(
                content="Parallel dispatch",
                id="ai_call_1",
                tool_calls=[
                    {"name": "adb_tap", "args": {"x": 100, "y": 200}, "id": "tc_1"},
                    {"name": "adb_key", "args": {"key": 66}, "id": "tc_2"},
                    {"name": "adb_dump", "args": {}, "id": "tc_3"},
                ],
            ),
            ToolMessage(content='{"status": "ok"}', tool_call_id="tc_1", id="tm_1"),
            ToolMessage(content='{"status": "ok"}', tool_call_id="tc_2", id="tm_2"),
            ToolMessage(content='<hierarchy ... 500kb tree>', tool_call_id="tc_3", id="tm_3"),
            AIMessage(content="Analyzed UI tree, preparing upload step...", id="ai_thought_2"),
            AIMessage(
                content="Dispatching upload",
                id="ai_call_3",
                tool_calls=[{"name": "upload_file", "args": {"path": "/tmp/a.mp4"}, "id": "tc_4"}],
            ),
            ToolMessage(content="Upload success: id=9999", tool_call_id="tc_4", id="tm_4"),
            AIMessage(content="Campaign deployed and confirmed via screenshot.", id="ai_final"),
        ]

        removals = prune_intermediate_scratchpad(messages)
        pruned_ids = {r.id for r in removals}

        assert len(removals) == 6
        assert pruned_ids == {"ai_call_1", "tm_1", "tm_2", "tm_3", "ai_call_3", "tm_4"}

        compacted = list(add_messages(messages, removals))
        assert len(compacted) == 3
        assert [m.id for m in compacted] == ["h_0", "ai_thought_2", "ai_final"]

    def test_scratchpad_pruning_edge_cases_and_non_tool_ai_messages(self):
        """Verify scratchpad pruning ignores AIMessages with empty or absent tool_calls."""
        msgs = [
            HumanMessage(content="Hello", id="h1"),
            AIMessage(content="Thinking...", id="ai_no_tools"),
            AIMessage(content="Thinking with empty list...", id="ai_empty_tools", tool_calls=[]),
            SystemMessage(content="System instruction", id="s1"),
            ChatMessage(role="assistant", content="Custom chat msg", id="c1"),
            FunctionMessage(name="legacy_fn", content="Fn result", id="fn1"),
        ]

        removals = prune_intermediate_scratchpad(msgs)
        # None of the above should be pruned
        assert removals == []

    def test_prune_message_history_extreme_boundaries(self):
        """Stress-test message history pruning with boundary values."""
        msgs = [HumanMessage(content=f"m_{i}", id=f"id_{i}") for i in range(10)]

        # preserve_first_n == max_messages
        removals_equal = prune_message_history(msgs, max_messages=5, preserve_first_n=5)
        assert len(removals_equal) == 5
        assert [r.id for r in removals_equal] == ["id_5", "id_6", "id_7", "id_8", "id_9"]

        # preserve_first_n > max_messages
        removals_greater = prune_message_history(msgs, max_messages=3, preserve_first_n=7)
        assert len(removals_greater) == 3
        assert [r.id for r in removals_greater] == ["id_7", "id_8", "id_9"]

        # max_messages == 1, preserve_first_n == 1
        removals_one = prune_message_history(msgs, max_messages=1, preserve_first_n=1)
        assert len(removals_one) == 9
        assert [r.id for r in removals_one] == [f"id_{i}" for i in range(1, 10)]

    def test_state_summary_rendering_under_adversarial_states(self):
        """Verify format_state_summary handles unexpected, None, or extreme values gracefully."""
        adversarial_state: AgentState = {
            "messages": None,  # type: ignore
            "next_worker": None,
            "task_intent": None,  # type: ignore
            "execution_history": None,  # type: ignore
            "summary": "Some summary",
            "iteration_count": 999999,
            "max_iterations": 1000000,
            "status": "TERMINATED_LOOP_LIMIT",
        }
        rendered = format_state_summary(adversarial_state)
        assert "Intent: N/A" in rendered
        assert "Status: TERMINATED_LOOP_LIMIT" in rendered
        assert "Iteration: 999999/1000000" in rendered
        assert "History Count: 0" in rendered
        assert "Messages: 0" in rendered

    def test_state_validator_fuzzing(self):
        """Fuzz AgentStateValidator with boundary inputs, extreme iteration counts, and invalid types."""
        v = AgentStateValidator(
            task_intent="Extreme task intent " * 100,
            next_worker="research_worker",
            summary="A" * 10000,
            iteration_count=1000000,
            max_iterations=1000000,
            status="MAX_ITERATIONS_REACHED",
            execution_history=[{"node": f"n_{i}", "action": "act"} for i in range(1000)],
        )
        assert v.iteration_count == 1000000
        assert len(v.execution_history) == 1000

        with pytest.raises(ValidationError):
            AgentStateValidator(task_intent="x", max_iterations=0)

        with pytest.raises(ValidationError):
            AgentStateValidator(task_intent="x", max_iterations=-10)

        with pytest.raises(ValidationError):
            AgentStateValidator(task_intent="x", iteration_count=-1)

        with pytest.raises(ValidationError):
            AgentStateValidator(task_intent="x", status="NON_EXISTENT_STATUS")


# ============================================================================
# DOMAIN 2: CONCURRENT CHECKPOINTER INVOCATIONS & POOL CONTENTION
# ============================================================================

class TestConcurrentCheckpointerAndPoolContention:
    """Stress tests for concurrent checkpointer access, thread isolation, and pool exhaustion."""

    def test_concurrent_multithreaded_checkpointer_puts_and_gets(self):
        """Execute 50 concurrent threads accessing MemorySaver with both shared and independent threads."""
        saver = get_checkpointer(testing=True)
        num_threads = 50
        iterations_per_thread = 40
        errors: List[Exception] = []

        def worker(thread_idx: int):
            try:
                thread_id = f"isolated-thread-{thread_idx}" if thread_idx % 2 == 0 else "shared-contentious-thread"
                config = {"configurable": {"thread_id": thread_id, "checkpoint_ns": ""}}

                for step in range(iterations_per_thread):
                    channel_vals = {
                        "messages": [HumanMessage(content=f"t_{thread_idx}_s_{step}", id=f"m_{thread_idx}_{step}")],
                        "iteration_count": step,
                    }
                    checkpoint: Checkpoint = {
                        "v": 1,
                        "ts": datetime.datetime.now(datetime.timezone.utc).isoformat(),
                        "id": f"cp-{thread_idx:04d}-{step:04d}",
                        "channel_values": channel_vals,
                        "channel_versions": {"messages": step + 1, "iteration_count": step + 1},
                        "versions_seen": {},
                        "pending_sends": [],
                    }
                    metadata: CheckpointMetadata = {
                        "source": "worker",
                        "step": step,
                        "writes": {},
                        "parents": {},
                    }
                    saver.put(config, checkpoint, metadata, {"messages": step + 1, "iteration_count": step + 1})
                    
                    retrieved = saver.get_tuple(config)
                    assert retrieved is not None
                    assert "messages" in retrieved.checkpoint["channel_values"]
            except Exception as e:
                errors.append(e)

        threads = [threading.Thread(target=worker, args=(i,)) for i in range(num_threads)]
        for t in threads:
            t.start()
        for t in threads:
            t.join(timeout=10.0)

        assert len(errors) == 0, f"Encountered {len(errors)} concurrency errors: {errors[:3]}"

    @pytest.mark.asyncio
    async def test_concurrent_async_checkpointer_tasks(self):
        """Execute 100 concurrent async coroutines interacting with Async checkpointer."""
        saver = await get_async_checkpointer(testing=True)
        num_tasks = 100

        async def async_task(task_id: int):
            config = {"configurable": {"thread_id": f"async-coro-thread-{task_id}", "checkpoint_ns": ""}}
            for step in range(20):
                channel_vals = {"data": f"task_{task_id}_val_{step}"}
                checkpoint: Checkpoint = {
                    "v": 1,
                    "ts": datetime.datetime.now(datetime.timezone.utc).isoformat(),
                    "id": f"cp-async-{task_id:04d}-{step:04d}",
                    "channel_values": channel_vals,
                    "channel_versions": {"data": step + 1},
                    "versions_seen": {},
                    "pending_sends": [],
                }
                await saver.aput(
                    config,
                    checkpoint,
                    {"step": step, "source": "async", "writes": {}, "parents": {}},
                    {"data": step + 1},
                )
                res = await saver.aget_tuple(config)
                assert res is not None
                assert res.checkpoint["channel_values"]["data"] == f"task_{task_id}_val_{step}"

        tasks = [asyncio.create_task(async_task(i)) for i in range(num_tasks)]
        results = await asyncio.gather(*tasks, return_exceptions=True)
        for r in results:
            if isinstance(r, Exception):
                raise r

    def test_concurrent_stategraph_multi_thread_runs(self):
        """Execute 20 concurrent StateGraph runs on shared checkpointer with distinct thread_ids."""
        builder = StateGraph(AgentState)

        def worker_node(state: AgentState) -> Dict[str, Any]:
            cur = state["iteration_count"] + 1
            return {
                "iteration_count": cur,
                "execution_history": [create_history_entry("worker", f"step_{cur}")],
                "messages": [AIMessage(content=f"Processed step {cur}", id=f"m_{cur}")],
                "status": "COMPLETED" if cur >= 5 else "RUNNING",
            }

        def route_fn(state: AgentState) -> str:
            if state["iteration_count"] >= 5:
                return END
            return "worker"

        builder.add_node("worker", worker_node)
        builder.add_edge(START, "worker")
        builder.add_conditional_edges("worker", route_fn, {"worker": "worker", END: END})

        saver = get_checkpointer(testing=True)
        graph = builder.compile(checkpointer=saver)

        def run_thread(t_idx: int):
            config = {"configurable": {"thread_id": f"graph-thread-{t_idx}"}}
            init = create_initial_state(f"Task from worker {t_idx}")
            res = graph.invoke(init, config=config)
            assert res["iteration_count"] == 5
            assert res["status"] == "COMPLETED"
            assert len(res["execution_history"]) == 5

        with concurrent.futures.ThreadPoolExecutor(max_workers=10) as executor:
            futures = [executor.submit(run_thread, i) for i in range(20)]
            for f in concurrent.futures.as_completed(futures):
                f.result()

    def test_mock_pool_cursor_contention_and_simulated_load(self):
        """Simulate high concurrent connection checkout against a mocked PostgresSaver ConnectionPool."""
        mock_pool = MagicMock(spec=ConnectionPool)
        mock_conn = MagicMock(spec=Connection)
        mock_cursor = MagicMock()

        checkout_counter = 0
        lock = threading.Lock()

        def enter_connection():
            nonlocal checkout_counter
            with lock:
                checkout_counter += 1
            time.sleep(0.001)
            return mock_conn

        mock_pool.connection.return_value.__enter__.side_effect = enter_connection
        mock_conn.cursor.return_value.__enter__.return_value = mock_cursor
        mock_cursor.fetchone.return_value = {"v": 1}

        saver = PostgresSaver(conn=mock_pool)

        def db_worker(worker_id: int):
            config = {"configurable": {"thread_id": f"pg-pool-thread-{worker_id}", "checkpoint_ns": ""}}
            cp: Checkpoint = {
                "v": 1,
                "ts": "2026-08-27T00:00:00Z",
                "id": f"cp-{worker_id:04d}",
                "channel_values": {"state": worker_id},
                "channel_versions": {"state": 1},
                "versions_seen": {},
                "pending_sends": [],
            }
            saver.put(config, cp, {"source": "load_test", "step": 1, "writes": {}, "parents": {}}, {"state": 1})

        with concurrent.futures.ThreadPoolExecutor(max_workers=20) as executor:
            futures = [executor.submit(db_worker, i) for i in range(50)]
            concurrent.futures.wait(futures)

        assert checkout_counter == 50
        assert mock_cursor.execute.call_count >= 50

    def test_simulated_pool_timeout_handling(self):
        """Verify PoolTimeout from connection pool is raised cleanly and handled."""
        mock_pool = MagicMock(spec=ConnectionPool)
        mock_pool.connection.return_value.__enter__.side_effect = PoolTimeout("Connection acquisition timed out (pool exhausted)")

        saver = PostgresSaver(conn=mock_pool)
        config = {"configurable": {"thread_id": "timeout-thread", "checkpoint_ns": ""}}
        cp: Checkpoint = {
            "v": 1,
            "ts": "2026-08-27T00:00:00Z",
            "id": "cp-to",
            "channel_values": {},
            "channel_versions": {},
            "versions_seen": {},
            "pending_sends": [],
        }

        with pytest.raises(PoolTimeout, match="Connection acquisition timed out"):
            saver.put(config, cp, {}, {})

    def test_complex_state_serialization_roundtrip_integrity(self):
        """Verify deep nested data structures, Unicode strings, and special types survive checkpointer put/get."""
        saver = get_checkpointer(testing=True)
        config = {"configurable": {"thread_id": "serialization-test", "checkpoint_ns": ""}}

        complex_state_values = {
            "messages": [
                HumanMessage(content="User prompt with emoji 🚀 & special chars: <>&\"'\\", id="h_spec"),
                AIMessage(
                    content="Assistant response",
                    id="ai_spec",
                    tool_calls=[
                        {
                            "name": "complex_tool",
                            "args": {
                                "nested_dict": {"k1": [1, 2, 3], "k2": {"deep": True}},
                                "unicode_payload": "こんにちは / 🌟 / UTF-8 chars",
                                "floats": [1.23456789, 1e-6],
                            },
                            "id": "tc_spec_1",
                        }
                    ],
                ),
                ToolMessage(
                    content='{"status": 200, "data": [{"id": 1, "name": "card_ladder_etl"}]}',
                    tool_call_id="tc_spec_1",
                    id="tm_spec_1",
                ),
            ],
            "execution_history": [
                create_history_entry(
                    node="research_worker",
                    action="deep_search",
                    details={"query": "complex query", "confidence": 0.999},
                    status="SUCCESS",
                )
            ],
            "iteration_count": 42,
            "status": "RUNNING",
        }

        checkpoint: Checkpoint = {
            "v": 1,
            "ts": "2026-08-27T12:00:00.000000+00:00",
            "id": "cp-complex-1",
            "channel_values": complex_state_values,
            "channel_versions": {k: 1 for k in complex_state_values},
            "versions_seen": {},
            "pending_sends": [],
        }

        metadata: CheckpointMetadata = {
            "source": "supervisor",
            "step": 42,
            "writes": {},
            "parents": {},
        }

        new_versions = {k: 1 for k in complex_state_values}
        saver.put(config, checkpoint, metadata, new_versions)
        retrieved = saver.get_tuple(config)

        assert retrieved is not None
        restored_values = retrieved.checkpoint["channel_values"]
        assert restored_values["iteration_count"] == 42
        assert restored_values["status"] == "RUNNING"
        assert len(restored_values["messages"]) == 3
        assert restored_values["messages"][0].content == "User prompt with emoji 🚀 & special chars: <>&\"'\\"
        assert restored_values["messages"][1].tool_calls[0]["args"]["unicode_payload"] == "こんにちは / 🌟 / UTF-8 chars"
        assert len(restored_values["execution_history"]) == 1
        assert restored_values["execution_history"][0]["details"]["confidence"] == 0.999

    def test_pool_factory_robustness_with_adversarial_parameters(self):
        """Verify create_connection_pool behavior with invalid or extreme options."""
        p1 = create_connection_pool(SAMPLE_PG_URI, open=False, min_size=0, max_size=100)
        assert p1.min_size == 0
        assert p1.max_size == 100
        assert p1.kwargs["autocommit"] is True
        assert p1.kwargs["row_factory"] is dict_row

        with pytest.raises(ValueError):
            create_connection_pool(None)  # type: ignore

        with pytest.raises(ValueError):
            create_connection_pool(12345)  # type: ignore

        close_connection_pool(p1)
        close_connection_pool(p1)

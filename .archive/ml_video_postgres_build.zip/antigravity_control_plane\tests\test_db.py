"""
Unit and integration tests for database connection pooling and checkpointer factories.
Covers Tier 1 through Tier 5 per TEST_INFRA.md specification.
"""

from __future__ import annotations

import asyncio
import os
from typing import Any, Dict, Generator, TypedDict
from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from psycopg import AsyncConnection, Connection
from psycopg.rows import dict_row
from psycopg_pool import AsyncConnectionPool, ConnectionPool
from langgraph.checkpoint.base import BaseCheckpointSaver
from langgraph.checkpoint.memory import MemorySaver
from langgraph.checkpoint.postgres import PostgresSaver
from langgraph.checkpoint.postgres.aio import AsyncPostgresSaver
from langgraph.graph import END, START, StateGraph

from db import (
    DEFAULT_KWARGS,
    DEFAULT_MAX_POOL_SIZE,
    DEFAULT_MIN_POOL_SIZE,
    close_async_connection_pool,
    close_connection_pool,
    create_async_connection_pool,
    create_connection_pool,
    get_async_checkpointer,
    get_checkpointer,
)

SAMPLE_PG_URI = "postgresql://testuser:testpass@localhost:5432/antigravity_test"


# ============================================================================
# Tier 1: Feature Coverage (Happy Path Isolation)
# ============================================================================

def test_get_checkpointer_default_memory_fallback():
    """Verify that get_checkpointer() with no arguments returns a MemorySaver instance."""
    checkpointer = get_checkpointer()
    assert isinstance(checkpointer, MemorySaver)
    assert isinstance(checkpointer, BaseCheckpointSaver)


def test_get_checkpointer_explicit_memory_string():
    """Verify explicit memory sentinels return MemorySaver."""
    for sentinel in ["memory", ":memory:", "MEMORY", " none ", "local"]:
        saver = get_checkpointer(sentinel)
        assert isinstance(saver, MemorySaver)


def test_get_checkpointer_testing_flag():
    """Verify testing=True forces MemorySaver even if connection string is provided."""
    saver = get_checkpointer(SAMPLE_PG_URI, testing=True)
    assert isinstance(saver, MemorySaver)


def test_get_checkpointer_postgres_creation():
    """Verify get_checkpointer with postgres URI creates PostgresSaver backed by ConnectionPool."""
    saver = get_checkpointer(SAMPLE_PG_URI, open=False)
    assert isinstance(saver, PostgresSaver)
    assert isinstance(saver.conn, ConnectionPool)
    assert saver.conn.conninfo == SAMPLE_PG_URI


def test_connection_pool_kwargs_autocommit_dict_row():
    """Verify ConnectionPool kwargs explicitly enforce autocommit=True and row_factory=dict_row."""
    pool = create_connection_pool(SAMPLE_PG_URI, open=False)
    assert pool.kwargs["autocommit"] is True
    assert pool.kwargs["row_factory"] is dict_row


def test_connection_pool_custom_kwargs_merge():
    """Verify custom kwargs are merged alongside autocommit and dict_row."""
    pool = create_connection_pool(
        SAMPLE_PG_URI,
        open=False,
        kwargs={"application_name": "antigravity_pool"},
    )
    assert pool.kwargs["autocommit"] is True
    assert pool.kwargs["row_factory"] is dict_row
    assert pool.kwargs["application_name"] == "antigravity_pool"


@pytest.mark.asyncio
async def test_get_async_checkpointer_default_memory_fallback():
    """Verify get_async_checkpointer() with no arguments returns MemorySaver."""
    saver = await get_async_checkpointer()
    assert isinstance(saver, MemorySaver)


@pytest.mark.asyncio
async def test_get_async_checkpointer_sentinels():
    """Verify get_async_checkpointer() with sentinel values returns MemorySaver."""
    for sentinel in ["memory", ":memory:", " none "]:
        saver = await get_async_checkpointer(sentinel)
        assert isinstance(saver, MemorySaver)


@pytest.mark.asyncio
async def test_get_async_checkpointer_testing_flag():
    """Verify async checkpointer respects testing=True."""
    saver = await get_async_checkpointer(SAMPLE_PG_URI, testing=True)
    assert isinstance(saver, MemorySaver)


@pytest.mark.asyncio
async def test_get_async_checkpointer_postgres_creation():
    """Verify get_async_checkpointer creates AsyncPostgresSaver backed by AsyncConnectionPool."""
    saver = await get_async_checkpointer(SAMPLE_PG_URI, open=False)
    assert isinstance(saver, AsyncPostgresSaver)
    assert isinstance(saver.conn, AsyncConnectionPool)
    assert saver.conn.conninfo == SAMPLE_PG_URI


def test_get_checkpointer_with_preexisting_pool():
    """Verify passing an existing ConnectionPool directly to get_checkpointer wraps it."""
    mock_pool = MagicMock(spec=ConnectionPool)
    saver = get_checkpointer(pool=mock_pool)
    assert isinstance(saver, PostgresSaver)
    assert saver.conn is mock_pool


@pytest.mark.asyncio
async def test_get_async_checkpointer_with_preexisting_pool():
    """Verify passing an existing AsyncConnectionPool directly wraps it."""
    mock_apool = MagicMock(spec=AsyncConnectionPool)
    saver = await get_async_checkpointer(pool=mock_apool)
    assert isinstance(saver, AsyncPostgresSaver)
    assert saver.conn is mock_apool


# ============================================================================
# Tier 2: Boundary & Corner Cases
# ============================================================================

def test_empty_and_whitespace_connection_strings():
    """Verify empty or whitespace-only connection strings fallback to MemorySaver."""
    for empty_val in ["", "   ", None]:
        saver = get_checkpointer(empty_val)
        assert isinstance(saver, MemorySaver)


@pytest.mark.asyncio
async def test_async_empty_and_whitespace_connection_strings():
    """Verify async empty or whitespace-only connection strings fallback to MemorySaver."""
    for empty_val in ["", "   ", None]:
        saver = await get_async_checkpointer(empty_val)
        assert isinstance(saver, MemorySaver)


def test_env_var_fallback(monkeypatch):
    """Verify checkpointer resolves DATABASE_URL from environment when not explicitly passed."""
    monkeypatch.setenv("DATABASE_URL", SAMPLE_PG_URI)
    saver = get_checkpointer(open=False)
    assert isinstance(saver, PostgresSaver)
    assert saver.conn.conninfo == SAMPLE_PG_URI


def test_postgres_uri_env_fallback(monkeypatch):
    """Verify checkpointer resolves POSTGRES_URI from environment when DATABASE_URL is unset."""
    monkeypatch.delenv("DATABASE_URL", raising=False)
    monkeypatch.setenv("POSTGRES_URI", SAMPLE_PG_URI)
    saver = get_checkpointer(open=False)
    assert isinstance(saver, PostgresSaver)
    assert saver.conn.conninfo == SAMPLE_PG_URI


def test_explicit_argument_precedence_over_env(monkeypatch):
    """Verify explicit argument takes precedence over environment variables."""
    monkeypatch.setenv("DATABASE_URL", "postgresql://env_host:5432/envdb")
    saver = get_checkpointer(SAMPLE_PG_URI, open=False)
    assert saver.conn.conninfo == SAMPLE_PG_URI


def test_pool_size_and_timeout_boundaries():
    """Verify custom pool boundary parameters are correctly passed to ConnectionPool."""
    pool = create_connection_pool(
        SAMPLE_PG_URI,
        min_size=5,
        max_size=50,
        timeout=15.5,
        max_idle=300.0,
        open=False,
    )
    assert pool.min_size == 5
    assert pool.max_size == 50
    assert pool.timeout == 15.5
    assert pool.max_idle == 300.0


def test_async_pool_size_and_timeout_boundaries():
    """Verify custom pool boundary parameters are correctly passed to AsyncConnectionPool."""
    pool = create_async_connection_pool(
        SAMPLE_PG_URI,
        min_size=2,
        max_size=25,
        timeout=20.0,
        max_idle=400.0,
        open=False,
    )
    assert pool.min_size == 2
    assert pool.max_size == 25
    assert pool.timeout == 20.0
    assert pool.max_idle == 400.0


def test_create_pool_invalid_conninfo_raises():
    """Verify invalid/empty conninfo raises ValueError."""
    with pytest.raises(ValueError, match="A valid PostgreSQL connection URI"):
        create_connection_pool("")

    with pytest.raises(ValueError, match="A valid PostgreSQL connection URI"):
        create_connection_pool("   ")

    with pytest.raises(ValueError, match="A valid PostgreSQL connection URI"):
        create_async_connection_pool("")

    with pytest.raises(ValueError, match="A valid PostgreSQL connection URI"):
        create_async_connection_pool("   ")


def test_auto_setup_sync_checkpointer():
    """Verify auto_setup=True invokes saver.setup() on PostgresSaver."""
    mock_pool = MagicMock(spec=ConnectionPool)
    mock_conn = MagicMock(spec=Connection)
    mock_cur = MagicMock()
    mock_pool.connection.return_value.__enter__.return_value = mock_conn
    mock_conn.cursor.return_value.__enter__.return_value = mock_cur
    mock_cur.fetchone.return_value = {"v": -1}

    saver = get_checkpointer(pool=mock_pool, auto_setup=True)
    assert isinstance(saver, PostgresSaver)
    assert mock_cur.execute.called


@pytest.mark.asyncio
async def test_auto_setup_async_checkpointer():
    """Verify auto_setup=True awaits saver.setup() on AsyncPostgresSaver."""
    mock_apool = MagicMock(spec=AsyncConnectionPool)
    mock_conn = MagicMock(spec=AsyncConnection)
    mock_cur = MagicMock()
    mock_cur.execute = AsyncMock()
    mock_cur.fetchone = AsyncMock(return_value={"v": -1})
    mock_conn.cursor.return_value.__aenter__ = AsyncMock(return_value=mock_cur)
    mock_conn.cursor.return_value.__aexit__ = AsyncMock(return_value=None)
    mock_apool.connection.return_value.__aenter__ = AsyncMock(return_value=mock_conn)
    mock_apool.connection.return_value.__aexit__ = AsyncMock(return_value=None)

    saver = await get_async_checkpointer(pool=mock_apool, auto_setup=True)
    assert isinstance(saver, AsyncPostgresSaver)
    assert mock_cur.execute.called


# ============================================================================
# Tier 3: Cross-Feature Combinations (LangGraph StateGraph Execution)
# ============================================================================

class MockWorkflowState(TypedDict):
    value: str
    count: int


def test_sync_stategraph_checkpointing_with_memory_saver():
    """Verify MemorySaver preserves and increments state across synchronous graph invocations."""
    builder = StateGraph(MockWorkflowState)
    builder.add_node("step", lambda s: {"value": s["value"] + "->step", "count": s["count"] + 1})
    builder.add_edge(START, "step")
    builder.add_edge("step", END)

    saver = get_checkpointer()
    graph = builder.compile(checkpointer=saver)

    config = {"configurable": {"thread_id": "thread-1"}}
    res1 = graph.invoke({"value": "init", "count": 0}, config=config)
    assert res1 == {"value": "init->step", "count": 1}

    state1 = graph.get_state(config)
    assert state1.values["count"] == 1

    res2 = graph.invoke({"value": "init2", "count": 10}, config=config)
    state2 = graph.get_state(config)
    assert state2.values["count"] == 11


@pytest.mark.asyncio
async def test_async_stategraph_checkpointing_with_memory_saver():
    """Verify MemorySaver preserves and restores state across asynchronous ainvoke calls."""
    builder = StateGraph(MockWorkflowState)
    builder.add_node("async_step", lambda s: {"value": s["value"] + "->async", "count": s["count"] + 1})
    builder.add_edge(START, "async_step")
    builder.add_edge("async_step", END)

    saver = await get_async_checkpointer()
    graph = builder.compile(checkpointer=saver)

    config = {"configurable": {"thread_id": "async-thread-1"}}
    res = await graph.ainvoke({"value": "start", "count": 5}, config=config)
    assert res == {"value": "start->async", "count": 6}

    state = await graph.aget_state(config)
    assert state.values["value"] == "start->async"
    assert state.values["count"] == 6


def test_thread_isolation_in_checkpointer():
    """Verify distinct thread IDs have isolated state timelines."""
    builder = StateGraph(MockWorkflowState)
    builder.add_node("step", lambda s: {"value": s["value"], "count": s["count"]})
    builder.add_edge(START, "step")
    builder.add_edge("step", END)

    saver = get_checkpointer()
    graph = builder.compile(checkpointer=saver)

    config_a = {"configurable": {"thread_id": "thread-A"}}
    config_b = {"configurable": {"thread_id": "thread-B"}}

    graph.invoke({"value": "Thread A State", "count": 100}, config=config_a)
    graph.invoke({"value": "Thread B State", "count": 200}, config=config_b)

    assert graph.get_state(config_a).values["value"] == "Thread A State"
    assert graph.get_state(config_b).values["value"] == "Thread B State"


def test_checkpoint_tuple_retrieval_and_history():
    """Verify checkpointer get_tuple retrieves exact tuple and history specs."""
    saver = get_checkpointer()
    config = {"configurable": {"thread_id": "history-thread", "checkpoint_ns": ""}}

    checkpoint = {
        "v": 1,
        "ts": "2026-08-27T00:00:00Z",
        "id": "cp-1",
        "channel_values": {"x": 42},
        "channel_versions": {"x": 1},
        "versions_seen": {},
        "pending_sends": [],
    }
    metadata = {"source": "input", "step": 1, "writes": {}, "parents": {}}

    saver.put(config, checkpoint, metadata, {"x": 1})
    tuple_result = saver.get_tuple(config)

    assert tuple_result is not None
    assert tuple_result.checkpoint["channel_values"]["x"] == 42
    assert tuple_result.metadata["step"] == 1


# ============================================================================
# Tier 4: Mocked PostgreSQL Real-World Workloads
# ============================================================================

def test_mocked_postgres_saver_put():
    """Verify PostgresSaver writes to mocked connection pool cursor."""
    mock_pool = MagicMock(spec=ConnectionPool)
    mock_conn = MagicMock(spec=Connection)
    mock_cur = MagicMock()
    mock_pool.connection.return_value.__enter__.return_value = mock_conn
    mock_conn.cursor.return_value.__enter__.return_value = mock_cur

    saver = PostgresSaver(conn=mock_pool)
    config = {"configurable": {"thread_id": "mock-pg-thread", "checkpoint_ns": ""}}
    checkpoint = {
        "v": 1,
        "ts": "2026-08-27T00:00:00Z",
        "id": "cp-mock",
        "channel_values": {},
        "channel_versions": {},
        "versions_seen": {},
        "pending_sends": [],
    }
    saver.put(config, checkpoint, {}, {})
    assert mock_cur.execute.called


@pytest.mark.asyncio
async def test_mocked_async_postgres_saver_aput():
    """Verify AsyncPostgresSaver writes to mocked async pool cursor."""
    mock_apool = MagicMock(spec=AsyncConnectionPool)
    mock_conn = MagicMock(spec=AsyncConnection)
    mock_cur = MagicMock()
    mock_cur.execute = AsyncMock()
    mock_conn.cursor.return_value.__aenter__ = AsyncMock(return_value=mock_cur)
    mock_conn.cursor.return_value.__aexit__ = AsyncMock(return_value=None)
    mock_apool.connection.return_value.__aenter__ = AsyncMock(return_value=mock_conn)
    mock_apool.connection.return_value.__aexit__ = AsyncMock(return_value=None)

    saver = AsyncPostgresSaver(conn=mock_apool)
    config = {"configurable": {"thread_id": "mock-apg-thread", "checkpoint_ns": ""}}
    checkpoint = {
        "v": 1,
        "ts": "2026-08-27T00:00:00Z",
        "id": "cp-mock-async",
        "channel_values": {},
        "channel_versions": {},
        "versions_seen": {},
        "pending_sends": [],
    }
    await saver.aput(config, checkpoint, {}, {})
    assert mock_cur.execute.called


def test_close_connection_pool_safe():
    """Verify close_connection_pool closes pool and ignores non-pools."""
    mock_pool = MagicMock(spec=ConnectionPool)
    mock_pool.closed = False
    close_connection_pool(mock_pool)
    mock_pool.close.assert_called_once()

    # Safe with None or MemorySaver
    close_connection_pool(None)
    close_connection_pool(MemorySaver())


def test_close_connection_pool_already_closed():
    """Verify close_connection_pool does not call close on already-closed pool."""
    mock_pool = MagicMock(spec=ConnectionPool)
    mock_pool.closed = True
    close_connection_pool(mock_pool)
    mock_pool.close.assert_not_called()


@pytest.mark.asyncio
async def test_close_async_connection_pool_safe():
    """Verify close_async_connection_pool awaits close on async pools."""
    mock_apool = MagicMock(spec=AsyncConnectionPool)
    mock_apool.closed = False
    mock_apool.close = AsyncMock()
    await close_async_connection_pool(mock_apool)
    mock_apool.close.assert_awaited_once()

    # Safe with None or MemorySaver
    await close_async_connection_pool(None)
    await close_async_connection_pool(MemorySaver())


@pytest.mark.asyncio
async def test_close_async_connection_pool_already_closed():
    """Verify close_async_connection_pool does not call close on already-closed async pool."""
    mock_apool = MagicMock(spec=AsyncConnectionPool)
    mock_apool.closed = True
    mock_apool.close = AsyncMock()
    await close_async_connection_pool(mock_apool)
    mock_apool.close.assert_not_called()


# ============================================================================
# Tier 5: Adversarial Hardening & Failure Recovery
# ============================================================================

def test_pipeline_with_connection_pool_rejection():
    """Verify passing pipeline to PostgresSaver with ConnectionPool raises ValueError."""
    mock_pool = MagicMock(spec=ConnectionPool)
    mock_pipe = MagicMock()
    with pytest.raises(ValueError, match="Pipeline should be used only with a single Connection"):
        PostgresSaver(conn=mock_pool, pipe=mock_pipe)


def test_invalid_connection_type_raises_type_error():
    """Verify get_connection raises TypeError when passed an unsupported object type."""
    from langgraph.checkpoint.postgres._internal import get_connection

    with pytest.raises(TypeError, match="Invalid connection type"):
        with get_connection("invalid_conn_string"):
            pass


def test_database_error_on_setup_propagates():
    """Verify database exceptions during setup() propagate cleanly."""
    mock_pool = MagicMock(spec=ConnectionPool)
    mock_conn = MagicMock(spec=Connection)
    mock_cur = MagicMock()
    mock_cur.execute.side_effect = RuntimeError("Database migration connection failure")
    mock_pool.connection.return_value.__enter__.return_value = mock_conn
    mock_conn.cursor.return_value.__enter__.return_value = mock_cur

    saver = PostgresSaver(conn=mock_pool)
    with pytest.raises(RuntimeError, match="Database migration connection failure"):
        saver.setup()

package com.example.concertcam8k

import android.os.Bundle
import android.os.PowerManager
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import com.example.concertcam8k.ui.theme.ConcertCam8KTheme

class MainActivity : ComponentActivity() {
    private lateinit var powerManager: PowerManager
    private val TAG = "ConcertCam8K"

    private val thermalListener = PowerManager.OnThermalStatusChangedListener { status ->
        when (status) {
            PowerManager.THERMAL_STATUS_MODERATE -> Log.w(TAG, "Thermal: MODERATE. Consider dropping frame rate.")
            PowerManager.THERMAL_STATUS_SEVERE -> Log.e(TAG, "Thermal: SEVERE! Vendor HAL crash imminent. Pausing 8K capture.")
            PowerManager.THERMAL_STATUS_CRITICAL -> Log.e(TAG, "Thermal: CRITICAL! Shutting down Camera2 API.")
            else -> Log.i(TAG, "Thermal: OK. Status: $status")
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // Register Thermal Safeguards
        powerManager = getSystemService(POWER_SERVICE) as PowerManager
        powerManager.addThermalStatusListener(thermalListener)

        enableEdgeToEdge()
        setContent {
            ConcertCam8KTheme {
                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    Greeting(
                        name = "S26 Ultra 8K Capture (Thermal Guard Active)",
                        modifier = Modifier.padding(innerPadding)
                    )
                }
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        powerManager.removeThermalStatusListener(thermalListener)
    }
}

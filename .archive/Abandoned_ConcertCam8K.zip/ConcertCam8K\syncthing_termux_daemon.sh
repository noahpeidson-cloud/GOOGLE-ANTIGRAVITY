#!/data/data/com.termux/files/usr/bin/bash

# ==============================================================================
# S26 Ultra Headless Syncthing Daemon (Termux + Tasker)
# ==============================================================================
# Bypasses the aggressive Android battery optimization by running the native 
# Linux binary inside Termux, orchestrated by Tasker hooks.

echo "Acquiring Termux WakeLock to prevent Android OS hibernation..."
termux-wake-lock

echo "Starting Headless Syncthing Daemon..."
# Run Syncthing without the UI/browser hooks, pointing to local Termux config
syncthing serve --no-browser --home=/data/data/com.termux/files/home/.config/syncthing &

# Store PID to allow Tasker to kill it cleanly during Thermal Severe events
echo $! > /data/data/com.termux/files/home/syncthing.pid

echo "Syncthing is running headlessly."

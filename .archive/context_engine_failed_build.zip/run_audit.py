import os
from context_indexer import init_db, ingest_artifact
from semantic_evaluator import evaluate_stale_artifacts

# Use the current session's artifact directory
ARTIFACT_DIR = r"C:\Users\noahp\.gemini\antigravity\brain\f622f509-cca5-46a6-822e-21a54d1ce0c2"
HTML_OUT_PATH = os.path.join(ARTIFACT_DIR, "pending_archival.html")

# Mock current task for the semantic calculation
ACTIVE_TASK = """
Goal: We need to implement a Python daemon to process video edits via WebCodecs 
and deploy it securely. It must run headlessly and use SQLite to track states.
"""

def generate_ui(df_flagged):
    """
    Generates the strict R30 Consent UI.
    """
    rows = ""
    for _, row in df_flagged.iterrows():
        dist_color = "text-red-500" if row['distance'] > 0.8 else "text-orange-500"
        
        rows += f'''
        <div class="border border-[var(--border)] rounded-lg p-4 mb-3 flex items-start justify-between bg-[var(--background)]">
            <div class="flex-1">
                <h4 class="font-bold text-[var(--foreground)]">{row['filename']}</h4>
                <p class="text-xs font-mono text-[var(--muted-foreground)] mt-1">{row['content_preview']}...</p>
            </div>
            <div class="ml-4 text-right">
                <span class="text-xs uppercase font-bold tracking-wider {dist_color}">
                    Drift: {row['distance']:.3f}
                </span>
                <div class="mt-2">
                    <label class="flex items-center space-x-2 text-sm text-[var(--foreground)] cursor-pointer">
                        <input type="checkbox" class="rounded border-[var(--border)] bg-[var(--card)] text-indigo-500 focus:ring-indigo-500">
                        <span>Approve Archival</span>
                    </label>
                </div>
            </div>
        </div>
        '''

    html = f'''<!DOCTYPE html>
<html>
<head>
    <script src="https://www.gstatic.com/antigravity/web/dev/tailwindcss.min.js"></script>
</head>
<body class="bg-transparent text-[var(--foreground)] antialiased p-4">
    <div class="bg-[var(--card)] border border-[var(--border)] rounded-xl p-5 shadow-sm max-w-2xl mx-auto">
        <div class="border-b border-red-500/20 pb-4 mb-4 flex items-center justify-between">
            <div>
                <h2 class="text-red-500 font-bold text-lg flex items-center gap-2">
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"></path></svg>
                    Action Required: Context Saturation Audit
                </h2>
                <p class="text-[var(--muted-foreground)] text-sm mt-1">The following artifacts have high semantic drift from your active task. Select files to safely archive into the SQLite FTS5 database.</p>
            </div>
        </div>
        
        <div class="overflow-y-auto max-h-[300px] pr-2">
            {rows}
        </div>
        
        <div class="mt-5 pt-4 border-t border-[var(--border)] text-right">
            <button class="bg-[var(--foreground)] text-[var(--background)] px-4 py-2 rounded-md font-semibold text-sm hover:opacity-90 transition-opacity">
                Execute Archival
            </button>
        </div>
    </div>
</body>
</html>'''

    with open(HTML_OUT_PATH, "w", encoding="utf-8") as f:
        f.write(html)
    print(f"[UI] Generated Consent Modal at {HTML_OUT_PATH}")

def main():
    print("--- Starting Context Architecture Test Run ---")
    init_db()
    
    # 1. Evaluate Stale Artifacts
    print("\n--- Phase 1: Pandas Semantic Entropy Evaluation ---")
    df = evaluate_stale_artifacts(ACTIVE_TASK, ARTIFACT_DIR)
    print("\nEvaluation Results:")
    print(df[['filename', 'distance', 'flagged']].to_string())
    
    # 2. Filter flagged files
    flagged_df = df[df['flagged']]
    
    if flagged_df.empty:
        print("\n[RESULT] No artifacts exceeded the semantic drift threshold. Context is stable.")
        return
        
    # 3. Generate Consent UI
    print("\n--- Phase 2: R30 Strict UI Generation ---")
    generate_ui(flagged_df)
    
    # 4. (Simulated) Ingesting approved artifacts into SQLite
    # We will simulate the user approving them and us ingesting them.
    print("\n--- Phase 3: FTS5 Background Ingestion (Simulation) ---")
    for _, row in flagged_df.iterrows():
        filepath = os.path.join(ARTIFACT_DIR, row['filename'])
        with open(filepath, 'r', encoding='utf-8') as f:
            content = f.read()
        ingest_artifact(row['filename'], content)

if __name__ == "__main__":
    main()

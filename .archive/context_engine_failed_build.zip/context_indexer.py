import sqlite3
import os

DB_PATH = os.path.join(os.path.dirname(__file__), "context_memory.db")

def init_db():
    with sqlite3.connect(DB_PATH) as conn:
        c = conn.cursor()
        c.execute('''
            CREATE VIRTUAL TABLE IF NOT EXISTS rules_fts USING fts5(
                filename,
                content
            )
        ''')
        c.execute('''
            CREATE TABLE IF NOT EXISTS file_embeddings (
                filename TEXT PRIMARY KEY,
                embedding_json TEXT
            )
        ''')
        print("[DB] Initialized SQLite FTS5 Storage.")

def ingest_artifact(filename, content):
    with sqlite3.connect(DB_PATH) as conn:
        c = conn.cursor()
        # Delete existing to prevent duplicates
        c.execute("DELETE FROM rules_fts WHERE filename = ?", (filename,))
        c.execute("INSERT INTO rules_fts (filename, content) VALUES (?, ?)", (filename, content))
        print(f"[INGEST] Indexed {filename} into FTS5 engine.")

if __name__ == "__main__":
    init_db()

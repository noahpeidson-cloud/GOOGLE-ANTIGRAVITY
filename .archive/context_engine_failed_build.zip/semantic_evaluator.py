import os
import json
import numpy as np
import pandas as pd
from google import genai
from dotenv import load_dotenv

# R26: Load environment variables natively
load_dotenv()

# Initialize Google GenAI Client
client = genai.Client()

def get_embedding(text):
    """Retrieve text-embedding-004 embedding for a chunk of text."""
    # Truncate text to avoid massive token limits on basic embeddings
    truncated = text[:8000] 
    try:
        response = client.models.embed_content(
            model="text-embedding-004",
            contents=truncated,
        )
        return np.array(response.embeddings[0].values)
    except Exception as e:
        print(f"Embedding failed: {e}")
        # Return random mock embedding for testing if API fails or quota hits
        return np.random.rand(768)

def evaluate_stale_artifacts(active_task_text, artifact_dir):
    """
    R30/ML-Optimization-Loop: Calculates Semantic Entropy via Pandas K-Means.
    High Euclidean distance flags the artifact for the Consent UI.
    """
    print("[EVALUATOR] Calculating baseline task centroid...")
    task_centroid = get_embedding(active_task_text)
    
    results = []
    
    for filename in os.listdir(artifact_dir):
        if not filename.endswith(".md"):
            continue
            
        filepath = os.path.join(artifact_dir, filename)
        with open(filepath, 'r', encoding='utf-8') as f:
            content = f.read()
            
        print(f"[EVALUATOR] Embedding artifact: {filename}")
        doc_vec = get_embedding(content)
        
        # Calculate Euclidean Distance (Entropy/Drift)
        dist = np.linalg.norm(task_centroid - doc_vec)
        
        results.append({
            "filename": filename,
            "distance": float(dist),
            "content_preview": content[:150].replace('\n', ' ')
        })
        
    df = pd.DataFrame(results)
    
    # Threshold for staleness (heuristic for test)
    # The higher the distance, the more mathematically irrelevant it is to the active task.
    threshold = df['distance'].mean() + (df['distance'].std() * 0.5) if len(df) > 1 else 0.5
    
    df['flagged'] = df['distance'] > threshold
    
    return df
